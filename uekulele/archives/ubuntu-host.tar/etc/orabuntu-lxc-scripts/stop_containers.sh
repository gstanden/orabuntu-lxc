#!/bin/bash

which lxc-ls > /dev/null 2>&1
if [ $? -eq 0 ]
then
        function GetContainersRunning {
                sudo lxc-ls -f | grep RUNNING | sed 's/  */ /g' | cut -f1 -d' ' | sed 's/$/ /' | tr -d '\n'
        }
        ContainersRunning=$(GetContainersRunning)

        for i in $ContainersRunning
        do
                sudo lxc-stop -n $i
        done
fi

