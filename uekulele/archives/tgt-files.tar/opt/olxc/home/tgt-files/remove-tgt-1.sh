#!/bin/bash

export DATEXT=`date +"%Y%m%d%H%M"`
# export IQN_YR=`date +"%Y"`
# export IQN_MO=`date +"%m"`

export IQN_YR=$1
export IQN_MO=$2

export IQN=iqn.$IQN_YR-$IQN_MO.com.orabuntu-lxc:storage.tgt.lxc.oracle.asm

clear

echo ''
echo "=============================================="
echo "Stop multipath-tools service...               "
echo "=============================================="
echo ''

sudo service multipath-tools stop > /dev/null 2>&1

echo ''
echo "=============================================="
echo "Multipath-tools service stopped...            "
echo "=============================================="
echo ''

sleep 2

clear

echo ''
echo "=============================================="
echo "Delete LUNs from TGT target...                "
echo "=============================================="
echo ''

sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=0 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=1 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=2 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=3 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=4 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=5 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=6 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=7 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=8 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=9 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=10 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=11 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=12 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=13 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=14 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=15 > /dev/null 2>&1

echo ''
echo "=============================================="
echo "LUNs deleted from TGT target...               "
echo "=============================================="
echo ''

sleep 2

clear

echo ''
echo "=============================================="
echo "Logout of TGT target...                       "
echo "=============================================="
echo ''

sudo iscsiadm --mode node --targetname $IQN --portal 10.210.107.1:3260 --logout
sudo iscsiadm --mode node --targetname $IQN --portal 10.211.107.1:3260 --logout

echo ''
echo "=============================================="
echo "Logged out of TGT target...                   "
echo "=============================================="
echo ''

sleep 2

clear

echo ''
echo "=============================================="
echo "Delete TGT target...                          "
echo "=============================================="
echo ''

sudo tgtadm --lld iscsi --op delete --mode target --tid=1

echo ''
echo "=============================================="
echo "Delete TGT target completed...                "
echo "=============================================="
echo ''

sleep 2

clear

echo ''
echo "=============================================="
echo "Delete TGT backing files...                   "
echo "=============================================="
echo ''

sudo rm /asm0/* > /dev/null 2>&1
sudo rm /asm1/* > /dev/null 2>&1
sudo rm /asm2/* > /dev/null 2>&1
sudo rm /asm3/* > /dev/null 2>&1
sudo rm /asm4/* > /dev/null 2>&1

echo ''
echo "=============================================="
echo "Delete TGT backing files complete...          "
echo "=============================================="
echo ''

sleep 2

clear

echo ''
echo "=============================================="
echo "Flush any remaining multipaths...             "
echo "=============================================="
echo ''

sudo multipath -F

echo ''
echo "=============================================="
echo "Flush multipaths completed...                 "
echo "=============================================="
echo ''

sleep 2

clear

echo ''
echo "==============================================="
echo "List existing multipath maps...                "
echo "==============================================="
echo ''

ls -l /dev/mapper

echo ''
echo "==============================================="
echo "Verify existing multipath maps removed...      "
echo "'control' should be the only map left...       "
echo "==============================================="
echo ''

sleep 2

clear

echo ''
echo "==============================================="
echo "Start multipath-tools service...               "
echo "==============================================="
echo ''

sudo service multipath-tools start

echo ''
echo "==============================================="
echo "Multipath-tools service started...             "
echo "==============================================="
echo ''

sleep 2

clear

echo ''
echo "==============================================="
echo "Move any existing /etc/multipath.conf file...  "
echo "==============================================="
echo ''

if [ -e /etc/multipath.conf ]
then
sudo mv /etc/multipath.conf /etc/multipath.conf.$DATEXT
fi

echo ''
echo "==============================================="
echo "Existing /etc/multipath.conf file moved...     "
echo "==============================================="
echo ''

