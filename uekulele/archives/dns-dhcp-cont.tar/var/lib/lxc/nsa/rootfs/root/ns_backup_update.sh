#!/bin/bash

. $HOME/.profile

SourceDir="~/Manage-Orabuntu/backup-lxc-container/nsa/updates"
DestDir="/var/lib/lxc/nsa/rootfs/root/backup-lxc-container/nsa/updates"

function CheckAwsCliConfigured {
	aws s3 ls | grep backup-lxc-container | wc -l
}
AwsCliConfigured=$(CheckAwsCliConfigured)

rndc sync
mkdir -p  /root/backup-lxc-container/nsa/updates
tar -cvzPf /root/backup-lxc-container/nsa/updates/backup_nsa_ns.tar.gz -T /root/ns_backup_update.lst
chown -R ubuntu:ubuntu backup-lxc-container

if [ -s /root/gre_hosts.txt ]
then
	function GetGreHosts {
		cat /root/gre_hosts.txt | sed 's/$/ /' | tr -d '\n' | sed 's/^[ \t]*//;s/[ \t]*$//'
	}
	GreHosts=$(GetGreHosts)
fi

if   [ $AwsCliConfigured -eq 1 ] && [ -s /root/gre_hosts.txt ]
then
	aws s3 sync /root/backup-lxc-container/nsa/updates s3://backup-lxc-container/nsa/updates
	for i in $GreHosts
	do
		ssh-keygen -f "/root/.ssh/known_hosts" -R $i
		sshpass -p ubuntu ssh -tt -o CheckHostIP=no -o StrictHostKeyChecking=no ubuntu@$i mkdir -p $SourceDir/
		sshpass -p ubuntu scp     -o CheckHostIP=no -o StrictHostKeyChecking=no /root/backup-lxc-container/nsa/updates/backup_nsa_ns.tar.gz ubuntu@$i:$SourceDir
		sshpass -p ubuntu ssh -tt -o CheckHostIP=no -o StrictHostKeyChecking=no ubuntu@$i "sudo -S <<< "ubuntu" mkdir -p $DestDir"
		sshpass -p ubuntu ssh -tt -o CheckHostIP=no -o StrictHostKeyChecking=no ubuntu@$i "sudo -S <<< "ubuntu" cp -p $SourceDir/backup_nsa_ns.tar.gz $DestDir/backup_nsa_ns_update.tar.gz"
		function CheckProcessRunning {
			ps -ef | grep sshpass | grep $i | grep -v grep | wc -l
		}
		ProcessRunning=$(CheckProcessRunning)
		while [ $ProcessRunning -gt 0 ]
		do
			ProcessRunning=$(CheckProcessRunning)
			sleep 5
		done
		nohup sshpass -p ubuntu ssh -tt -o CheckHostIP=no -o StrictHostKeyChecking=no ubuntu@$i "sudo -S <<< "ubuntu" lxc-start -n nsa; sleep 5; sudo -S <<< "ubuntu" lxc-stop -n nsa" &
	done
elif [ -s /root/gre_hosts.txt ]
then
	for i in $GreHosts
	do
		ssh-keygen -f "/root/.ssh/known_hosts" -R $i
		sshpass -p ubuntu ssh -tt -o CheckHostIP=no -o StrictHostKeyChecking=no ubuntu@$i mkdir -p $SourceDir/
		sshpass -p ubuntu scp     -o CheckHostIP=no -o StrictHostKeyChecking=no /root/backup-lxc-container/nsa/updates/backup_nsa_ns.tar.gz ubuntu@$i:$SourceDir
		sshpass -p ubuntu ssh -tt -o CheckHostIP=no -o StrictHostKeyChecking=no ubuntu@$i "sudo -S <<< "ubuntu" mkdir -p $DestDir"
		sshpass -p ubuntu ssh -tt -o CheckHostIP=no -o StrictHostKeyChecking=no ubuntu@$i "sudo -S <<< "ubuntu" cp -p $SourceDir/backup_nsa_ns.tar.gz $DestDir/backup_nsa_ns_update.tar.gz"
		function CheckProcessRunning {
			ps -ef | grep sshpass | grep $i | grep -v grep | wc -l
		}
		ProcessRunning=$(CheckProcessRunning)
		while [ $ProcessRunning -gt 0 ]
		do
			ProcessRunning=$(CheckProcessRunning)
			sleep 5
		done
		nohup sshpass -p ubuntu ssh -tt -o CheckHostIP=no -o StrictHostKeyChecking=no ubuntu@$i "sudo -S <<< "ubuntu" lxc-start -n nsa; sleep 5; sudo -S <<< "ubuntu" lxc-stop -n nsa" &
	done
fi
