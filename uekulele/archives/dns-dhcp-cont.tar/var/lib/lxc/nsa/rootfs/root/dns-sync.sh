#!/bin/bash
#
# Synchronize LXC DNS DHCP local container replica
#
start() {
  /bin/tar -P -xvf /root/backup-lxc-container/olive/updates/backup_olive_ns_update.tar.gz > /dev/null 2>&1
}

stop() {
  /bin/rm /root/backup-lxc-container/olive/updates/backup_olive_ns_update.tar.gz > /dev/null 2>&1
}

case $1 in
  start|stop) "$1" ;;
esac

