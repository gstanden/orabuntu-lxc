#!/bin/bash

HOME=/home/ubuntu
USER=root
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/snap/bin

if [ -s /home/ubuntu/new_gre_host.txt ]
then
        function GetNewGreHost {
                cat /home/ubuntu/new_gre_host.txt
        }
        NewGreHost=$(GetNewGreHost)

        function GetGrepNewGreHost {
		touch			/root/gre_hosts.original.do-not-edit
		chmod 644		/root/gre_hosts.original.do-not-edit
                grep -c $NewGreHost	/root/gre_hosts.original.do-not-edit
        }
        GrepNewGreHost=$(GetGrepNewGreHost)

        if [ $GrepNewGreHost -eq 0 ]
        then
                echo $NewGreHost >>	/root/gre_hosts.original.do-not-edit
		chmod 644		/root/gre_hosts.original.do-not-edit
                sed  '1!G;h;$!d'	/root/gre_hosts.original.do-not-edit > /root/gre_hosts.txt
                cp -p                   /root/gre_hosts.txt /home/ubuntu/gre_hosts.txt
                chown ubuntu:ubuntu     /home/ubuntu/gre_hosts.txt
                chmod 644               /home/ubuntu/gre_hosts.txt
        fi
else
	touch			/home/ubuntu/gre_hosts.txt
	chown ubuntu:ubuntu     /home/ubuntu/gre_hosts.txt
	chmod 644               /home/ubuntu/gre_hosts.txt
fi

function CheckZoneUpdates {
	ls -l /var/lib/bind | grep -c jnl
}
ZoneUpdates=$(CheckZoneUpdates)

function CheckGreHostCount {
	cat /home/ubuntu/gre_hosts.txt | wc -l
}
GreHostCount=$(CheckGreHostCount)

if [ $GreHostCount -gt 1 ]
then
	if [ $ZoneUpdates -gt 0 ] || [ -s /home/ubuntu/new_gre_host.txt ]
	then
		rndc sync
		if [ $? -eq 0 ]
		then
			/root/ns_backup_update.sh
			if [ $? -eq 0 ]
			then
				service bind9 stop
				rm -f /var/lib/bind/*.jnl
				service bind9 start
			fi
		fi
	else
		touch no-dns-updates
	fi
fi

if [ -f /root/backup-lxc-container/nsa/updates/backup_nsa_ns_update.tar.gz ]
then
	service bind9 stop
	tar -P -xvf /root/backup-lxc-container/nsa/updates/backup_nsa_ns_update.tar.gz
	rm -f /root/backup-lxc-container/nsa/updates/backup_nsa_ns_update.tar.gz
	service bind9 start
fi

if [ -s /home/ubuntu/new_gre_host.txt ]
then
        rm -f /home/ubuntu/new_gre_host.txt
fi

