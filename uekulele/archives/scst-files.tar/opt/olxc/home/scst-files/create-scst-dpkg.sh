#!/bin/bash
#
#    Copyright 2015-2021 Gilbert Standen
#    This file is part of Orabuntu-LXC.

#    Orabuntu-LXC is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-LXC is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with Orabuntu-LXC.  If not, see <http://www.gnu.org/licenses/>.

#    v2.4 		GLS 20151224
#    v2.8 		GLS 20151231
#    v3.0 		GLS 20160710 Updates for Ubuntu 16.04
#    v4.0 		GLS 20161025 DNS DHCP services moved into an LXC container
#    v5.0 		GLS 20170909 Orabuntu-LXC Multi-Host
#    v6.0-AMIDE-beta	GLS 20180106 Orabuntu-LXC AmazonS3 Multi-Host Docker Enterprise Edition (AMIDE)
#    v7.0-ELENA-beta    GLS 20210428 Enterprise LXD Edition New AMIDE

#    Note that this software builds a containerized DNS DHCP solution (bind9 / isc-dhcp-server).
#    The nameserver should NOT be the name of an EXISTING nameserver but an arbitrary name because this software is CREATING a new LXC-containerized nameserver.
#    The domain names can be arbitrary fictional names or they can be a domain that you actually own and operate.
#    There are two domains and two networks because the "seed" LXC containers are on a separate network from the production LXC containers.
#    If the domain is an actual domain, you will need to change the subnet using the subnets feature of Orabuntu-LXC

clear

echo ''
echo "============================================================"
echo "Install additional packages required for DKMS build...      "
echo "============================================================"
echo '' 

function CheckAptProcessRunning {
	ps -ef | grep -v '_apt' | grep apt | grep -v grep | wc -l
}
AptProcessRunning=$(CheckAptProcessRunning)

while [ $AptProcessRunning -gt 0 ]
do
	echo 'Waiting for running apt update process(es) to finish...sleeping for 10 seconds'
	echo ''
	ps -ef | grep -v '_apt' | grep apt | grep -v grep
	sleep 10
	AptProcessRunning=$(CheckAptProcessRunning)
done

sudo apt-get -y install subversion dkms quilt debhelper devscripts

echo ''
echo "============================================================"
echo "Completed: Install DKMS additional packages.                "
echo "============================================================"
echo ''

sleep 5

clear

echo ''
echo "============================================================"
echo "Download Newest SCST source code...                         "
echo "============================================================"
echo '' 

sudo rm -rf scst-latest
if ! (git clone https://github.com/bvanassche/scst.git scst-latest)
then
        if ! (svn checkout svn://svn.code.sf.net/p/scst/svn/trunk scst-latest)
        then
                echo 'All SCST source download methods have failed. Please check your internet connection.'
                exit
        else
                echo 'SCST source successfully downloaded from sourceforge svn://svn.code.sf.net/p/scst/svn/trunk repository.'
	fi
else
        echo 'SCST source successfully downloaded from https://github.com/bvanassche/scst.git repository.'
fi

echo ''
echo "============================================================"
echo "Done: Download Newest SCST source code.                     "
echo "============================================================"
echo ''

sleep 5

clear

echo ''
echo "============================================================"
echo "Dynamic Discovery SCST Version and Rename Directory...      "
echo "============================================================"
echo '' 

echo 'DEBEMAIL="dpackager@anydomain.com"'       >> ~/.bash_aliases
echo 'DEBFULLNAME="Debbie Packager"'            >> ~/.bash_aliases
echo 'export DEBEMAIL DEBFULLNAME'              >> ~/.bash_aliases
source ~/.bash_aliases
env | grep DEB

function GetVersionString {
	cat scst-latest/usr/include/version.h | grep VERSION_STR | cut -f2 -d'"' | cut -f1 -d'-'
}
VersionString=$(GetVersionString)
echo "SCST Version:  $VersionString"

mv scst-latest scst-"$VersionString"
cd scst-"$VersionString"
make dpkg
cd dpkg
sudo dpkg -i iscsi-scst*.deb scst-dev*.deb scstadmin*.deb
sudo dpkg -i scst-dkms*.deb

echo ''
echo "============================================================"
echo "Completed:  Dynamic Discovery SCST Version and Rename Dir.  "
echo "============================================================"
echo ''

sleep 2

echo "============================================================"
echo "Perform post-installation actions (modprobe, etc)...        "
echo "============================================================"
echo '' 

sudo modprobe scst
sudo depmod
sudo modprobe iscsi-scst
if ! pgrep iscsi-scstd; then sudo iscsi-scstd; fi > /dev/null
sudo modprobe scst_vdisk
sudo modprobe scst_disk
sudo modprobe scst_user
sudo modprobe scst_modisk
sudo modprobe scst_processor
sudo modprobe scst_raid
sudo modprobe scst_tape
sudo modprobe scst_cdrom
sudo modprobe scst_changer
sudo modprobe iscsi-scst
sudo systemctl enable scst.service
sudo modprobe iscsi-scst
sudo systemctl enable scst.service
sudo service scst start
sudo scstadmin -write_config /etc/scst.conf

echo ''
echo "============================================================"
echo "Completed: Post-installation actions.                       "
echo "============================================================"

sleep 2

echo ''
echo "============================================================"
echo "Update File /etc/modules                                    "
echo "============================================================"
echo '' 

grep iscsi_scst /etc/modules
if [ $? -ne 0 ]
then
sudo sh -c "echo 'iscsi-scst'									>> /etc/modules"
fi
grep scst_vdisk /etc/modules
if [ $? -ne 0 ]
then
sudo sh -c "echo 'scst_vdisk'									>> /etc/modules"
fi
grep scst_disk /etc/modules
if [ $? -ne 0 ]
then
sudo sh -c "echo 'scst_disk'									>> /etc/modules"
fi
grep scst_user /etc/modules
if [ $? -ne 0 ]
then
sudo sh -c "echo 'scst_user'									>> /etc/modules"
fi
grep scst_moddisk /etc/modules
if [ $? -ne 0 ]
then
sudo sh -c "echo 'scst_modisk'									>> /etc/modules"
fi
grep scst_processor /etc/modules
if [ $? -ne 0 ]
then
sudo sh -c "echo 'scst_processor'								>> /etc/modules"
fi
grep scst_raid /etc/modules
if [ $? -ne 0 ]
then
sudo sh -c "echo 'scst_raid'									>> /etc/modules"
fi
grep scst_tape /etc/modules
if [ $? -ne 0 ]
then
sudo sh -c "echo 'scst_tape'									>> /etc/modules"
fi
grep scst_cdrom /etc/modules
if [ $? -ne 0 ]
then
sudo sh -c "echo 'scst_cdrom'									>> /etc/modules"
fi
grep scst_changer /etc/modules
if [ $? -ne 0 ]
then
sudo sh -c "echo 'scst_changer'									>> /etc/modules"
fi

cat /etc/modules

echo ''
echo "============================================================"
echo "Completed: Update File /etc/modules.                        "
echo "============================================================"

sleep 2

echo ''
echo "============================================================"
echo "Create Service: scst-san (start iscsi-scstd load scst.conf) "
echo "============================================================"
echo '' 

	sudo sh -c "echo '[Unit]'									>  /etc/systemd/system/scst-san.service"
	sudo sh -c "echo 'Description=SCST SAN Service'							>> /etc/systemd/system/scst-san.service"
	sudo sh -c "echo 'After=scst.service'								>> /etc/systemd/system/scst-san.service"
	sudo sh -c "echo ''										>> /etc/systemd/system/scst-san.service"
	sudo sh -c "echo '[Service]'									>> /etc/systemd/system/scst-san.service"
	sudo sh -c "echo 'Type=oneshot'									>> /etc/systemd/system/scst-san.service"
	sudo sh -c "echo 'ExecStart=/usr/bin/sudo /usr/sbin/iscsi-scstd'				>> /etc/systemd/system/scst-san.service"
	sudo sh -c "echo 'ExecStart=/usr/bin/sudo /usr/sbin/scstadmin -config /etc/scst.conf'		>> /etc/systemd/system/scst-san.service"
	sudo sh -c "echo 'ExecStart=/etc/network/openvswitch/strt_scst.sh'				>> /etc/systemd/system/scst-san.service"
	sudo sh -c "echo 'RemainAfterExit=true'								>> /etc/systemd/system/scst-san.service"
# 	sudo sh -c "echo 'ExecStop=/usr/bin/sudo /bin/kill -9 /usr/sbin/iscsi-scstd'			>> /etc/systemd/system/scst-san.service"
	sudo sh -c "echo 'ExecStop=/usr/bin/sudo /etc/network/openvswitch/stop_scst.sh'			>> /etc/systemd/system/scst-san.service"
	sudo sh -c "echo 'StandardOutput=journal'							>> /etc/systemd/system/scst-san.service"
	sudo sh -c "echo ''										>> /etc/systemd/system/scst-san.service"
	sudo sh -c "echo '[Install]'									>> /etc/systemd/system/scst-san.service"
	sudo sh -c "echo 'WantedBy=multi-user.target'							>> /etc/systemd/system/scst-san.service"

	sudo chmod 644 /etc/systemd/system/scst-san.service
	sudo systemctl enable scst-san.service
	cat /etc/systemd/system/scst-san.service

echo ''
echo "============================================================"
echo "Completed: Create Service scst-san                          "
echo "============================================================"

sleep 2

echo ''
echo "=============================================="
echo "Run a few checks on SCST now...               "
echo "=============================================="
echo ''
ps -ef | grep scst
echo ''
lsmod | grep scst
echo ''
cat /etc/modules
echo ''
sudo service scst status
echo ''

sleep 10

echo "=============================================="
echo "Completed:  Run SCST checks.                  "
echo "=============================================="
echo ''

