#!/bin/bash

#    Copyright 2015-2021 Gilbert Standen
#    This file is part of Orabuntu-LXC.

#    Orabuntu-LXC is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-LXC is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with Orabuntu-LXC.  If not, see <http://www.gnu.org/licenses/>.

# OpenvSwitch service for Oracle Linux 6 and similar non-systemd linuxes
#
# chkconfig:   345 10 94
# description: SCST script
#

### BEGIN INIT INFO
# Provides:
# Required-Start:
# Required-Stop:
# Should-Start:
# Should-Stop:
# Default-Start:
# Default-Stop:
# Short-Description:
# Description:
### END INIT INFO

# Source function library.

start() {
    /etc/init.d/scst start
    iscsiadm -m discovery -t sendtargets --portal 127.0.0.1 > /dev/null 2>&1
    iscsiadm -m node --login > /dev/null 2>&1
    udevadm control --reload-rules && udevadm trigger
}

stop() {
    iscsiadm -m node --logout
    /etc/init.d/scst stop
    multipath -F
}

restart() {
    stop
    start
}

status() {
    service scst status
}

case "$1" in
    start)
        start
        $1
        ;;
    stop)
        stop
        $1
        ;;
    restart)
        restart
        ;;
    status)
        status
        ;;
    *)
        echo $"Usage: $0 {start|stop|restart|status}"
        exit 2
esac
exit $?

