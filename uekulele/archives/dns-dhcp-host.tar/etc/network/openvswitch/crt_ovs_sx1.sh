#!/bin/bash

#    Copyright 2015-2017 Gilbert Standen
#    This file is part of Orabuntu-LXC.

#    Orabuntu-LXC is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-LXC is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with Orabuntu-LXC.  If not, see <http://www.gnu.org/licenses/>.

#    v2.4 GLS 20151224
#    v2.8 GLS 20151231
#    v3.0 GLS 20160710 Updates for Ubuntu 16.04
#    v4.0 GLS 20161025 DNS DHCP services moved into an LXC container
#    v5.0 GLS 20170909 Orabuntu-LXC MultiHost

#    Note that Orabuntu-LXC v5.0  builds a conntainerized DNS DHCP solution for the Desktop or Enterprise environment.
#    The nameserver should NOT be the name of an EXISTING nameserver but an arbitrary name because this software is CREATING a new LXC-containerized nameserver.
#    The domain names can be arbitrary fictional names or they can be a domain that you actually own and operate.
#    There are two domains and two networks because the "seed" LXC containers are on a separate network and domain from the production LXC containers.

# GLS 20170916 Auxiliary Ports and Patch Port
# Port a1 is reserved for patch port to switch sw1 for multihost traffic over GRE tunnel
# Other aX ports can be used for VM's or for any other purpose (ports a2, a3 are default auxiliary ports - you can add more here)

GetLinuxFlavors(){
if   [[ -e /etc/oracle-release ]]
then
        LinuxFlavors=$(cat /etc/oracle-release | cut -f1 -d' ')
elif [[ -e /etc/redhat-release ]]
then
        LinuxFlavors=$(cat /etc/redhat-release | cut -f1 -d' ')
elif [[ -e /usr/bin/lsb_release ]]
then
        LinuxFlavors=$(lsb_release -d | awk -F ':' '{print $2}' | cut -f1 -d' ')
elif [[ -e /etc/issue ]]
then
        LinuxFlavors=$(cat /etc/issue | cut -f1 -d' ')
else
        LinuxFlavors=$(cat /proc/version | cut -f1 -d' ')
fi
}
GetLinuxFlavors

function TrimLinuxFlavors {
echo $LinuxFlavors | sed 's/^[ \t]//;s/[ \t]$//'
}
LinuxFlavor=$(TrimLinuxFlavors)

if   [ $LinuxFlavor = 'Oracle' ]
then
        function GetOracleDistroRelease {
                sudo cat /etc/oracle-release | cut -f5 -d' ' | cut -f1 -d'.'
        }
        OracleDistroRelease=$(GetOracleDistroRelease)
        Release=$OracleDistroRelease
        LF=$LinuxFlavor
        RL=$Release
elif [ $LinuxFlavor = 'Red' ]
then
        function GetRedHatVersion {
                sudo cat /etc/redhat-release | cut -f7 -d' ' | cut -f1 -d'.'
        }
        RedHatVersion=$(GetRedHatVersion)
        Release=$RedHatVersion
        LF=$LinuxFlavor'Hat'
        RL=$Release
fi

  ovs-vsctl --may-exist add-br sx1

# GLS 20140825 Get active external interface dynamically at boot.  Tested & works with {wlan0, eth0, bnep0} on Ubuntu 14.04.1 Desktop x86_64.
# GLS 20140825 Interface "bnep0" is Blackberry Z30 OS10 Bluetooth Tether.
# GLs 20151219 Added enp / wlp to support Ubuntu 15.10 Wily Werewolf and higher releases.

### BEGIN Get Active EXTIF Dynamcially. ###

function GetInterface
{
ifconfig | egrep -B1 'inet' | egrep -A1 'enp|wlp|wlan|eth|bnep' | sed '$!N;s/\n/ /' | sed 's/  */ /g' | cut -f1,7 -d' ' | sed 's/ addr//' | head -1 | cut -f1 -d':'
}
Interface=$(GetInterface)
function GetIP
{
ifconfig | grep -A1 $Interface | grep inet | sed '$!N;s/\n/ /' | sed 's/  */ /g' | cut -f3 -d' '
}

### END Get active EXTIF dynamically. ###

  function GetInterfaceMtu {
        ifconfig $Interface | grep mtu | rev | cut -f1 -d' ' | rev
  }
  InterfaceMtu=$(GetInterfaceMtu)

  function CheckGreTunnelExist {
        sudo ovs-vsctl show | grep type | grep gre | cut -f2 -d':' | sed 's/^[ \t]*//;s/[ \t]*$//'
  }
  GreTunnelExist=$(CheckGreTunnelExist)

  function CheckGreTunnelStringLen {
        sudo ovs-vsctl show | grep type | grep gre | cut -f2 -d':' | sed 's/^[ \t]*//;s/[ \t]*$//' | wc -l
  }
  GreTunnelStringLen=$(CheckGreTunnelStringLen)

  function GetConfigCount {
        ls -l /var/lib/lxc |  wc -l
  }
  ConfigCount=$(GetConfigCount)

  if [ $GreTunnelStringLen -gt 0 ] && [ $ConfigCount -gt 0 ]
  then
        if [ $GreTunnelExist = 'gre' ]
        then
                MtuSetting=1420
 		sed -i "/lxc.network.mtu =/c lxc.network.mtu = $MtuSetting" /var/lib/lxc/*/config
        fi
  else
        MtuSetting=$InterfaceMtu
 	sed -i "/lxc.network.mtu =/c lxc.network.mtu = $MtuSetting" /var/lib/lxc/*/config
  fi

  ip tuntap add a1 mode tap 
# ip tuntap add a2 mode tap 
# ip tuntap add a3 mode tap 

  ip link set a1 up mtu $MtuSetting
# ip link set a2 up mtu $MtuSetting
# ip link set a3 up mtu $MtuSetting

  ovs-vsctl --may-exist add-port sx1 a1
# ovs-vsctl --may-exist add-port sx1 a2
# ovs-vsctl --may-exist add-port sx1 a3

  ip link set up dev sx1
  ip addr add 10.207.29.SWITCH_IP/24 dev sx1
  ip route replace 10.207.29.0/24 dev sx1

  ovs-vsctl set port sx1 tag=11
  ovs-vsctl set port  a1 tag=11

# GLS 20170916 Patch Ports allow UDP and TCP traffic on sx1 10.207.29.0/24 subnet to go over the GRE tunnel attached to sw1 on 10.207.39.0/24 network
  ovs-vsctl set interface a1 type=patch
  ovs-vsctl set interface a1 options:peer=s1

  echo '       IP: '$(GetIP)
  echo 'Interface: '$(GetInterface)
  echo '      MTU: '$MtuSetting

  INTIF="sx1"
  EXTIF=$(GetInterface)

  echo 1 > /proc/sys/net/ipv4/ip_forward

### BEGIN manage iptables rules ###

# clear existing iptable rules, set a default policy
# When used by the sw1/sx1 combo, do NOT uncomment these lines.
# The sw1 switch takes care of implementing these before sx1 runs.
# iptables -P INPUT ACCEPT
# iptables -F INPUT 
# iptables -P OUTPUT ACCEPT
# iptables -F OUTPUT 
# iptables -P FORWARD DROP
# iptables -F FORWARD 
# iptables -t nat -F

function CheckIptablesRulesCount {
	iptables -S | grep FORWARD | grep sx1 | wc -l
}
IptablesRulesCount=$(CheckIptablesRulesCount)

while [ $IptablesRulesCount -ne 0 ]
do
	iptables -D FORWARD -i $EXTIF -o $INTIF -j ACCEPT > /dev/null 2>&1
	iptables -D FORWARD -i $INTIF -o $EXTIF -j ACCEPT > /dev/null 2>&1
	IptablesRulesCount=$(CheckIptablesRulesCount)
done

# set forwarding and nat rules
  iptables -A FORWARD -i $EXTIF -o $INTIF -j ACCEPT
  iptables -A FORWARD -i $INTIF -o $EXTIF -j ACCEPT
  iptables -t nat -A POSTROUTING -o $EXTIF -j MASQUERADE

### END  manage iptables rules ###

# service dhcpd restart # DNS and DHCP services have been moved to an LXC container.
# service named restart # DNS and DHCP services have been moved to an LXC container.
