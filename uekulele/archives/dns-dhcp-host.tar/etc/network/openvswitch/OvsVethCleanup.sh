
# Service to clean up abandoned veth ports

function GetAbandonedVeth {
		sudo ovs-vsctl show | grep -B1 error | grep veth | grep Interface | rev | cut -f1 -d' ' | rev | sed 's/"//g'
}
AbandonedVeth=$(GetAbandonedVeth)

for i in $AbandonedVeth
do
	echo $i
	sudo ovs-vsctl del-port $i
	sudo ip link del $i
done

