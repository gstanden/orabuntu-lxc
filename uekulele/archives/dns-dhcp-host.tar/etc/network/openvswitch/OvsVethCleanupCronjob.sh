#!/bin/bash
cat > /etc/cron.d/OvsVethCleanup << EOF
SHELL=/bin/bash
PATH=/sbin:/bin:/usr/sbin:/usr/bin
MAILTO=root HOME=/
*/5 * * * * root /etc/network/openvswitch/OvsVethCleanup.sh
EOF

