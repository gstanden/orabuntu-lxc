#!/bin/bash

clear

function CheckSwitchMtu {
	ifconfig | grep mtu | egrep 'sw1|sx1' | grep 1420 | wc -l
}
SwitchMtu=$(CheckSwitchMtu)

echo ''
echo "=============================================="
echo "Prepare LXC container for nameserver...        "
echo "=============================================="
echo ''

sudo lxc-stop    -n "NAMESERVER"
sudo lxc-stop    -n "NAMESERVER"-s3
sudo lxc-destroy -n "NAMESERVER"-s3
sudo lxc-copy    -n "NAMESERVER" -N "NAMESERVER"-s3
sudo lxc-destroy -n "NAMESERVER"

echo ''
echo "=============================================="
echo "Done: Prepare LXC container for nameserver.   "
echo "=============================================="
echo ''

sleep 5

clear

echo ''
echo "=============================================="
echo "Create LXC container for nameserver...        "
echo "=============================================="
echo ''

sudo lxc-create -t download -n NAMESERVER -- --dist ubuntu --release xenial --arch amd64
sudo lxc-update-config -c /var/lib/lxc/NAMESERVER/config

if [ $SwitchMtu -eq 2 ]
then
	sudo sed -i 's/1500/1420/g'  /var/lib/lxc/NAMESERVER/config
fi

echo ''
echo "=============================================="
echo "Done: Create LXC container for nameserver.    "
echo "=============================================="

sleep 5

clear

echo ''
echo "=============================================="
echo "Install required files...                     "
echo "=============================================="
echo ''

sudo tar -vP --extract --file=dns-dhcp-cont.tar /var/lib/lxc/nsa/rootfs/etc/network/interfaces
sudo tar -vP --extract --file=dns-dhcp-cont.tar /var/lib/lxc/nsa/rootfs/root/ns_backup_update.sh
sudo tar -vP --extract --file=dns-dhcp-cont.tar /var/lib/lxc/nsa/rootfs/root/ns_backup_update.lst
sudo tar -vP --extract --file=dns-dhcp-cont.tar /var/lib/lxc/nsa/rootfs/root/ns_backup.start.sh
sudo tar -vP --extract --file=dns-dhcp-cont.tar /var/lib/lxc/nsa/rootfs/root/crontab.txt

sudo tar -vP --extract --file=dns-dhcp-host.tar /var/lib/lxc/nsa/config

sudo tar -vP --extract --file=dns-dhcp-host.tar /etc/network/if-up.d/openvswitch/nsa-pub-ifup-sw1
sudo tar -vP --extract --file=dns-dhcp-host.tar /etc/network/if-down.d/openvswitch/nsa-pub-ifdown-sw1
sudo tar -vP --extract --file=dns-dhcp-host.tar /etc/network/if-up.d/openvswitch/nsa-pub-ifup-sx1
sudo tar -vP --extract --file=dns-dhcp-host.tar /etc/network/if-down.d/openvswitch/nsa-pub-ifdown-sx1

sudo mv /etc/network/if-up.d/openvswitch/nsa-pub-ifup-sw1	/etc/network/if-up.d/openvswitch/NAMESERVER-pub-ifup-sw1
sudo mv /etc/network/if-down.d/openvswitch/nsa-pub-ifdown-sw1	/etc/network/if-down.d/openvswitch/NAMESERVER-pub-ifdown-sw1
sudo mv /etc/network/if-up.d/openvswitch/nsa-pub-ifup-sx1	/etc/network/if-up.d/openvswitch/NAMESERVER-pub-ifup-sx1
sudo mv /etc/network/if-down.d/openvswitch/nsa-pub-ifdown-sx1	/etc/network/if-down.d/openvswitch/NAMESERVER-pub-ifdown-sx1

sudo mv /var/lib/lxc/nsa/rootfs/etc/network/interfaces		/var/lib/lxc/NAMESERVER/rootfs/etc/network/interfaces
sudo mv /var/lib/lxc/nsa/config					/var/lib/lxc/NAMESERVER/config

sudo sed -i "/orabuntu-lxc\.com/s/orabuntu-lxc\.com/DOMAIN1/g"				/var/lib/lxc/NAMESERVER/rootfs/etc/network/interfaces
sudo sed -i "/consultingcommandos\.us/s/consultingcommandos\.us/DOMAIN2/g"		/var/lib/lxc/NAMESERVER/rootfs/etc/network/interfaces
sudo sed -i "/nsa/s/nsa/NAMESERVER/g" 							/var/lib/lxc/NAMESERVER/config
sudo sed -i "s/nsa/NAMESERVER/g'							/var/lib/lxc/nsa/rootfs/root/ns_backup_update.sh
sudo sed -i "s/nsa/NAMESERVER/g'							/var/lib/lxc/nsa/rootfs/root/ns_backup_update.lst
sudo sed -i "s/nsa/NAMESERVER/g'							/var/lib/lxc/nsa/rootfs/root/ns_backup.start.sh
sudo sed -i "s/nsa/NAMESERVER/g'							/var/lib/lxc/nsa/rootfs/root/crontab.txt

sudo mv /var/lib/lxc/nsa/rootfs/root/ns_backup_update.sh 	/var/lib/lxc/NAMESERVER/rootfs/root/ns_backup_update.sh
sudo mv /var/lib/lxc/nsa/rootfs/root/ns_backup.start.sh 	/var/lib/lxc/NAMESERVER/rootfs/root/ns_backup.start.sh
sudo mv /var/lib/lxc/nsa/rootfs/root/ns_backup_update.lst 	/var/lib/lxc/NAMESERVER/rootfs/root/ns_backup_update.lst
sudo mv /var/lib/lxc/nsa/rootfs/root/crontab.txt 		/var/lib/lxc/NAMESERVER/rootfs/root/crontab.txt

echo ''
echo "=============================================="
echo "Done: Install required files.                 "
echo "=============================================="

sleep 5

clear

echo ''
echo "=============================================="
echo "Start NAMESERVER nameserver...               "
echo "=============================================="
echo ''

sudo lxc-update-config -c /var/lib/lxc/NAMESERVER/config
sudo lxc-start  -n NAMESERVER
sudo lxc-info   -n NAMESERVER

echo ''
echo "=============================================="
echo "Done: Start NAMESERVER nameserver.           "
echo "=============================================="

sleep 5

clear

echo ''
echo "=============================================="
echo "Install required packages...                  "
echo "=============================================="
echo ''

if [ $SwitchMtu -eq 2 ]
then
	sudo ifconfig NAMESERVERw mtu 1420
	sudo ifconfig NAMESERVERx mtu 1420
	sudo lxc-attach -n NAMESERVER -- ifconfig eth0 mtu 1420
	sudo lxc-attach -n NAMESERVER -- ifconfig eth1 mtu 1420
fi

sudo lxc-attach -n NAMESERVER -- sudo apt-get -y update
sudo lxc-attach -n NAMESERVER -- sudo apt-get -y install bind9 isc-dhcp-server bind9utils dnsutils openssh-server awscli

echo ''
echo "=============================================="
echo "Done: Install required packages.              "
echo "=============================================="

sleep 5

clear

sudo tar -vP --extract --file=/home/ubuntu/Downloads/orabuntu-lxc-master/orabuntu/archives/dns-dhcp-cont.tar /var/lib/lxc/nsa/rootfs/root/crontab.txt
sudo tar -vP --extract --file=/home/ubuntu/Downloads/orabuntu-lxc-master/orabuntu/archives/dns-dhcp-cont.tar /var/lib/lxc/nsa/rootfs/root/ns_backup_update.lst
sudo tar -vP --extract --file=/home/ubuntu/Downloads/orabuntu-lxc-master/orabuntu/archives/dns-dhcp-cont.tar /var/lib/lxc/nsa/rootfs/root/ns_backup_update.sh
sudo tar -vP --extract --file=/home/ubuntu/Downloads/orabuntu-lxc-master/orabuntu/archives/dns-dhcp-cont.tar /var/lib/lxc/nsa/rootfs/root/ns_backup.start.sh

sudo sed -i "s/nsa/NAMESERVER/g" /var/lib/lxc/NAMESERVER/rootfs/ns_backup*

sudo mv /var/lib/lxc/nsa/rootfs/root/ns_backup_update.lst /var/lib/lxc/NAMESERVER/rootfs/root/ns_backup_update.lst
sudo mv /var/lib/lxc/nsa/rootfs/root/ns_backup_update.sh  /var/lib/lxc/NAMESERVER/rootfs/root/ns_backup_update.sh
sudo mv /var/lib/lxc/nsa/rootfs/root/ns_backup.start.sh   /var/lib/lxc/NAMESERVER/rootfs/root/ns_backup.start.sh
sudo mv /var/lib/lxc/nsa/rootfs/root/crontab.txt          /var/lib/lxc/NAMESERVER/rootfs/root/crontab.txt

mkdir -p /home/ubuntu/Downloads/Manage-Orabuntu/backup-lxc-container/NAMESERVER/updates

sleep 5

clear

echo ''
echo "=============================================="
echo "Download zones from Amazon S3...              "
echo "=============================================="
echo ''

aws s3 sync s3://backup-lxc-container/NAMESERVER/ /home/ubuntu/Downloads/Manage-Orabuntu/backup-lxc-container/NAMESERVER

sleep 5

clear

echo ''
echo "=============================================="
echo "Done: Download zones from Amazon S3.          "
echo "=============================================="

sleep 5

clear

echo ''
echo "=============================================="
echo "Restore bind9 & isc-dhcp-server files...      "
echo "=============================================="
echo ''

sudo mkdir -p /var/lib/lxc/NAMESERVER/rootfs/backup-lxc-container/NAMESERVER
sudo cp -p /home/ubuntu/Downloads/Manage-Orabuntu/backup-lxc-container/NAMESERVER/backup_NAMESERVER_ns.tar.gz /var/lib/lxc/NAMESERVER/rootfs/backup-lxc-container/NAMESERVER/.

sudo tar -vzP --extract --file=/home/ubuntu/Manage-Orabuntu/backup-lxc-container/NAMESERVER/backup_NAMESERVER_ns.tar.gz /var/lib/lxc/NAMESERVER/rootfs/etc/bind/named.conf
sudo tar -vzP --extract --file=/home/ubuntu/Manage-Orabuntu/backup-lxc-container/NAMESERVER/backup_NAMESERVER_ns.tar.gz /var/lib/lxc/NAMESERVER/rootfs/etc/bind/named.conf.local
sudo tar -vzP --extract --file=/home/ubuntu/Manage-Orabuntu/backup-lxc-container/NAMESERVER/backup_NAMESERVER_ns.tar.gz /var/lib/lxc/NAMESERVER/rootfs/etc/bind/named.conf.options
sudo tar -vzP --extract --file=/home/ubuntu/Manage-Orabuntu/backup-lxc-container/NAMESERVER/backup_NAMESERVER_ns.tar.gz /var/lib/lxc/NAMESERVER/rootfs/etc/bind/rndc.key
sudo tar -vzP --extract --file=/home/ubuntu/Manage-Orabuntu/backup-lxc-container/NAMESERVER/backup_NAMESERVER_ns.tar.gz /var/lib/lxc/NAMESERVER/rootfs/etc/default/bind9
sudo tar -vzP --extract --file=/home/ubuntu/Manage-Orabuntu/backup-lxc-container/NAMESERVER/backup_NAMESERVER_ns.tar.gz /var/lib/lxc/NAMESERVER/rootfs/etc/default/isc-dhcp-server
sudo tar -vzP --extract --file=/home/ubuntu/Manage-Orabuntu/backup-lxc-container/NAMESERVER/backup_NAMESERVER_ns.tar.gz /var/lib/lxc/NAMESERVER/rootfs/etc/dhcp/dhcpd.conf
sudo tar -vzP --extract --file=/home/ubuntu/Manage-Orabuntu/backup-lxc-container/NAMESERVER/backup_NAMESERVER_ns.tar.gz /var/lib/lxc/NAMESERVER/rootfs/etc/network/interfaces
sudo tar -vzP --extract --file=/home/ubuntu/Manage-Orabuntu/backup-lxc-container/NAMESERVER/backup_NAMESERVER_ns.tar.gz /var/lib/lxc/NAMESERVER/rootfs/var/lib/bind/fwd.DOMAIN1
sudo tar -vzP --extract --file=/home/ubuntu/Manage-Orabuntu/backup-lxc-container/NAMESERVER/backup_NAMESERVER_ns.tar.gz /var/lib/lxc/NAMESERVER/rootfs/var/lib/bind/fwd.DOMAIN2
sudo tar -vzP --extract --file=/home/ubuntu/Manage-Orabuntu/backup-lxc-container/NAMESERVER/backup_NAMESERVER_ns.tar.gz /var/lib/lxc/NAMESERVER/rootfs/var/lib/bind/rev.DOMAIN1
sudo tar -vzP --extract --file=/home/ubuntu/Manage-Orabuntu/backup-lxc-container/NAMESERVER/backup_NAMESERVER_ns.tar.gz /var/lib/lxc/NAMESERVER/rootfs/var/lib/bind/rev.DOMAIN2
sudo tar -vzP --extract --file=/home/ubuntu/Manage-Orabuntu/backup-lxc-container/NAMESERVER/backup_NAMESERVER_ns.tar.gz /var/lib/lxc/NAMESERVER/rootfs/var/lib/dhcp/dhcpd.leases
sudo tar -vzP --extract --file=/home/ubuntu/Manage-Orabuntu/backup-lxc-container/NAMESERVER/backup_NAMESERVER_ns.tar.gz /var/lib/lxc/NAMESERVER/rootfs/var/lib/dhcp/dhcpd.leases~

echo ''
echo "=============================================="
echo "Done: Restore bind9 & isc-dhcp-server files.  "
echo "=============================================="
echo ''

sleep 5

clear

echo ''
echo "=============================================="
echo "Start bind9 & isc-dhcp-server...              "
echo "=============================================="
echo ''

sudo lxc-attach -n NAMESERVER -- sudo service isc-dhcp-server start
sudo lxc-attach -n NAMESERVER -- sudo service bind9 start

echo "=============================================="
echo "DNS status...                                 "
echo "=============================================="
echo ''

sudo lxc-attach -n NAMESERVER -- sudo service bind9 status

echo ''
echo "=============================================="
echo "DHCP status...                                "
echo "=============================================="
echo ''

sudo lxc-attach -n NAMESERVER -- sudo service isc-dhcp-server status

echo ''
echo "=============================================="
echo "Done: Start bind9 & isc-dhcp-server.          "
echo "=============================================="

sleep 5

clear

echo ''
echo "=============================================="
echo "Check NAMESERVER nameserver...               "
echo "=============================================="
echo ''

echo '###'
sudo lxc-attach -n NAMESERVER -- nslookup NAMESERVER
echo '###'
nslookup NAMESERVER
echo '###'

echo ''
echo "=============================================="
echo "Done: Check NAMESERVER nameserver.           "
echo "=============================================="
echo ''

sleep 5

clear

echo ''
echo "=============================================="
echo "Set NAMESERVER ubuntu password...                  "
echo "=============================================="
echo ''

sudo lxc-attach -n NAMESERVER -- usermod --password `perl -e "print crypt('ubuntu','ubuntu');"` ubuntu

echo ''
echo "=============================================="
echo "Done: Set NAMESERVER ubuntu password.              "
echo "=============================================="
echo ''

sleep 5

clear

echo ''
echo "=============================================="
echo "Set NAMESERVER crontab...                     "
echo "=============================================="
echo ''

sudo lxc-attach -n NAMESERVER -- crontab /root/crontab.txt

echo ''
echo "=============================================="
echo "Done: Set NAMESERVER crontab.                 "
echo "=============================================="
echo ''
