sudo sed -i '/route add -net/s/#/ /g'               /etc/network/openvswitch/crt_ovs_sw1.sh >/dev/null 2>&1
# sudo sed -i '/REMOTE_GRE_ENDPOINT/s/#/ /' 	    /etc/network/openvswitch/crt_ovs_sw1.sh >/dev/null 2>&1
sudo sed -i "s/REMOTE_GRE_ENDPOINT/MultiHostVar6/g" /etc/network/openvswitch/crt_ovs_sw1.sh >/dev/null 2>&1
# sudo sed -i "s/MHV6/MultiHostVar6/g" /etc/network/openvswitch/crt_ovs_sw1.sh >/dev/null 2>&1
sudo ovs-vsctl del-port greMultiHostVar3 >/dev/null 2>&1
sudo ovs-vsctl add-port sw1 greMultiHostVar3    trunks=10,11 -- set interface greMultiHostVar3    type=gre    options:remote_ip=MultiHostVar6
sudo ovs-vsctl add-port sw1 geneveMultiHostVar3 trunks=10,11 -- set interface geneveMultiHostVar3 type=geneve options:remote_ip=MultiHostVar6 options:key=flow
sudo ovs-vsctl add-port sw1 vxlanMultiHostVar3  trunks=10,11 -- set interface vxlanMultiHostVar3  type=vxlan  options:remote_ip=MultiHostVar6 options:key=flow
sudo sh -c "echo 'sudo ovs-vsctl add-port sw1 geneveMultiHostVar3 trunks=10,11 -- set interface geneveMultiHostVar3 type=geneve options:remote_ip=MultiHostVar6 options:key=flow' >> /etc/network/openvswitch/crt_ovs_sw1.sh"
sudo sh -c "echo 'sudo ovs-vsctl add-port sw1 vxlanMultiHostVar3  trunks=10,11 -- set interface vxlanMultiHostVar3  type=vxlan  options:remote_ip=MultiHostVar6 options:key=flow' >> /etc/network/openvswitch/crt_ovs_sw1.sh"
sudo sh -c "echo 'sudo ovs-vsctl add-port sw1 greMultiHostVar3    trunks=10,11 -- set interface greMultiHostVar3    type=gre    options:remote_ip=MultiHostVar6' 		  >> /etc/network/openvswitch/crt_ovs_sw1.sh"
sudo firewall-cmd --permanent --zone=public --add-port=6081/udp
sudo firewall-cmd --permanent --zone=public --add-interface=genev_sys_6081
sudo firewall-cmd --permanent --zone=public --add-port=4789/udp
sudo firewall-cmd --permanent --zone=public --add-interface=vxlan_sys_4789
sudo firewall-cmd --permanent --zone=public --add-protocol=gre
sudo firewall-cmd --permanent --zone=public --add-interface=gre_sys
sudo firewall-cmd --reload
exit

