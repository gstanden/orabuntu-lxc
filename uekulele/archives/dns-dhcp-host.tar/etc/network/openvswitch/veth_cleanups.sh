#!/bin/bash

Container=$1

sudo ip link del "$Container"       
sudo ip link del "$Container-priv1"
sudo ip link del "$Container-priv2"
sudo ip link del "$Container-priv3"
sudo ip link del "$Container-priv4"
sudo ip link del "$Container-asm1"
sudo ip link del "$Container-asm2"

