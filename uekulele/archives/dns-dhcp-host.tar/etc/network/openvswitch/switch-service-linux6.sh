#!/bin/sh
#
# OpenvSwitch service for Oracle Linux 6 and similar non-systemd linuxes
#
# chkconfig:   345 10 94
# description: openvswitch script
#

### BEGIN INIT INFO
# Provides:
# Required-Start:
# Required-Stop:
# Should-Start:
# Should-Stop:
# Default-Start:
# Default-Stop:
# Short-Description:
# Description:
### END INIT INFO

# Source function library.

start() {
    /etc/network/openvswitch/crt_ovs_SWK.sh >/dev/null 2>&1
}

stop() {
    /usr/bin/ovs-vsctl del-br SWK
}

restart() {
    stop
    start
}

status() {
    /sbin/ip link show SWK
}

case "$1" in
    start)
        start
        $1
        ;;
    stop)
        stop
        $1
        ;;
    restart)
        restart
        ;;
    status)
        status
        ;;
    *)
        echo $"Usage: $0 {start|stop|restart|status}"
        exit 2
esac
exit $?

