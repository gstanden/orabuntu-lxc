#!/bin/bash

#    Copyright 2015-2017 Gilbert Standen
#    This file is part of Orabuntu-LXC.

#    Orabuntu-LXC is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-LXC is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with Orabuntu-LXC.  If not, see <http://www.gnu.org/licenses/>.

#    v2.4 GLS 20151224
#    v2.8 GLS 20151231
#    v3.0 GLS 20160710 Updates for Ubuntu 16.04
#    v4.0 GLS 20161025 DNS DHCP services moved into an LXC container
#    v5.0 GLS 20170909 Orabuntu-LXC MultiHost
#    v5.3 GLS 20171209 Orabuntu-LXC MultiHost Docker S3

#    Note that Orabuntu-LXC v5.0  builds a conntainerized DNS DHCP solution for the Desktop or Enterprise environment.
#    The nameserver should NOT be the name of an EXISTING nameserver but an arbitrary name because this software is CREATING a new LXC-containerized nameserver.
#    The domain names can be arbitrary fictional names or they can be a domain that you actually own and operate.
#    There are two domains and two networks because the "seed" LXC containers are on a separate network and domain from the production LXC containers.

# GLS 20170916 Auxiliary Ports and Patch Port
# Port s1 is reserved for patch port to switch sw1 for multihost traffic over GRE tunnel from the seed container network.
# Other sX ports can be used for VM's or for any other purpose: ports {s2,s3,s4...} are default auxiliary ports.

GetLinuxFlavors(){
if   [[ -e /etc/oracle-release ]]
then
        LinuxFlavors=$(cat /etc/oracle-release | cut -f1 -d' ')
elif [[ -e /etc/redhat-release ]]
then
        LinuxFlavors=$(cat /etc/redhat-release | cut -f1 -d' ')
elif [[ -e /usr/bin/lsb_release ]]
then
        LinuxFlavors=$(lsb_release -d | awk -F ':' '{print $2}' | cut -f1 -d' ')
elif [[ -e /etc/issue ]]
then
        LinuxFlavors=$(cat /etc/issue | cut -f1 -d' ')
else
        LinuxFlavors=$(cat /proc/version | cut -f1 -d' ')
fi
}
GetLinuxFlavors

function TrimLinuxFlavors {
echo $LinuxFlavors | sed 's/^[ \t]//;s/[ \t]$//'
}
LinuxFlavor=$(TrimLinuxFlavors)

if   [ $LinuxFlavor = 'Oracle' ]
then
	function GetOracleDistroRelease {
		sudo cat /etc/oracle-release | cut -f5 -d' ' | cut -f1 -d'.'
	}
	OracleDistroRelease=$(GetOracleDistroRelease)
	Release=$OracleDistroRelease
	LF=$LinuxFlavor
	RL=$Release
elif [ $LinuxFlavor = 'Red' ]
then
	function GetRedHatVersion {
		sudo cat /etc/redhat-release | cut -f7 -d' ' | cut -f1 -d'.'
	}
	RedHatVersion=$(GetRedHatVersion)
	Release=$RedHatVersion 
	LF=$LinuxFlavor'Hat'
	RL=$Release
fi

  ovs-vsctl --may-exist add-br sw1

# GRE Tunnel
# sudo ovs-vsctl add-port sw1 greSWITCH_IP -- set interface greSWITCH_IP type=gre options:remote_ip=REMOTE_GRE_ENDPOINT

# Add routes for GRE tunneling of all switches
# route add -net 192.210.39.0/24 gw 10.207.39.SWITCH_IP dev sw1
# route add -net 192.211.39.0/24 gw 10.207.39.SWITCH_IP dev sw1
# route add -net 192.212.39.0/24 gw 10.207.39.SWITCH_IP dev sw1
# route add -net 192.213.39.0/24 gw 10.207.39.SWITCH_IP dev sw1
# route add -net 172.220.40.0/24 gw 10.207.39.SWITCH_IP dev sw1
# route add -net 172.221.40.0/24 gw 10.207.39.SWITCH_IP dev sw1
# route add -net 10.207.39.0/24  gw 10.207.39.SWITCH_IP dev sw1

# NameServer=NAMESERVER

# GLS 20140825 Get active external interface dynamically at boot.  Tested & works with {wlan0, eth0, bnep0} on Ubuntu 14.04.1 Desktop x86_64.
# GLS 20140825 Interface "bnep0" is for bluetooth tether (Blackberry, iPhone, Samsung, etc).
# GLS 20161117 Support was added previously for {wlp, enp}.
# GLS 20171004 Set MTU dynamically in the container config files.

  ### BEGIN Get active EXTIF dynamcally. ###

  INTIF="sw1"
  function GetSw1Ip {
	  ifconfig sw1 | grep inet | grep '10.207.39' | wc -l
  }

  Sw1Ip=$(GetSw1Ip)

  if [ $Sw1Ip -eq 0 ]
  then
	  function GetInterfaces {
	  	ifconfig | egrep 'enp|wlp|wlan|eth|bnep' | egrep -v 'ether|veth' | cut -f1 -d' ' | cut -f1 -d':' | sed 's/$/ /' | tr -d '\n' |  sed 's/^[ \t]*//;s/[ \t]*$//'
	  }
	  Interfaces=$(GetInterfaces)

	  for j in $Interfaces
	  do
		function GetOnVm {
       		 	ifconfig $j | grep inet | grep '10.207.39' | wc -l
		}
		OnVm=$(GetOnVm)

		if   [ $OnVm -eq 1 ]
       		then
	  		Interface=$j

			function GetIP {
				ifconfig | grep -A1 $Interface | grep inet | sed '$!N;s/\n/ /' | sed 's/  */ /g' | cut -f3 -d' ' | rev | cut -f1 -d':' | rev
  			}
			IP=$(GetIP)

  			function GetInterfaceMtu {
				ifconfig $Interface | grep -i mtu | sed 's/^[ \t]*//;s/[ \t]*$//' | sed 's/,/ /g' | cut -f6-9 -d' ' | sed 's/^[ \t]*//;s/[ \t]*$//' | sed 's/ /:/g' | cut -f1,2 -d':' | cut -f2 -d':'
			}
			InterfaceMtu=$(GetInterfaceMtu)

 		 	echo '       IP: '$(GetIP)
		 	echo 'Interface: '$Interface
			echo '      MTU: '$(GetInterfaceMtu)

			EXTIF=$Interface
			IP=$(GetIP)

			sudo sh -c "echo '$Interface:$IP:$InterfaceMtu' > /etc/network/openvswitch/sw1.info"
	
			ovs-vsctl add-port $INTIF $EXTIF
			ovs-vsctl set port $EXTIF tag=10
			ifconfig $EXTIF 0
			ifconfig $INTIF $IP netmask 255.255.255.0
			route add default gw 10.207.39.1 sw1
			ip link set sw1 up
		fi
	done
  fi

  Sw1Ip=$(GetSw1Ip)

  if [ $Sw1Ip -eq 0 ] && [ -f /etc/network/openvswitch/sw1.info ]
  then
	function GetEXTIF {
		cat /etc/network/openvswitch/sw1.info | cut -f1 -d':'
	}
	EXTIF=$(GetEXTIF)

	function GetIP {
		cat /etc/network/openvswitch/sw1.info | cut -f2 -d':'
	}
	IP=$(GetIP)
			
	function GetMTU {
		cat /etc/network/openvswitch/sw1.info | cut -f3 -d':'
	}
	MTU=$(GetMTU)
			
	ovs-vsctl add-port $INTIF $EXTIF
	ovs-vsctl set port $EXTIF tag=10
	ifconfig $EXTIF 0
	ifconfig $INTIF $IP netmask 255.255.255.0
	route add default gw 10.207.39.1 sw1
	ip link set sw1 up
  fi

  Sw1Ip=$(GetSw1Ip)

  if [ $Sw1Ip -eq 0 ]
  then
	function GetInterface {
		ifconfig | egrep -B1 'inet' | egrep -A1 'enp|wlp|wlan|eth|bnep' | sed '$!N;s/\n/ /' | sed 's/  */ /g' | cut -f1,7 -d' ' | sed 's/ addr//' | head -1 | cut -f1 -d':'
	}
	EXTIF=$(GetInterface)

  	ip addr add 10.207.39.SWITCH_IP/24 dev $INTIF
  	ip route replace 10.207.39.0/24 dev sw1
	ip link set sw1 up
	
	# GLS 20161117 Begin code for setting the domain search information in the /etc/resolv.conf file.

	### BEGIN Set domain search in /etc/resolv.conf dynamcially. ###

	function GetInterfaceFirstThree {
		echo $EXTIF | cut -c1-3
	}
	InterfaceFirstThree=$(GetInterfaceFirstThree)

	if   [ $InterfaceFirstThree = 'enp' ] || [ $InterfaceFirstThree = 'eth' ]
	then
		string='search urdomain1.com urdomain2.com gns1.urdomain1.com'
		sudo sed -i -e "\|$string|h; \${x;s|$string||;{g;t};a\\" -e "$string" -e "}" /etc/resolv.conf 
		if [ $LinuxFlavor != 'Ubuntu' ]
		then	
			sudo sed -i '/DOMAIN/d' /etc/sysconfig/network-scripts/ifcfg-$EXTIF
			sudo sed -i '$!N; /^\(.*\)\n\1$/!P; D' /etc/sysconfig/network-scripts/ifcfg-$EXTIF
			sudo sed -i -e '\|DOMAIN="urdomain1.com urdomain2.com gns1.urdomain1.com"|h; ${x;s/incl//;{g;t};a\' -e 'DOMAIN="urdomain1.com urdomain2.com gns1.urdomain1.com"' -e '}' /etc/sysconfig/network-scripts/ifcfg-$EXTIF
			sudo sed -i '$!N; /^\(.*\)\n\1$/!P; D' /etc/sysconfig/network-scripts/ifcfg-$EXTIF
			sudo sed -i -n 'G; s/\n/&&/; /^\([ -~]*\n\).*\n\1/d; s/\n//; h; P' /etc/sysconfig/network-scripts/ifcfg-$EXTIF
		fi
	elif [ $InterfaceFirstThree = 'wlp' ] || [ $InterfaceFirstThree = 'wla' ] || [ $InterfaceFirstThree = 'bne' ]
	then
		string='search urdomain1.com urdomain2.com gns1.urdomain1.com'
		sudo sed -i -e "\|$string|h; \${x;s|$string||;{g;t};a\\" -e "$string" -e "}" /etc/resolv.conf 
		if [ $LinuxFlavor != 'Ubuntu' ]
		then	
			function GetEssid () { sudo iwgetid | cut -f2 -d':' | sed 's/"//g'; }
			ESSID=$(GetEssid)
			sudo sed -i '/DOMAIN/d' /etc/sysconfig/network-scripts/ifcfg-$ESSID
			sudo sed -i '$!N; /^\(.*\)\n\1$/!P; D' /etc/sysconfig/network-scripts/ifcfg-$ESSID
			sudo  sed -i -e '\|DOMAIN="urdomain1.com urdomain2.com gns1.urdomain1.com"|h; ${x;s/incl//;{g;t};a\' -e 'DOMAIN="urdomain1.com urdomain2.com gns1.urdomain1.com"' -e '}' /etc/sysconfig/network-scripts/ifcfg-$ESSID
			sudo  sed -i '$!N; /^\(.*\)\n\1$/!P; D' /etc/sysconfig/network-scripts/ifcfg-$ESSID
			sudo  sed -i -n 'G; s/\n/&&/; /^\([ -~]*\n\).*\n\1/d; s/\n//; h; P' /etc/sysconfig/network-scripts/ifcfg-$ESSID
		fi
	fi

	### END Set domain search in /etc/resolv.conf dynamcially. ###

	# GLS 20161117 End code for setting the domain information in the /etc/resolv.conf file.

	echo 1 > /proc/sys/net/ipv4/ip_forward
	
	### BEGIN iptables rules management ###

		iptables -P INPUT ACCEPT
		iptables -F INPUT 
		iptables -P OUTPUT ACCEPT
		iptables -F OUTPUT 
		iptables -P FORWARD DROP
		iptables -F FORWARD 
		iptables -t nat -F

	function CheckIptablesRulesCount {
		iptables -S | grep FORWARD | grep sw1 | wc -l
	}
	IptablesRulesCount=$(CheckIptablesRulesCount)

	while [ $IptablesRulesCount -ne 0 ]
	do
		iptables -D FORWARD -i $EXTIF -o $INTIF -j ACCEPT > /dev/null 2>&1
		iptables -D FORWARD -i $INTIF -o $EXTIF -j ACCEPT > /dev/null 2>&1
		IptablesRulesCount=$(CheckIptablesRulesCount)
	done

	# set forwarding and nat rules

	SwitchList='sw1 sx1'
	for k in $SwitchList
	do
		function CheckRuleExist {
			sudo iptables -S | grep -c $k
		}
		RuleExist=$(CheckRuleExist)
		function FormatSearchString {
			sudo iptables -S | grep $k | sort -u | head -1 | sed 's/-/\\-/g'
		}
		SearchString=$(FormatSearchString)
		if [ $RuleExist -ne 0 ]
		then
       		 	function GetSwitchRuleCount {
       			 	sudo iptables -S | grep -c "$SearchString"
       		 	}
       		 	SwitchRuleCount=$(GetSwitchRuleCount)
		else
       		 	SwitchRuleCount=0
		fi
		function GetSwitchRule {
			sudo iptables -S | grep $k | sort -u | head -1 | cut -f2-10 -d' '
		}
		SwitchRule=$(GetSwitchRule)
		function GetCountSwitchRules {
			echo $SwitchRule | grep -c $k
		}
		CountSwitchRules=$(GetCountSwitchRules)
		while [ $SwitchRuleCount -ne 0 ] && [ $RuleExist -ne 0 ] && [ $CountSwitchRules -ne 0 ]
		do
       		 	SwitchRule=$(GetSwitchRule)
       		 	sudo iptables -D $SwitchRule
       		 	SearchString=$(FormatSearchString)
       		 	SwitchRuleCount=$(GetSwitchRuleCount)
       		 	RuleExist=$(CheckRuleExist)
		done
	
		# Set forwarding and NAT rules

		iptables -A FORWARD -i $EXTIF -o $k -j ACCEPT
		iptables -A FORWARD -i $k -o $EXTIF -j ACCEPT
		iptables -t nat -A POSTROUTING -o $EXTIF -j MASQUERADE

	done

	### END iptables rules management ###
  fi

  ip tuntap add s1 mode tap 
  ip tuntap add s2 mode tap 
  ip tuntap add s3 mode tap 
  ip tuntap add s4 mode tap 
  ip tuntap add s5 mode tap 
  ip tuntap add s6 mode tap 
# ip tuntap add YourCustomPortName mode tap 

  ip link set s1 up 
  ip link set s2 up
  ip link set s3 up
  ip link set s4 up
  ip link set s5 up
  ip link set s6 up
# ip link set YourCustomPortName up

  ovs-vsctl --may-exist add-port sw1 s1
  ovs-vsctl --may-exist add-port sw1 s2
  ovs-vsctl --may-exist add-port sw1 s3
  ovs-vsctl --may-exist add-port sw1 s4
  ovs-vsctl --may-exist add-port sw1 s5
  ovs-vsctl --may-exist add-port sw1 s6
# ovs-vsctl --may-exist add-port sw1 YourCustomPortName

  ovs-vsctl set port sw1 tag=10
  ovs-vsctl set port sw1 trunks=10,11
  ovs-vsctl set port  s1 tag=11
  ovs-vsctl set port  s2 tag=10
  ovs-vsctl set port  s3 tag=10
  ovs-vsctl set port  s4 tag=10
  ovs-vsctl set port  s5 tag=10
  ovs-vsctl set port  s6 tag=10

  # Patch Ports
  ovs-vsctl set interface s1 type=patch
  ovs-vsctl set interface s1 options:peer=a1

  ### END Get active EXTIF dynamically. ###

  ### BEGIN MTU and tunnel settings. ###
 
#  function GetInterfaceMtu {
#  	ifconfig $Interface | grep mtu | rev | cut -f1 -d' ' | rev
#  }
#  InterfaceMtu=$(GetInterfaceMtu)

#  function CheckGreTunnelExist {
#  	sudo ovs-vsctl show | grep type | grep gre | cut -f2 -d':' | sed 's/^[ \t]*//;s/[ \t]*$//'
#  }
#  GreTunnelExist=$(CheckGreTunnelExist)

#  function CheckGreTunnelStringLen {
#  	sudo ovs-vsctl show | grep type | grep gre | cut -f2 -d':' | sed 's/^[ \t]*//;s/[ \t]*$//' | wc -l
#  }
#  GreTunnelStringLen=$(CheckGreTunnelStringLen)

#  function GetConfigCount {
#	if [ -d /var/lib/lxc/*/config ]
#	then
#  		ls -l /var/lib/lxc/*/config |  wc -l
#	fi
#  }
#  ConfigCount=$(GetConfigCount)

#  if [ $GreTunnelStringLen -gt 0 ] && [ $ConfigCount -gt 0 ] && [ -d /var/lib/lxc/*/config ]
#  then
#  	if [ $GreTunnelExist = 'gre' ]
#  	then
#		MtuSetting=$((InterfaceMtu-80))
#		sed -i "/lxc.network.mtu =/c lxc.network.mtu = $MtuSetting" /var/lib/lxc/*/config
#		function GetRunningContainers {
#			sudo lxc-ls -f | grep RUNNING | sed 's/  */ /g' | cut -f1 -d' ' | sed 's/$/ /' |  tr -d '\n'
#		}
#		RunningContainers=$(GetRunningContainers)
#		for i in $RunningContainers
#		do
#			function GetContainerPorts {
#				ifconfig | grep $i | cut -f1 -d':' | sed 's/$/ /' | tr -d '\n'
#			}
#			ContainerPorts=$(GetContainerPorts)
#			for j in $ContainerPorts
#			do
#				ip link set $j mtu $MtuSetting
#			done
#			function GetContainerInterfaces {
#				lxc-attach -n $i -- ifconfig | grep eth | grep mtu | cut -f1 -d':' | sed 's/$/ /' | tr -d '\n'
#			}
#			ContainerInterfaces=$(GetContainerInterfaces)
#			for k in $ContainerInterfaces
#			do
#        			lxc-attach -n $i -- ip link set $k mtu $MtuSetting
#			done
#		done
#  	fi
#  elif [ -d /var/lib/lxc/*/config ]
#  then
#	MtuSetting=$InterfaceMtu
#	sed -i "/lxc.network.mtu =/c lxc.network.mtu = $MtuSetting" /var/lib/lxc/*/config
#	function GetRunningContainers {
#		sudo lxc-ls -f | grep RUNNING | sed 's/  */ /g' | cut -f1 -d' ' | sed 's/$/ /' |  tr -d '\n'
#	}
#	RunningContainers=$(GetRunningContainers)
#	for i in $RunningContainers
#	do
#		function GetContainerPorts {
#			ifconfig | grep $i | cut -f1 -d':' | sed 's/$/ /' | tr -d '\n'
#		}
#		ContainerPorts=$(GetContainerPorts)
#		for j in $ContainerPorts
#		do
#			ip link set $j mtu $MtuSetting
#		done
#		function GetContainerInterfaces {
#			lxc-attach -n $i -- ifconfig | grep eth | grep mtu | cut -f1 -d':' | sed 's/$/ /' | tr -d '\n'
#		}
#		ContainerInterfaces=$(GetContainerInterfaces)
#		for k in $ContainerInterfaces
#		do
#       			lxc-attach -n $i -- ip link set $k mtu $MtuSetting
#		done
#	done
#  fi

### END MTU and tunnel settings. ###

# GLS 20161117 DNS DHCP dynamic services are now in an Ubuntu 16.04 LXC container that is installed by uekulele.
# service dhcpd start   # Moved to LXC container. These commands are no longer relevant to the LXC host server.
# service named restart # Moved to LXC container. These commands are no longer relevant to the LXC host server.
#
### GRE tunnels 

