#!/bin/bash

chkconfig ntpd on
ntpd
service ntpd start
chkconfig sendmail off
service avahi-daemon stop
yum -y install bind-utils net-tools
yum -y install tar
yum -y install perl
yum -y install which
yum -y install bash
yum -y install bc
