#!/bin/bash
# Start lxc container after required networks are up
switches='sw1 sx1'
m=0
for i in $switches
do
sudo ip link | grep $i >/dev/null 2>&1
while [ $? -ne 0 ]
do
m=$((m+1))
if [ $m -eq 1000 ]
then
exit
fi
sudo ip link | grep $i >/dev/null 2>&1
done
done
sudo lxc-start -n nsa >/dev/null 2>&1

