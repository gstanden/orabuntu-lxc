#!/bin/bash

sudo scstadmin -clear_config -force             
sudo dpkg -r scst                               
sudo apt-get purge scst                         
sudo rm -rf /asm0                                
sudo rm -rf /asm1                                
sudo rm -rf /asm2                                
sudo rm -rf /asm3                                
sudo rm -rf /asm4                                
sudo rm -f /etc/network/openvswitch/stp_scst.sh 
sudo rm -f /etc/network/openvswitch/strt_scst.sh
sudo systemctl disable uekuscst
sudo rm -f /etc/systemd/sysstem/uekuscst.service
sudo rm -f /etc/network/if-down.d/scst.net      
sudo rm -f /etc/udev/rules.d/99-oracle.rules    
sudo rm -rf ~/Downloads/scst-trunk

# If previously using multipath.conf then restore your backup copy.
# If not then just uncomment and delete the multipath.conf 

# sudo rm -f /etc/multipath.conf

