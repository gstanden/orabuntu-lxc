#!/bin/bash

echo ''
echo "=============================================="
echo "Create RSA key for namserver $NameServer...   "
echo "=============================================="
echo ''

ssh-keygen -f /root/.ssh/id_rsa -t rsa -N ''

touch ~/.ssh/authorized_keys

function GetAuthorizedKey {
        cat /root/.ssh/id_rsa.pub
}
AuthorizedKey=$(GetAuthorizedKey)

cat  /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys

echo ''
echo "=============================================="
echo "Create RSA key completed                      "
echo "=============================================="
echo ''
