#!/bin/bash
#
# Synchronize LXC DNS DHCP local container replica
#
start() {
  if [ -f /root/backup-lxc-container/nsa-base/updates/backup_nsa-base_ns_update.tar.gz ]
  then
  	/bin/tar -P -xvf /root/backup-lxc-container/nsa-base/updates/backup_nsa-base_ns_update.tar.gz > /root/dns-sync.log 2>&1
  fi
}

stop() {
  if [ -f /root/backup-lxc-container/nsa-base/updates/backup_nsa-base_ns_update.tar.gz ]
  then
  	/bin/rm /root/backup-lxc-container/nsa-base/updates/backup_nsa-base_ns_update.tar.gz > /root/dns-sync.log 2>&1
  fi
}

case $1 in
  start|stop) "$1" ;;
esac
