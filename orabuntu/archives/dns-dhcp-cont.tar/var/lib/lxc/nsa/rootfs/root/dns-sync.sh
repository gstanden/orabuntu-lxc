#!/bin/bash
#
# Synchronize LXC DNS DHCP local container replica
#
start() {
  /bin/tar -P -xvf /root/backup-lxc-container/nsa/updates/backup_nsa_ns_update.tar.gz > /root/dns-sync.log 2>&1
}

stop() {
  /bin/tar -cvzPf /root/backup-lxc-container/nsa/updates/backup_nsa_ns_update.tar.gz /root/ns_backup_update.lst  > /root/dns-sync.log 2>&1
}

case $1 in
  start|stop) "$1" ;;
esac
