#!/bin/bash

. $HOME/.profile

SourceDir="~/Manage-Orabuntu/backup-lxc-container/nsa/updates"
DestDir="/var/lib/lxc/nsa/delta0/root/backup-lxc-container/nsa/updates"
Owner=ubuntu
Pass=ubuntu

function CheckAwsCliConfigured {
	aws s3 ls | grep backup-lxc-container | wc -l
}
AwsCliConfigured=$(CheckAwsCliConfigured)

rndc sync
mkdir -p  /root/backup-lxc-container/nsa/updates
tar -cvzPf /root/backup-lxc-container/nsa/updates/backup_nsa_ns_update.tar.gz -T /root/ns_backup_update.lst
chown -R ubuntu:ubuntu backup-lxc-container

if [ -s /root/gre_hosts.txt ]
then
	function GetGreHosts {
		cat /root/gre_hosts.txt | sed 's/$/ /' | tr -d '\n' | sed 's/^[ \t]*//;s/[ \t]*$//'
	}
	GreHosts=$(GetGreHosts)
fi

if   [ $AwsCliConfigured -eq 1 ] && [ -s /root/gre_hosts.txt ]
then
	aws s3 sync /root/backup-lxc-container/nsa/updates s3://backup-lxc-container/nsa/updates
	for i in $GreHosts
	do
		ssh-keygen -f "/root/.ssh/known_hosts" -R $i
		sshpass -p $Pass ssh -tt -o CheckHostIP=no -o StrictHostKeyChecking=no $Owner@$i mkdir -p $SourceDir/
		sshpass -p $Pass scp     -o CheckHostIP=no -o StrictHostKeyChecking=no /root/backup-lxc-container/nsa/updates/backup_nsa_ns_update.tar.gz $Owner@$i:$SourceDir
		sshpass -p $Pass ssh -tt -o CheckHostIP=no -o StrictHostKeyChecking=no $Owner@$i "sudo -S <<< "$Pass" mkdir -p $DestDir"
		sshpass -p $Pass ssh -tt -o CheckHostIP=no -o StrictHostKeyChecking=no $Owner@$i "sudo -S <<< "$Pass" cp -p $SourceDir/backup_nsa_ns_update.tar.gz $DestDir/backup_nsa_ns_update.tar.gz"
	done
elif [ -s /root/gre_hosts.txt ]
then
	for i in $GreHosts
	do
		ssh-keygen -f "/root/.ssh/known_hosts" -R $i
		sshpass -p $Pass ssh -tt -o CheckHostIP=no -o StrictHostKeyChecking=no $Owner@$i mkdir -p $SourceDir/
		sshpass -p $Pass scp     -o CheckHostIP=no -o StrictHostKeyChecking=no /root/backup-lxc-container/nsa/updates/backup_nsa_ns_update.tar.gz $Owner@$i:$SourceDir
		sshpass -p $Pass ssh -tt -o CheckHostIP=no -o StrictHostKeyChecking=no $Owner@$i "sudo -S <<< "$Pass" mkdir -p $DestDir"
		sshpass -p $Pass ssh -tt -o CheckHostIP=no -o StrictHostKeyChecking=no $Owner@$i "sudo -S <<< "$Pass" cp -p $SourceDir/backup_nsa_ns_update.tar.gz $DestDir/backup_nsa_ns_update.tar.gz"
	done
fi
