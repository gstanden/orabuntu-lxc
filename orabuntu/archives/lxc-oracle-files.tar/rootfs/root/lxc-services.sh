#!/bin/bash

# This file is for additional configurations and packages for Oracle
# that are not part of basic Oracle documentation package installs.
# Oracle basic package installs are in the packages.sh file.

chkconfig ntpd on
ntpd
service ntpd start
chkconfig sendmail off
service avahi-daemon stop

# Installed for dnsmasq handling of the Oracle GNS lookups
yum -y install NetworkManager

# Needed for nslookup utility
yum -y install bind-utils

# Oracle Needed for TFA Install During Oracle GI install
yum -y install tar
yum -y install perl
yum -y install which
yum -y install bash

# Oracle Needed for hugepages_settings.sh script
yum -y install bc

# Uncomment if using NFS
# chown grid:asmadmin /shared_data
# service rpcbind start
# mount -a
