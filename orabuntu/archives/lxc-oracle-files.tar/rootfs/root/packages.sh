#!/bin/bash

# This packages.sh file is for packages that are required according to Oracle documentation.
# Use the lxc-services.sh file for packages that are for container and other purposes.

yum -y install binutils
yum -y install compat-libcap1
yum -y install compat-libstdc++-33
yum -y install compat-libstdc++-33.i686
yum -y install gcc
yum -y install gcc-c++
yum -y install glibc
yum -y install glibc.i686
yum -y install glibc-devel
yum -y install glibc-devel.i686
yum -y install ksh
yum -y install libgcc
yum -y install libgcc.i686
yum -y install libstdc++
yum -y install libstdc++.i686
yum -y install libstdc++-devel
yum -y install libstdc++-devel.i686
yum -y install libaio
yum -y install libaio.i686
yum -y install libaio-devel
yum -y install libaio-devel.i686
yum -y install libXext
yum -y install libXext.i686
yum -y install libXtst
yum -y install libXtst.i686
yum -y install libX11
yum -y install libX11.i686
yum -y install libXau
yum -y install libXau.i686
yum -y install libxcb
yum -y install libxcb.i686
yum -y install libXi
yum -y install libXi.i686
yum -y install make
yum -y install sysstat
yum -y install unixODBC
yum -y install unixODBC-devel
yum -y install xdpyinfo
yum -y install xorg-x11-apps
yum -y install pdksh
yum -y install libicu
yum -y remove elfutils-libelf-devel.i386
yum -y install ntp
yum -y install sg3-utils
yum -y install xauth
yum -y install xorg-x11-fonts*
yum -y install unzip
yum -y install nfs-utils
chkconfig sendmail off

