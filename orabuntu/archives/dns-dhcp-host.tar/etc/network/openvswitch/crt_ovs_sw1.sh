#!/bin/bash

#    Copyright 2015-2017 Gilbert Standen
#    This file is part of Orabuntu-LXC.

#    Orabuntu-LXC is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-LXC is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with Orabuntu-LXC.  If not, see <http://www.gnu.org/licenses/>.

#    v2.4 GLS 20151224
#    v2.8 GLS 20151231
#    v3.0 GLS 20160710 Updates for Ubuntu 16.04
#    v4.0 GLS 20161025 DNS DHCP services moved into an LXC container
#    v5.0 GLS 20170909 Orabuntu-LXC MultiHost

#    Note that Orabuntu-LXC v5.0  builds a conntainerized DNS DHCP solution for the Desktop or Enterprise environment.
#    The nameserver should NOT be the name of an EXISTING nameserver but an arbitrary name because this software is CREATING a new LXC-containerized nameserver.
#    The domain names can be arbitrary fictional names or they can be a domain that you actually own and operate.
#    There are two domains and two networks because the "seed" LXC containers are on a separate network and domain from the production LXC containers.

# GLS 20170916 Auxiliary Ports and Patch Port
# Port s1 is reserved for patch port to switch sx1 for multihost traffic over GRE tunnel for the seed container network.
# Other sX ports can be used for VM's or for any other purpose (ports s2, s3 are default auxiliary ports - you can add more here)

  ip tuntap add s1 mode tap 
  ip tuntap add s2 mode tap 
  ip tuntap add s3 mode tap 
# ip tuntap add YourCustomPortName mode tap 

  ip link set s1 up
  ip link set s2 up
  ip link set s3 up
# ip link set YourCustomPortName up

  ovs-vsctl --may-exist add-br sw1

  ovs-vsctl --may-exist add-port sw1 s1
  ovs-vsctl --may-exist add-port sw1 s2
  ovs-vsctl --may-exist add-port sw1 s3
# ovs-vsctl --may-exist add-port sw1 YourCustomPortName

  ip link set up dev sw1
  ip addr add 10.207.39.SWITCH_IP/24 dev sw1
  ip route replace 10.207.39.0/24 dev sw1
  ovs-vsctl set port sw1 tag=10
  ovs-vsctl set port sw1 trunks=10,11
  ovs-vsctl set port  s1 tag=11
  ovs-vsctl set port  s2 tag=10
  ovs-vsctl set port  s3 tag=10

# GRE Tunnel
# sudo ovs-vsctl add-port sw1 gre0 -- set interface gre0 type=gre options:remote_ip=REMOTE_GRE_ENDPOINT

# Patch Ports
  ovs-vsctl set interface s1 type=patch
  ovs-vsctl set interface s1 options:peer=a1
  
# Add routes for GRE tunneling of all switches
# route add -net 192.220.39.0/24 gw 10.207.39.SWITCH_IP dev sw1
# route add -net 192.221.39.0/24 gw 10.207.39.SWITCH_IP dev sw1
# route add -net 192.222.39.0/24 gw 10.207.39.SWITCH_IP dev sw1
# route add -net 192.223.39.0/24 gw 10.207.39.SWITCH_IP dev sw1
# route add -net 172.230.40.0/24 gw 10.207.39.SWITCH_IP dev sw1
# route add -net 172.231.40.0/24 gw 10.207.39.SWITCH_IP dev sw1
# route add -net 10.207.39.0/24  gw 10.207.39.SWITCH_IP dev sw1

# GLS 20140825 Get active external interface dynamically at boot.  Tested & works with {wlan0, eth0, bnep0} on Ubuntu 14.04.1 Desktop x86_64.
# GLS 20140825 Interface "bnep0" is Blackberry Z30 OS10 Bluetooth Tether.
# GLS 20161117 Support was added previously for {wlp, enp}.

### BEGIN Get active EXTIF dynamcally. ###

function GetInterface {
ifconfig | egrep -B1 'inet' | egrep -A1 'enp|wlp|wlan|eth|bnep' | sed '$!N;s/\n/ /' | sed 's/  */ /g' | cut -f1,7 -d' ' | sed 's/ addr//' | head -1 | cut -f1 -d':'
}
Interface=$(GetInterface)
function GetIP
{
ifconfig | grep -A1 $Interface | grep inet | sed '$!N;s/\n/ /' | sed 's/  */ /g' | cut -f3 -d' '
}

### END Get active EXTIF dynamically. ###

echo '       IP: '$(GetIP)
echo 'Interface: '$(GetInterface)

INTIF="sw1"
EXTIF=$(GetInterface)

# GLS 20161117 Begin code for setting the domain search information in the /etc/resolv.conf file.

### BEGIN Set domain search in /etc/resolv.conf dynamcially. ###

function GetInterfaceFirstThree {
echo $EXTIF | cut -c1-3
}
InterfaceFirstThree=$(GetInterfaceFirstThree)

function CheckNetworkManagerInstalled {
        dpkg -l | grep -v  network-manager- | grep network-manager | wc -l
}
NetworkManagerInstalled=$(CheckNetworkManagerInstalled)

function CheckSystemdResolvedInstalled {
	sudo netstat -ulnp | grep 53 | sed 's/  */ /g' | rev | cut -f1 -d'/' | rev | sort -u | grep systemd- | wc -l
}
SystemdResolvedInstalled=$(CheckSystemdResolvedInstalled)

GetLinuxFlavors(){
if [[ -e /etc/redhat-release ]]
then
        LinuxFlavors=$(cat /etc/redhat-release | cut -f1 -d' ')
elif [[ -e /usr/bin/lsb_release ]]
then
        LinuxFlavors=$(lsb_release -d | awk -F ':' '{print $2}' | cut -f1 -d' ')
elif [[ -e /etc/issue ]]
then
        LinuxFlavors=$(cat /etc/issue | cut -f1 -d' ')
else
        LinuxFlavors=$(cat /proc/version | cut -f1 -d' ')
fi
}
GetLinuxFlavors

function TrimLinuxFlavors {
	echo $LinuxFlavors | sed 's/^[ \t]//;s/[ \t]$//'
}
LinuxFlavor=$(TrimLinuxFlavors)

if   [ $InterfaceFirstThree = 'enp' ] || [ $InterfaceFirstThree = 'eth' ]
then
	if [ $LinuxFlavor = 'Red' ]
	then
		sudo sed -i '/DOMAIN/d' /etc/sysconfig/network-scripts/ifcfg-$EXTIF
		sudo sed -i '$!N; /^\(.*\)\n\1$/!P; D' /etc/sysconfig/network-scripts/ifcfg-$EXTIF
		sudo sed -i -e '\|DOMAIN="orabuntu-lxc.com consultingcommandos.us gns1.orabuntu-lxc.com"|h; ${x;s/incl//;{g;t};a\' -e 'DOMAIN="orabuntu-lxc.com consultingcommandos.us gns1.orabuntu-lxc.com"' -e '}' /etc/sysconfig/network-scripts/ifcfg-$EXTIF
		sudo sed -i '$!N; /^\(.*\)\n\1$/!P; D' /etc/sysconfig/network-scripts/ifcfg-$EXTIF
		sudo sed -i -n 'G; s/\n/&&/; /^\([ -~]*\n\).*\n\1/d; s/\n//; h; P' /etc/sysconfig/network-scripts/ifcfg-$EXTIF
	fi
	if   [ $NetworkManagerInstalled -eq 1 ]
	then
		string1='search orabuntu-lxc.com consultingcommandos.us gns1.orabuntu-lxc.com'
		sudo sed -i -e "\|$string1|h; \${x;s|$string1||;{g;t};a\\" -e "$string1" -e "}" /etc/resolv.conf 
		sudo sed -i '$!N; /^\(.*\)\n\1$/!P; D' /etc/resolv.conf
	elif [ $SystemdResolvedInstalled -eq 1 ]
	then
		function GetExistingNameservers {
			cat /etc/resolv.conf | grep nameserver | egrep -v '#|127.0.0.53' | sed 's/^[ \t]*//;s/[ \t]*$//' | cut -f2 -d' ' | sed 's/$/ /' | tr -d '\n'
		}
		ExistingNameservers=$(GetExistingNameservers)
		function GetExistingSearch {
			cat /etc/resolv.conf | grep -v '#' | grep search | tail -1
		}
		ExistingSearch=$(GetExistingSearch)
		echo "Existing nameservers = $ExistingNameservers"
		echo "Existing search      = $ExistingSearch"
		sudo sed -i "/#DNS=/s/#DNS=/DNS=10.207.39.2 10.207.29.2 $ExistingNameservers/" 							/etc/systemd/resolved.conf
		sudo sed -i '/nameserver/{/127\.0\.0\.53/b;d}'											/etc/resolv.conf
		sudo service systemd-resolved restart
		if [ -z $ExistingSearch ]
		then
			sudo sh -c "echo 'search orabuntu-lxc.com consultingcommandos.us gns1.orabuntu-lxc.com' >>				/etc/resolv.conf"
		else
			sudo sed -i "/*search*/c\search orabuntu-lxc.com consultingcommandos.us gns1.orabuntu-lxc.com $ExistingSearch/" 	/etc/resolv.conf
		fi
		sudo service systemd-resolved restart
	fi
elif [ $InterfaceFirstThree = 'wlp' ] || [ $InterfaceFirstThree = 'wla' ] || [ $InterfaceFirstThree = 'bne' ]
then
	function GetEssid () { sudo iwgetid | cut -f2 -d':' | sed 's/"//g'; }
	ESSID=$(GetEssid)
	if [ $LinuxFlavor = 'Red' ]
	then
		sudo sed -i '/DOMAIN/d' /etc/sysconfig/network-scripts/ifcfg-$ESSID
		sudo sed -i '$!N; /^\(.*\)\n\1$/!P; D' /etc/sysconfig/network-scripts/ifcfg-$ESSID
		sudo  sed -i -e '\|DOMAIN="orabuntu-lxc.com consultingcommandos.us gns1.orabuntu-lxc.com"|h; ${x;s/incl//;{g;t};a\' -e 'DOMAIN="orabuntu-lxc.com consultingcommandos.us gns1.orabuntu-lxc.com"' -e '}' /etc/sysconfig/network-scripts/ifcfg-$ESSID
		sudo  sed -i '$!N; /^\(.*\)\n\1$/!P; D' /etc/sysconfig/network-scripts/ifcfg-$ESSID
		sudo  sed -i -n 'G; s/\n/&&/; /^\([ -~]*\n\).*\n\1/d; s/\n//; h; P' /etc/sysconfig/network-scripts/ifcfg-$ESSID
	fi
	if   [ $NetworkManagerInstalled -eq 1 ]
	then
		string1='search orabuntu-lxc.com consultingcommandos.us gns1.orabuntu-lxc.com'
		sudo sed -i -e "\|$string1|h; \${x;s|$string1||;{g;t};a\\" -e "$string1" -e "}" /etc/resolv.conf 
		sudo sed -i '$!N; /^\(.*\)\n\1$/!P; D' /etc/resolv.conf
	elif [ $SystemdResolvedInstalled -eq 1 ]
	then
		function GetExistingNameservers {
			cat /etc/resolv.conf | grep nameserver | egrep -v '#|127.0.0.53' | sed 's/^[ \t]*//;s/[ \t]*$//' | cut -f2 -d' ' | sed 's/$/ /' | tr -d '\n'
		}
		ExistingNameservers=$(GetExistingNameservers)
		function GetExistingSearch {
			cat /etc/resolv.conf | grep -v '#' | grep search | tail -1 
		}
		ExistingSearch=$(GetExistingSearch)
		echo "Existing nameservers = $ExistingNameservers"
		echo "Existing search      = $ExistingSearch"
		sudo sed -i "/#DNS=/s/#DNS=/DNS=10.207.39.2 10.207.29.2 $ExistingNameservers/" 							/etc/systemd/resolved.conf
		sudo sed -i '/nameserver/{/127\.0\.0\.53/b;d}'											/etc/resolv.conf 
		if [ -z $ExistingSearch ]
		then
			sudo sh -c "echo 'search orabuntu-lxc.com consultingcommandos.us gns1.orabuntu-lxc.com' >>				/etc/resolv.conf"
		else
			sudo sed -i "/*search*/c\search orabuntu-lxc.com consultingcommandos.us gns1.orabuntu-lxc.com $ExistingSearch/" 	/etc/resolv.conf
		fi
		sudo service systemd-resolved restart
	fi
fi

sudo sed -i 's/files resolve \[\!UNAVAIL=return\] dns/dns files resolve \[\!UNAVAIL=return\]/' /etc/nsswitch.conf

### END Set domain search in /etc/resolv.conf dynamcially. ###

# GLS 20161117 End code for setting the domain information in the /etc/resolv.conf file.

echo 1 > /proc/sys/net/ipv4/ip_forward

### BEGIN iptables rules management ###

	iptables -P INPUT ACCEPT
	iptables -F INPUT 
	iptables -P OUTPUT ACCEPT
	iptables -F OUTPUT 
	iptables -P FORWARD DROP
	iptables -F FORWARD 
	iptables -t nat -F

function CheckIptablesRulesCount {
iptables -S | grep FORWARD | grep sw1 | wc -l
}
IptablesRulesCount=$(CheckIptablesRulesCount)

while [ $IptablesRulesCount -ne 0 ]
do
	iptables -D FORWARD -i $EXTIF -o $INTIF -j ACCEPT > /dev/null 2>&1
	iptables -D FORWARD -i $INTIF -o $EXTIF -j ACCEPT > /dev/null 2>&1
	IptablesRulesCount=$(CheckIptablesRulesCount)
done

# set forwarding and nat rules

SwitchList='sw1 sx1'
for k in $SwitchList
do
	function CheckRuleExist {
	sudo iptables -S | grep -c $k
	}
	RuleExist=$(CheckRuleExist)
	function FormatSearchString {
		sudo iptables -S | grep $k | sort -u | head -1 | sed 's/-/\\-/g'
	}
	SearchString=$(FormatSearchString)
	if [ $RuleExist -ne 0 ]
	then
        	function GetSwitchRuleCount {
        	sudo iptables -S | grep -c "$SearchString"
        	}
        	SwitchRuleCount=$(GetSwitchRuleCount)
	else
        	SwitchRuleCount=0
	fi
	function GetSwitchRule {
	sudo iptables -S | grep $k | sort -u | head -1 | cut -f2-10 -d' '
	}
	SwitchRule=$(GetSwitchRule)
	function GetCountSwitchRules {
	echo $SwitchRule | grep -c $k
	}
	CountSwitchRules=$(GetCountSwitchRules)
	while [ $SwitchRuleCount -ne 0 ] && [ $RuleExist -ne 0 ] && [ $CountSwitchRules -ne 0 ]
	do
        	SwitchRule=$(GetSwitchRule)
        	sudo iptables -D $SwitchRule
        	SearchString=$(FormatSearchString)
        	SwitchRuleCount=$(GetSwitchRuleCount)
        	RuleExist=$(CheckRuleExist)
	done
	iptables -A FORWARD -i $EXTIF -o $k -j ACCEPT
	iptables -A FORWARD -i $k -o $EXTIF -j ACCEPT
	iptables -t nat -A POSTROUTING -o $EXTIF -j MASQUERADE
done

### END iptables rules management ###

# GLS 20161117 DNS DHCP dynamic services are now in an Ubuntu 16.04 LXC container that is installed by Uekulele.
# service dhcpd start   # Moved to LXC container. These commands are no longer relevant to the LXC host server.
# service named restart # Moved to LXC container. These commands are no longer relevant to the LXC host server.


