sudo sed -i '/route add -net/s/#/ /g' /etc/network/openvswitch/crt_ovs_sw1.sh >/dev/null 2>&1
sudo sed -i '/REMOTE_GRE_ENDPOINT/s/#/ /' /etc/network/openvswitch/crt_ovs_sw1.sh >/dev/null 2>&1
sudo sed -i "s/REMOTE_GRE_ENDPOINT/MultiHostVar6/g" /etc/network/openvswitch/crt_ovs_sw1.sh >/dev/null 2>&1
# sudo sed -i "s/MHV6/MultiHostVar6/g" /etc/network/openvswitch/crt_ovs_sw1.sh >/dev/null 2>&1
sudo ovs-vsctl del-port gre0 >/dev/null 2>&1
sudo ovs-vsctl add-port sw1 gre0 -- set interface gre0 type=gre options:remote_ip=MultiHostVar6 >/dev/null 2>&1
exit

