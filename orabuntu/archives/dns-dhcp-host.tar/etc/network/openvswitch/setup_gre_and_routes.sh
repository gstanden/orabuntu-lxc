sudo sed -i '/route add -net/s/#/ /g' /etc/network/openvswitch/crt_ovs_sw1.sh >/dev/null 2>&1
sudo sed -i '/REMOTE_GRE_ENDPOINT/s/#/ /' /etc/network/openvswitch/crt_ovs_sw1.sh >/dev/null 2>&1
sudo sed -i "s/REMOTE_GRE_ENDPOINT/MultiHostVar6/g" /etc/network/openvswitch/crt_ovs_sw1.sh >/dev/null 2>&1
# sudo sed -i "s/MHV6/MultiHostVar6/g" /etc/network/openvswitch/crt_ovs_sw1.sh >/dev/null 2>&1
sudo ovs-vsctl del-port greMultiHostVar3 >/dev/null 2>&1
sudo ovs-vsctl add-port sw1 geneveMultiHostVar3 -- set interface geneveMultiHostVar3 type=geneve options:remote_ip=MultiHostVar6 options:key=123 >/dev/null 2>&1
sudo sh -c "echo 'sudo ovs-vsctl add-port sw1 geneveMultiHostVar3 -- set interface geneveMultiHostVar3 type=geneve options:remote_ip=MultiHostVar6 options:key=123' >> /etc/network/openvswitch/crt_ovs_sw1.sh"
exit

