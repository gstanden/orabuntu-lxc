#!/bin/bash

  ip tuntap add s1 mode tap 
  ip tuntap add s2 mode tap 
  ip tuntap add s3 mode tap 
# ip tuntap add YourCustomPortName mode tap 

  ip link set s1 up
  ip link set s2 up
  ip link set s3 up
# ip link set YourCustomPortName up

  ovs-vsctl --may-exist add-br sw1

  ovs-vsctl --may-exist add-port sw1 s1
  ovs-vsctl --may-exist add-port sw1 s2
  ovs-vsctl --may-exist add-port sw1 s3
# ovs-vsctl --may-exist add-port sw1 YourCustomPortName

  ip link set up dev sw1
  ip addr add 10.207.39.1/24 dev sw1
  ip route replace 10.207.39.0/24 dev sw1

  ovs-vsctl set port sw1 trunks=10
  ovs-vsctl set port sw1 tag=10
  ovs-vsctl set port s1 tag=10
  ovs-vsctl set port s2 tag=10
  ovs-vsctl set port s3 tag=10
# ovs-vsctl set port YourCustomPortName tag=10

# GLS 20140825 Get active external interface dynamically at boot.  Tested & works with {wlan0, eth0, bnep0} on Ubuntu 14.04.1 Desktop x86_64.
# GLS 20140825 Interface "bnep0" is Blackberry Z30 OS10 Bluetooth Tether.
# GLS 20161117 Support was added previously for {wlp, enp}.

### BEGIN Get active EXTIF dynamcally. ###

function GetInterface {
ifconfig | egrep -B1 'inet' | egrep -A1 'enp|wlp|wlan|eth|bnep' | sed '$!N;s/\n/ /' | sed 's/  */ /g' | cut -f1,7 -d' ' | sed 's/ addr//' | head -1 | cut -f1 -d':'
}
Interface=$(GetInterface)
function GetIP
{
ifconfig | grep -A1 $Interface | grep inet | sed '$!N;s/\n/ /' | sed 's/  */ /g' | cut -f3 -d' '
}

### END Get active EXTIF dynamically. ###

echo '       IP: '$(GetIP)
echo 'Interface: '$(GetInterface)

INTIF="sw1"
EXTIF=$(GetInterface)

# GLS 20161117 Begin code for setting the domain search information in the /etc/resolv.conf file.

### BEGIN Set domain search in /etc/resolv.conf dynamcially. ###

function GetInterfaceFirstThree {
echo $EXTIF | cut -c1-3
}
InterfaceFirstThree=$(GetInterfaceFirstThree)

if [ -r /etc/lsb-release ]
then
	function GetLinuxFlavor {
		cat /etc/lsb-release | grep DISTRIB_ID | cut -f2 -d'='
	}
	LinuxFlavor=$(GetLinuxFlavor)
else
	LinuxFlavor='NotUbuntu'
fi

if   [ $LinuxFlavor = 'NotUbuntu' ]
then
	if   [ $InterfaceFirstThree = 'enp' ] || [ $InterfaceFirstThree = 'eth' ]
	then
		sudo sed -i '/DOMAIN/d' /etc/sysconfig/network-scripts/ifcfg-$EXTIF
		sudo sed -i '$!N; /^\(.*\)\n\1$/!P; D' /etc/sysconfig/network-scripts/ifcfg-$EXTIF
		sudo sed -i -e '\|DOMAIN="orabuntu-lxc.com consultingcommandos.us gns1.orabuntu-lxc.com"|h; ${x;s/incl//;{g;t};a\' -e 'DOMAIN="orabuntu-lxc.com consultingcommandos.us gns1.orabuntu-lxc.com"' -e '}' /etc/sysconfig/network-scripts/ifcfg-$EXTIF
		sudo sed -i '$!N; /^\(.*\)\n\1$/!P; D' /etc/sysconfig/network-scripts/ifcfg-$EXTIF
		sudo sed -i -n 'G; s/\n/&&/; /^\([ -~]*\n\).*\n\1/d; s/\n//; h; P' /etc/sysconfig/network-scripts/ifcfg-$EXTIF
	elif [ $InterfaceFirstThree = 'wlp' ] || [ $InterfaceFirstThree = 'wla' ] || [ $InterfaceFirstThree = 'bne' ]
	then
		function GetEssid () { sudo iwgetid | cut -f2 -d':' | sed 's/"//g'; }
		ESSID=$(GetEssid)
		sudo sed -i '/DOMAIN/d' /etc/sysconfig/network-scripts/ifcfg-$ESSID
		sudo sed -i '$!N; /^\(.*\)\n\1$/!P; D' /etc/sysconfig/network-scripts/ifcfg-$ESSID
		sudo  sed -i -e '\|DOMAIN="orabuntu-lxc.com consultingcommandos.us gns1.orabuntu-lxc.com"|h; ${x;s/incl//;{g;t};a\' -e 'DOMAIN="orabuntu-lxc.com consultingcommandos.us gns1.orabuntu-lxc.com"' -e '}' /etc/sysconfig/network-scripts/ifcfg-$ESSID
		sudo  sed -i '$!N; /^\(.*\)\n\1$/!P; D' /etc/sysconfig/network-scripts/ifcfg-$ESSID
		sudo  sed -i -n 'G; s/\n/&&/; /^\([ -~]*\n\).*\n\1/d; s/\n//; h; P' /etc/sysconfig/network-scripts/ifcfg-$ESSID
	fi
fi

if  [ $LinuxFlavor = 'Ubuntu' ]
then
 	sudo sed -i '/search/d' 	/etc/resolv.conf
# 	sudo sed -i '/nameserver/d' 	/etc/resolv.conf
 	sudo sh -c "echo 'search orabuntu-lxc.com consultingcommandos.us gns1.orabuntu-lxc.com'		>> /etc/resolv.conf"
# 	sudo sh -c "echo 'nameserver 10.207.39.2' 						>> /etc/resolv.conf"
# 	sudo sh -c "echo 'nameserver 10.207.29.2' 						>> /etc/resolv.conf"
fi

### END Set domain search in /etc/resolv.conf dynamcially. ###

# GLS 20161117 End code for setting the domain information in the /etc/resolv.conf file.

echo 1 > /proc/sys/net/ipv4/ip_forward

### BEGIN iptables rules management ###

	iptables -P INPUT ACCEPT
	iptables -F INPUT 
	iptables -P OUTPUT ACCEPT
	iptables -F OUTPUT 
	iptables -P FORWARD DROP
	iptables -F FORWARD 
	iptables -t nat -F

function CheckIptablesRulesCount {
iptables -S | grep FORWARD | grep sw1 | wc -l
}
IptablesRulesCount=$(CheckIptablesRulesCount)

while [ $IptablesRulesCount -ne 0 ]
do
	iptables -D FORWARD -i $EXTIF -o $INTIF -j ACCEPT > /dev/null 2>&1
	iptables -D FORWARD -i $INTIF -o $EXTIF -j ACCEPT > /dev/null 2>&1
	IptablesRulesCount=$(CheckIptablesRulesCount)
done

# set forwarding and nat rules

SwitchList='sw1 sx1'
for k in $SwitchList
do
	function CheckRuleExist {
	sudo iptables -S | grep -c $k
	}
	RuleExist=$(CheckRuleExist)
	function FormatSearchString {
		sudo iptables -S | grep $k | sort -u | head -1 | sed 's/-/\\-/g'
	}
	SearchString=$(FormatSearchString)
	if [ $RuleExist -ne 0 ]
	then
        	function GetSwitchRuleCount {
        	sudo iptables -S | grep -c "$SearchString"
        	}
        	SwitchRuleCount=$(GetSwitchRuleCount)
	else
        	SwitchRuleCount=0
	fi
	function GetSwitchRule {
	sudo iptables -S | grep $k | sort -u | head -1 | cut -f2-10 -d' '
	}
	SwitchRule=$(GetSwitchRule)
	function GetCountSwitchRules {
	echo $SwitchRule | grep -c $k
	}
	CountSwitchRules=$(GetCountSwitchRules)
	while [ $SwitchRuleCount -ne 0 ] && [ $RuleExist -ne 0 ] && [ $CountSwitchRules -ne 0 ]
	do
        	SwitchRule=$(GetSwitchRule)
        	sudo iptables -D $SwitchRule
        	SearchString=$(FormatSearchString)
        	SwitchRuleCount=$(GetSwitchRuleCount)
        	RuleExist=$(CheckRuleExist)
	done
	iptables -A FORWARD -i $EXTIF -o $k -j ACCEPT
	iptables -A FORWARD -i $k -o $EXTIF -j ACCEPT
	iptables -t nat -A POSTROUTING -o $EXTIF -j MASQUERADE
done

### END iptables rules management ###

# GLS 20161117 DNS DHCP dynamic services are now in an Ubuntu 16.04 LXC container that is installed by Uekulele.
# service dhcpd start   # Moved to LXC container. These commands are no longer relevant to the LXC host server.
# service named restart # Moved to LXC container. These commands are no longer relevant to the LXC host server.
