sudo systemctl reload snap.lxd.daemon
lxc image copy images:oracle/8 local: --alias=oracle/8
lxc image copy images:oracle/7 local: --alias=oracle/7
lxc image copy images:oracle/6 local: --alias=oracle/6

