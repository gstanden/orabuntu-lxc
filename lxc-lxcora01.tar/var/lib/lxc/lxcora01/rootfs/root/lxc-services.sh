chkconfig ntpd on
service ntpd start
chkconfig sendmail off
service avahi-daemon stop
yum -y install bind-utils
chown grid:asmadmin /shared_data
service rpcbind start
mount -a
