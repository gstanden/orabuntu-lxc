#!/bin/bash

#    Copyright 2015-2016 Gilbert Standen
#    This file is part of orabuntu-lxc.

#    Orabuntu-lxc is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-lxc is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with orabuntu-lxc.  If not, see <http://www.gnu.org/licenses/>.

#    v2.8 GLS 20151231
#    v3.0 GLS 20160717

export IQN_YR=`date +"%Y"`
export IQN_MO=`date +"%m"`
export IQN=iqn.$IQN_YR-$IQN_MO.com.orabuntu-lxc:storage.tgt.lxc.oracle.asm

clear

echo ''
echo "=============================================="
echo "Clear any old multipath maps ...              "
echo "=============================================="
echo ''

sudo service multipath-tools stop > /dev/null 2>&1
sudo multipath -F > /dev/null 2>&1
sudo service multipath-tools start > /dev/null 2>&1

echo ''
echo "=============================================="
echo "Multipath maps cleared...             "
echo "=============================================="
echo ''

sleep 5

clear

echo ''
echo "=============================================="
echo "Discover new TGT target SAN...                "
echo "=============================================="
echo ''

sudo iscsiadm --mode discovery --type sendtargets --portal 10.207.40.1:3260
sudo iscsiadm --mode discovery --type sendtargets --portal 10.207.41.1:3260

echo ''
echo "=============================================="
echo "TGT target SAN discovery complete...          "
echo "=============================================="
echo ''

sleep 5

clear

echo ''
echo "=============================================="
echo "Login to new TGT target...                    "
echo "=============================================="
echo ''

sudo iscsiadm --mode node --targetname $IQN --portal 10.207.40.1:3260 --login
sudo iscsiadm --mode node --targetname $IQN --portal 10.207.41.1:3260 --login

echo ''
echo "=============================================="
echo "Login to new TGT target complete...           "
echo "=============================================="
echo ''

sleep 5

clear

echo ''
echo "=============================================="
echo "List new TGT target LUNs...                   "
echo "=============================================="
echo ''

ls -l /dev/mapper

echo ''
echo "=============================================="
echo "List new TGT target LUNs complete...          "
echo "=============================================="
echo ''

# Optional automatic LUN startup - use with CAUTION! because network may not load at boot ahead of iscsi login causing boot to hang.
# Typically use of this on the same server as the login requires changes to services startup order.
# Be sure to substitute the actual IQN_YR and IQN_MO to the below lines before adding to /etc/rc.local

# sudo iscsiadm -m node -T iqn.$IQN_YR-$IQN_MO.com.orabuntu-lxc:storage.tgt.lxc.oracle.asm -p 192.168.1.44 --op update -n node.startup -v automatic

echo ''
echo "=============================================="
echo "Add the following lines above the 'exit 0' line in the /etc/rc.local file"
echo "so that SAN will login and start on bootup.   "
echo "=============================================="
echo ''
echo "sudo iscsiadm --mode node --targetname $IQN --portal 10.207.40.1:3260 --login"
echo "sudo iscsiadm --mode node --targetname $IQN --portal 10.207.41.1:3260 --login"
echo ''
echo "=============================================="
