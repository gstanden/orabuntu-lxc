#!/bin/bash

#    Copyright 2015-2016 Gilbert Standen
#    This file is part of orabuntu-lxc.

#    Orabuntu-lxc is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-lxc is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with orabuntu-lxc.  If not, see <http://www.gnu.org/licenses/>.

#    Usage:  $1 is the YEAR of the IQN name
#            $2 is the MONTH of the IQN name
#    e.g.:   iqn.2016-07.com.orabuntu-lxc:storage.tgt.lxc.oracle.asm

#    You have to pass these in because you might run the remove-tgt-1.sh script long after creating the TGT SAN, and in that case the month and year have changed.

#    v2.8 GLS 20151231
#    v3.0 GLS 20160717

export DATEXT=`date +"%Y%m%d%H%M"`
# export IQN_YR=`date +"%Y"`
# export IQN_MO=`date +"%m"`

export IQN_YR=$1
export IQN_MO=$2

export IQN=iqn.$IQN_YR-$IQN_MO.com.orabuntu-lxc:storage.tgt.lxc.oracle.asm

clear

echo ''
echo "=============================================="
echo "Stop multipath-tools service...               "
echo "=============================================="
echo ''

sudo service multipath-tools stop > /dev/null 2>&1

echo ''
echo "=============================================="
echo "Multipath-tools service stopped...            "
echo "=============================================="
echo ''

sleep 2

clear

echo ''
echo "=============================================="
echo "Delete LUNs from TGT target...                "
echo "=============================================="
echo ''

sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=0 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=1 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=2 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=3 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=4 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=5 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=6 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=7 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=8 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=9 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=10 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=11 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=12 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=13 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=14 > /dev/null 2>&1
sudo tgtadm --lld iscsi --op delete --mode=logicalunit --tid=1 --lun=15 > /dev/null 2>&1

echo ''
echo "=============================================="
echo "LUNs deleted from TGT target...               "
echo "=============================================="
echo ''

sleep 2

clear

echo ''
echo "=============================================="
echo "Logout of TGT target...                       "
echo "=============================================="
echo ''

sudo iscsiadm --mode node --targetname $IQN --portal 10.207.40.1:3260 --logout
sudo iscsiadm --mode node --targetname $IQN --portal 10.207.41.1:3260 --logout

echo ''
echo "=============================================="
echo "Logged out of TGT target...                   "
echo "=============================================="
echo ''

sleep 2

clear

echo ''
echo "=============================================="
echo "Delete TGT target...                          "
echo "=============================================="
echo ''

sudo tgtadm --lld iscsi --op delete --mode target --tid=1

echo ''
echo "=============================================="
echo "Delete TGT target completed...                "
echo "=============================================="
echo ''

sleep 2

clear

echo ''
echo "=============================================="
echo "Delete TGT backing files...                   "
echo "=============================================="
echo ''

sudo rm /asm0/* > /dev/null 2>&1
sudo rm /asm1/* > /dev/null 2>&1
sudo rm /asm2/* > /dev/null 2>&1
sudo rm /asm3/* > /dev/null 2>&1
sudo rm /asm4/* > /dev/null 2>&1

echo ''
echo "=============================================="
echo "Delete TGT backing files complete...          "
echo "=============================================="
echo ''

sleep 2

clear

echo ''
echo "=============================================="
echo "Flush any remaining multipaths...             "
echo "=============================================="
echo ''

sudo multipath -F

echo ''
echo "=============================================="
echo "Flush multipaths completed...                 "
echo "=============================================="
echo ''

sleep 2

clear

echo ''
echo "==============================================="
echo "List existing multipath maps...                "
echo "==============================================="
echo ''

ls -l /dev/mapper

echo ''
echo "==============================================="
echo "Verify existing multipath maps removed...      "
echo "'control' should be the only map left...       "
echo "==============================================="
echo ''

sleep 2

clear

echo ''
echo "==============================================="
echo "Start multipath-tools service...               "
echo "==============================================="
echo ''

sudo service multipath-tools start

echo ''
echo "==============================================="
echo "Multipath-tools service started...             "
echo "==============================================="
echo ''

sleep 2

clear

echo ''
echo "==============================================="
echo "Move any existing /etc/multipath.conf file...  "
echo "==============================================="
echo ''

if [ -e /etc/multipath.conf ]
then
sudo mv /etc/multipath.conf /etc/multipath.conf.$DATEXT
fi

echo ''
echo "==============================================="
echo "Existing /etc/multipath.conf file moved...     "
echo "==============================================="
echo ''

