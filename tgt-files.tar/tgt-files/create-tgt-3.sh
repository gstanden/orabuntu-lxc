#!/bin/bash

#    Copyright 2015-2016 Gilbert Standen
#    This file is part of orabuntu-lxc.

#    Orabuntu-lxc is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-lxc is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with orabuntu-lxc.  If not, see <http://www.gnu.org/licenses/>.

#    v2.8 GLS 20151231
#    v3.0 GLS 20160717

clear

echo ''
echo "===================================================="
echo "Dynamically create multipath.conf file...patience..."
echo "===================================================="
echo ''

function GetHostname {
uname -n
}
Hostname=$(GetHostname)

echo '' > ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo 'blacklist {' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    devnode      "sd[a]$"' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf

function GetDevNode {
sudo ls /dev/sd* | sed 's/$/ /' | tr -d '\n'
}
DevNode=$(GetDevNode)
# echo $DevNode

echo ''
echo "Enter sudo password (\"Connection to $Hostname closed\") will be echoed to the screen..."
echo ''

function GetIdAndName {
sshpass ssh -o CheckHostIP=no -o StrictHostKeyChecking=no -t gstanden@"$Hostname" "sudo tgtadm --lld iscsi --op show --mode target | egrep 'SCSI ID|Backing store path' | sed '$!N;s/\n/ /' | sed 's/  */ /g' | cut -f5,9 -d' ' | grep asm | cut -f1,3 -d'/' | cut -f1 -d'.' | sed 's/\///' | sed 's/ /:/' | grep -v closed | sed 's/$/ /' | tr -d '\n'"
}
IdAndName=$(GetIdAndName)

echo ''
echo "Wait about 20 or 30 seconds (up to a minute or two) for the multipath.conf file to be generated..."
echo ''

# echo $IdAndName

for i in $IdAndName
do
function GetLunInfo {
echo $i | grep asm
}
LunInfo=$(GetLunInfo)
# echo $LunInfo
# echo ''
done

for k in $DevNode
do
	function GetVendor {
	sudo udevadm info -a -p  $(udevadm info -q path -n $k) | egrep 'ATTRS{vendor}' | grep -v '0x' | sed 's/  *//g' | rev | cut -f1 -d'=' | sed 's/"//g' | rev | sed 's/$/_DEVICE/'
	}
	Vendor=$(GetVendor)
	# echo $Vendor
 	function GetProduct {
 	sudo udevadm info -a -p  $(udevadm info -q path -n $k) | egrep 'ATTRS{model}' | grep -v '0x' | sed 's/  *//g' | rev | cut -f1 -d'=' | rev
 	}
 	Product=$(GetProduct)
	# echo $Product
	function CheckProductExist {
	cat multipath.conf | grep $Product | rev | cut -f1 -d' ' | rev | sort -u | wc -l
	}
	ProductExist=$(CheckProductExist)
	# echo $ProductExist
	function GetExistId {
	sudo /lib/udev/scsi_id -g -u -d $k
	}
	ExistId=$(GetExistId)
	# echo $ExistId
		if [ "$Vendor" != "IET_DEVICE" ] && [ "$ProductExist" -eq 0 ] && [ ! -z $ExistId ]
		then
			ExistId=$(GetExistId)
			function CheckIdExist {
			grep -c $ExistId ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
			}
			IdExist=$(CheckIdExist)
			if [ "$IdExist" -eq 0 ]
			then
			sudo /lib/udev/scsi_id -g -u -d $k | sed 's/^/    wwid         "/' | sed 's/$/"/' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
			fi
		echo '    device {' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
		sudo udevadm info -a -p  $(udevadm info -q path -n $k) | egrep 'ATTRS{rev}|ATTRS{model}|ATTRS{vendor}' | grep -v 0x | grep vendor | cut -f3 -d'=' | sed 's/  *//g' | sed 's/^/        vendor   /' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
		sudo udevadm info -a -p  $(udevadm info -q path -n $k) | egrep 'ATTRS{rev}|ATTRS{model}|ATTRS{vendor}' | grep -v 0x | grep model  | cut -f3 -d'=' | sed 's/  *//g' | sed 's/^/        product  /' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
		sudo udevadm info -a -p  $(udevadm info -q path -n $k) | egrep 'ATTRS{rev}|ATTRS{model}|ATTRS{vendor}' | grep -v 0x | grep rev    | cut -f3 -d'=' | sed 's/  *//g' | sed 's/^/        revision /' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
		echo '    }' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
		fi
done
echo '}' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf

echo 'defaults {' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    user_friendly_names  yes' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '}' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo 'devices {' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    device {' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    vendor               "TGT"' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo "    product              $Product" >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    revision             "310"' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    path_grouping_policy group_by_serial' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    getuid_callout       "/lib/udev/scsi_id --whitelisted --device=/dev/%n"' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    hardware_handler     "0"' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    features             "1 queue_if_no_path"' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    fast_io_fail_tmo     5' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    dev_loss_tmo         30' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    failback             immediate' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    rr_weight            uniform' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    no_path_retry        fail' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    path_checker         tur' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    rr_min_io            4' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    path_selector        "round-robin 0"' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '    }' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo '}' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
echo 'multipaths {' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf

# Old function line
# sudo scstadmin -list_group | grep systemdg | rev | cut -f1 -d' ' | rev | sed 's/$/ /' | tr -d '\n'

# function GetLunName {
# cat /etc/scst.conf | grep LUN | rev | cut -f1 -d' ' | rev | sed 's/$/ /' | tr -d '\n'
# }
# LunName=$(GetLunName)


for i in $IdAndName
do
	function GetDevNode {
	sudo ls /dev/sd* | sed 's/$/ /' | tr -d '\n'
	}
	DevNode=$(GetDevNode)
	function GetTgtLastEight {
	echo $i | cut -f1 -d':'
	}
	TgtLastEight=$(GetTgtLastEight)
	function GetTgtFriendlyName {
	echo $i | cut -f2 -d':'
	}
	TgtFriendlyName=$(GetTgtFriendlyName)
		for j in $DevNode
		do
		function GetLunLastEight {
		sudo /lib/udev/scsi_id -g -u -d $j | rev | cut -c1-8 | rev
		}
		LunLastEight=$(GetLunLastEight)
		function CheckEntryExist {
		cat ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf | grep $TgtFriendlyName
		}
		if [ ! -z "$TgtFriendlyName" ]
		then
		EntryExist=$(CheckEntryExist)
		fi
		if [ "$TgtLastEight" = "$LunLastEight" ] && [ -z "$EntryExist" ]
		then
			function Getwwid {
			sudo /lib/udev/scsi_id -g -u -d $j
			}
			wwid=$(Getwwid)
			echo "     multipath {" >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
			echo "         wwid $wwid" >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
			echo "         alias $TgtFriendlyName" >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
			echo "     }" >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
		fi
	done
done
echo '}' >> ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf

# GLS 20151126 Added function to get kernel version of running kernel to support linux 4.x kernels in Ubuntu Wily Werewolf etc.

function GetRunningKernelVersion {
uname -r | cut -f1-2 -d'.'
}
RunningKernelVersion=$(GetRunningKernelVersion)

# GLS 20160717 Updated function to get kernel directory path for running kernel version to support all linux 4.x and linux 3.x kernels etc.

function GetKernelDirectoryPath {
uname -a | cut -f3 -d' ' | cut -f1 -d'-' | cut -f1 -d'.' | sed 's/^/linux-/'
}
KernelDirectoryPath=$(GetKernelDirectoryPath)

if [ $KernelDirectoryPath = 'linux-4' ]
then
sed -i 's/revision "/# revision "/' ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf
fi

echo "Review file ~/Downloads/orabuntu-lxc-master/tgt-files/multipath.conf for validity, then run script create-tgt-4.sh ..."
echo ''

echo "===================================================="
echo "Dynamically create multipath.conf file complete.    "
echo "===================================================="
echo ''

