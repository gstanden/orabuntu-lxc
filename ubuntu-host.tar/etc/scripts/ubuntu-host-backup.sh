#!/bin/bash

export DATEXT=`date +'%y%m%d_%H%M%S'`

sudo cp -p /etc/multipath.conf /etc/multipath.conf.lxc.oracle.bak.$DATEXT
sudo cp -p /etc/iscsi/initiatorname.iscsi /etc/iscsi/initiatorname.iscsi.lxc.oracle.bak.$DATEXT
sudo cp -p /etc/dhcp/dhcpd.conf /etc/dhcp/dhcpd.conf.lxc.oracle.bak.$DATEXT
sudo cp -p /etc/dhcp/dhclient.conf /etc/dhcp/dhclient.conf.lxc.oracle.bak.$DATEXT
sudo cp -p /etc/bind/rndc.key /etc/bind/rndc.key.lxc.oracle.bak.$DATEXT
sudo cp -p /etc/default/isc-dhcp-server /etc/default/isc-dhcp-server.lxc.oracle.bak.$DATEXT
sudo cp -p /etc/bind/named.conf.options /etc/bind/named.conf.options.lxc.oracle.bak.$DATEXT
sudo cp -p /etc/bind/named.conf.local /etc/bind/named.conf.local.lxc.oracle.bak.$DATEXT
sudo cp -p /etc/default/bind9 /etc/default/bind9.lxc.oracle.bak.$DATEXT
sudo cp -p /etc/network/interfaces /etc/network/interfaces.lxc.oracle.bak.$DATEXT
sudo cp -p /etc/apparmor.d/lxc/lxc-default /etc/apparmor.d/lxc/lxc-default.lxc.oracle.bak.$DATEXT
sudo cp -p /etc/security/limits.conf /etc/security/limits.conf.lxc.oracle.bak.$DATEXT
sudo cp -p /etc/sysctl.conf /etc/sysctl.conf.lxc.oracle.bak.$DATEXT
sudo cp -p /etc/exports /etc/exports.lxc.oracle.bak.$DATEXT
sudo cp -p /etc/resolv.conf /etc/resolv.conf.lxc.oracle.bak.$DATEXT
