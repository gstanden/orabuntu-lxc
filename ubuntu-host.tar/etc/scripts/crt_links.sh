ln -sf /etc/dhcp .
ln -sf /etc/dhcp/dhcpd.conf .
ln -sf /etc/dhcp/dhclient.conf .
ln -sf /var/lib/bind bind_zone_files
ln -sf /etc/bind bind_config_files
ln -sf /etc/bind/named.conf.options .
ln -sf /etc/bind/named.conf.local .
ln -sf /etc/bind/rndc.key .
ln -sf /var/lib/lxc .
ln -sf /etc/network .
ln -sf /etc/network/interfaces .
ln -sf /etc/network/if-up.d/openvswitch if-up.d-openvswitch
ln -sf /etc/network/if-down.d/openvswitch if-down.d-openvswitch
ln -sf /etc/network/if-up.d/openvswitch-net .
ln -sf /etc/network/openvswitch
ln -sf /etc/network/openvswitch/del-bridges.sh
ln -sf /etc/network/openvswitch/veth_cleanups.sh
ln -sf /etc/network/openvswitch/create-ovs-sw-files-v2.sh
ln -sf /etc/NetworkManager/dnsmasq.d/local .
ln -sf /etc/default/bind9 .
ln -sf /etc/default/isc-dhcp-server .
ln -sf /etc/scripts/stop_containers.sh .
ln -sf /etc/scripts/start_containers.sh .
ln -sf /etc/multipath.conf .
ln -sf /etc/multipath.conf.example .
ln -sf /etc/network/if-down.d/scst-net .
ln -sf /etc/network/openvswitch/crt_ovs_sw1.sh .
ln -sf /etc/network/openvswitch/crt_ovs_sx1.sh .
ln -sf /etc/network/openvswitch/crt_ovs_sw2.sh .
ln -sf /etc/network/openvswitch/crt_ovs_sw3.sh .
ln -sf /etc/network/openvswitch/crt_ovs_sw4.sh .
ln -sf /etc/network/openvswitch/crt_ovs_sw5.sh .
ln -sf /etc/network/openvswitch/crt_ovs_sw6.sh .
ln -sf /etc/network/openvswitch/crt_ovs_sw7.sh .
ln -sf /etc/network/openvswitch/crt_ovs_sw8.sh .
ln -sf /etc/network/openvswitch/crt_ovs_sw9.sh .
