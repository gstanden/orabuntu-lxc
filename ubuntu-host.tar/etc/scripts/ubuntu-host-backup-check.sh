#!/bin/bash

export DATEXT=`date +'%y%m%d_%H%M%S'`

sudo ls -l /etc/multipath.conf.lxc.oracle.bak.$DATEXT
sudo ls -l /etc/iscsi/initiatorname.iscsi.lxc.oracle.bak.$DATEXT
sudo ls -l /etc/dhcp/dhcpd.conf.lxc.oracle.bak.$DATEXT
sudo ls -l /etc/dhcp/dhclient.conf.lxc.oracle.bak.$DATEXT
sudo ls -l /etc/bind/rndc.key.lxc.oracle.bak.$DATEXT
sudo ls -l /etc/default/isc-dhcp-server.lxc.oracle.bak.$DATEXT
sudo ls -l /etc/bind/named.conf.options.lxc.oracle.bak.$DATEXT
sudo ls -l /etc/bind/named.conf.local.lxc.oracle.bak.$DATEXT
sudo ls -l /etc/default/bind9.lxc.oracle.bak.$DATEXT
sudo ls -l /etc/apparmor.d/lxc/lxc-default.lxc.oracle.bak.$DATEXT
sudo ls -l /etc/security/limits.conf.lxc.oracle.bak.$DATEXT
sudo ls -l /etc/sysctl.conf.lxc.oracle.bak.$DATEXT
sudo ls -l /etc/exports.lxc.oracle.bak.$DATEXT
sudo ls -l /etc/resolv.conf.lxc.oracle.bak.$DATEXT
