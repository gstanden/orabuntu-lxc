mkdir -p /u00/app/18c/grid
mkdir -p /u00/app/grid/product/18c/grid
chown -R grid:oinstall /u00
mkdir -p /u00/app/oracle
chown oracle:oinstall /u00/app/oracle
chmod -R 775 /u00

