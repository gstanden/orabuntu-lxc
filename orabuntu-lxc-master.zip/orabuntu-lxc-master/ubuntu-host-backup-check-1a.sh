# sudo ls -l /etc/multipath.conf.lxc.oracle.bak
sudo ls -l /etc/iscsi/initiatorname.iscsi.lxc.oracle.bak
sudo ls -l /etc/dhcp/dhcpd.conf.lxc.oracle.bak
sudo ls -l /etc/dhcp/dhclient.conf.lxc.oracle.bak
sudo ls -l /etc/bind/rndc.key.lxc.oracle.bak
sudo ls -l /etc/default/isc-dhcp-server.lxc.oracle.bak
sudo ls -l /etc/bind/named.conf.options.lxc.oracle.bak
sudo ls -l /etc/bind/named.conf.local.lxc.oracle.bak
sudo ls -l /etc/default/bind9.lxc.oracle.bak
# sudo ls -l /var/lib/bind/rev.vmem.org.lxc.oracle.bak
# sudo ls -l /var/lib/bind/fwd.vmem.org.lxc.oracle.bak
# sudo ls -l /var/lib/bind/rev.mccc.org.lxc.oracle.bak
# sudo ls -l /var/lib/bind/fwd.mccc.org.lxc.oracle.bak
# sudo ls -l /etc/NetworkManager/dnsmasq.d/local.lxc.oracle.bak
# sudo ls -l /etc/network/interfaces.lxc.oracle.bak
# sudo ls -l /etc/network/if-up.d/openvswitch-net.lxc.oracle.bak
# sudo ls -l /etc/network/if-up.d/openvswitch.lxc.oracle.bak
# sudo ls -l /etc/network/if-down.d/openvswitch.lxc.oracle.bak
# sudo ls -l /home/gstanden/OpenvSwitch/crt_ovs_sw1.sh.lxc.oracle.bak
# sudo ls -l /home/gstanden/OpenvSwitch/crt_ovs_sw2.sh.lxc.oracle.bak
# sudo ls -l /home/gstanden/OpenvSwitch/crt_ovs_sw3.sh.lxc.oracle.bak
# sudo ls -l /home/gstanden/OpenvSwitch/crt_ovs_sw4.sh.lxc.oracle.bak
# sudo ls -l /home/gstanden/OpenvSwitch/crt_ovs_sw5.sh.lxc.oracle.bak
# sudo ls -l /home/gstanden/OpenvSwitch/crt_ovs_sw6.sh.lxc.oracle.bak
# sudo ls -l /home/gstanden/OpenvSwitch/crt_ovs_sw7.sh.lxc.oracle.bak
# sudo ls -l /home/gstanden/OpenvSwitch/crt_ovs_sw8.sh.lxc.oracle.bak
# sudo ls -l /home/gstanden/OpenvSwitch/crt_ovs_sw9.sh.lxc.oracle.bak
# sudo ls -l /home/gstanden/OpenvSwitch/crt_ovs_sx1.sh.lxc.oracle.bak
# sudo ls -l /home/gstanden/OpenvSwitch/del-bridges.sh.lxc.oracle.bak
# sudo ls -l /home/gstanden/OpenvSwitch/create_asm_luns.sh.lxc.oracle.bak
# sudo ls -l /home/gstanden/Networking/nslookups.sh.lxc.oracle.bak
# sudo ls -l /home/gstanden/Networking/crt_links.sh.lxc.oracle.bak
sudo ls -l /etc/apparmor.d/lxc/lxc-default.lxc.oracle.bak
sudo ls -l /etc/security/limits.conf.lxc.oracle.bak
sudo ls -l /etc/sysctl.conf.lxc.oracle.bak
sudo ls -l /etc/exports.lxc.oracle.bak
sudo ls -l /etc/resolv.conf.lxc.oracle.bak
