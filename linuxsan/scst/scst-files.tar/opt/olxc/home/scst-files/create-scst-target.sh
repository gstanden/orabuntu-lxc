#!/bin/bash
#
#    Copyright 2015-2021 Gilbert Standen
#    This file is part of Orabuntu-LXC.

#    Orabuntu-LXC is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-LXC is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with Orabuntu-LXC.  If not, see <http://www.gnu.org/licenses/>.

#    v2.4 		GLS 20151224
#    v2.8 		GLS 20151231
#    v3.0 		GLS 20160710 Updates for Ubuntu 16.04
#    v4.0 		GLS 20161025 DNS DHCP services moved into an LXC container
#    v5.0 		GLS 20170909 Orabuntu-LXC Multi-Host
#    v6.0-AMIDE-beta	GLS 20180106 Orabuntu-LXC AmazonS3 Multi-Host Docker Enterprise Edition (AMIDE)
#    v7.0-ELENA-beta    GLS 20210428 Enterprise LXD Edition New AMIDE

#    Note that this software builds a containerized DNS DHCP solution (bind9 / isc-dhcp-server).
#    The nameserver should NOT be the name of an EXISTING nameserver but an arbitrary name because this software is CREATING a new LXC-containerized nameserver.
#    The domain names can be arbitrary fictional names or they can be a domain that you actually own and operate.
#    There are two domains and two networks because the "seed" LXC containers are on a separate network from the production LXC containers.
#    If the domain is an actual domain, you will need to change the subnet using the subnets feature of Orabuntu-LXC

#    !! SEE THE README FILE FOR COMPLETE INSTRUCTIONS FIRST BEFORE RUNNING !!
#
#    sudo ALL privilege is required      prior to running!
#    internet connectivity is required   prior to running!
#
# Note:		Following line shows options you can set for running create-scst-target.sh in this file.
#       	Set the com.yourdomain, the scstadmin groupname, the ASM redundancy, the sizes of your LUNs, and the logical blocksize in this file if you want non-default values.
#       	Review the create-scst-target.sh for more details and/or the README file.
#
# Example:	create-scst-target.sh com.urdomain1 lxc1 [external|normal|high] 10G 30G 30G [512|4096]
#
# IMPORTANT!    Remeber that if you use non-default settings for create-scst-target.sh BE SURE TO SPECIFY ALL OF THEM $1 through $7 !!  Otherwise they will be misinterpreted by the script.
#    Note1:     If you do not pass in a "com.yourdomain" parameter it will be set to default value of com.urdomain1
#    Note2:     If you do not pass in a "ScstGroupName"  parameter it will be set to default value of lxc1
#    Note3:     If you do not pass in a "LunRedundancy"  parameter it will be set to default value of external
#    Note4:     If you do not pass in a "GrpA1SizeGb"    parameter it will be set to default value of 1Gb
#    Note5:     If you do not pass in a "GrpB1SizeGb"    parameter it will be set to default value of 1Gb 
#    Note6:     If you do not pass in a "GrpC1SizeGb"    parameter it will be set to default value of 1Gb 
#    Note7:     If you do not pass in a "LogicalBlkSiz"  parameter it will be set to default value of 512 (optionally set to 4096)

# Determine if sudo prefix is needed on commands

# create-scst-target.sh ubuntu ubuntu 0660 k8s_luns   ubuntu k8s   com.urdomain1 k8s1 external pool cont kube  1G  1G 1G 512 kubernetes $SUDO_PREFIX
# create-scst-target.sh ubuntu ubuntu 0660 zpool_luns ubuntu zpool com.urdomain1 zfs1 external zfsa zfsm zfsb 25G 25G 1G 512 zfspool    $SUDO_PREFIX $LXDStorageDriver


StorageOwner=$1
if [ -z $1 ]
then
	StorageOwner=grid
fi

StorageGroup=$2
if [ -z $2 ]
then
	StorageGroup=asmadmin
fi

Mode=$3
if [ -z $3 ]
then
	Mode=0660
fi

StoragePrefix=$6
if [ -z $6 ]
then
	StoragePrefix=asm
fi

ContainerName=$4
if [ -z $4 ]
then
	ContainerName="$StoragePrefix"_luns
fi

Owner=$5
if [ -z $5 ]
then
	Owner=oracle
fi

SUDO_PREFIX=${18}
if [ -z ${18} ]
then
	SUDO_PREFIX=sudo	
fi

LXDStorageDriver=${19}
if [ -z ${19} ]
then
	LXDStorageDriver=none
fi

function GetRPath {
        which rm
} 
RPath=$(GetRPath)

function GetUPath {
        which udevadm
}
UPath=$(GetUPath)

function GetMPath {
        which multipath
}
MPath=$(GetMPath)

function GetIPath {
        which iscsiadm
}
IPath=$(GetIPath)

function GetSPath {
        which service
}
SPath=$(GetSPath)

function GetDPath {
        which mkdir
}
DPath=$(GetDPath)

function GetOPath {
        which sudo
}
OPath=$(GetOPath)

GetLinuxFlavors(){
if   [[ -e /etc/oracle-release ]]
then
        LinuxFlavors=$(cat /etc/oracle-release | cut -f1 -d' ')
elif [[ -e /etc/redhat-release ]]
then
        LinuxFlavors=$(cat /etc/redhat-release | cut -f1 -d' ')
elif [[ -e /usr/bin/lsb_release ]]
then
        LinuxFlavors=$(lsb_release -d | awk -F ':' '{print $2}' | cut -f1 -d' ')
elif [[ -e /etc/issue ]]
then
        LinuxFlavors=$(cat /etc/issue | cut -f1 -d' ')
else
        LinuxFlavors=$(cat /proc/version | cut -f1 -d' ')
fi
}
GetLinuxFlavors

function TrimLinuxFlavors {
	echo $LinuxFlavors | sed 's/^[ \t]//;s/[ \t]$//'
}
LinuxFlavor=$(TrimLinuxFlavors)

if   [ $LinuxFlavor = 'Oracle' ]
then
        function GetOracleDistroRelease {
                $SUDO_PREFIX cat /etc/oracle-release | cut -f5 -d' ' | cut -f1 -d'.'
        }
        OracleDistroRelease=$(GetOracleDistroRelease)
        if   [ $OracleDistroRelease -eq 7 ] || [ $OracleDistroRelease -eq 6 ]
        then
                CutIndex=7
        elif [ $OracleDistroRelease -eq 8 ]
        then
                CutIndex=6
        fi
        function GetRedHatVersion {
                $SUDO_PREFIX cat /etc/redhat-release | cut -f"$CutIndex" -d' ' | cut -f1 -d'.'
        }
        RedHatVersion=$(GetRedHatVersion)
        RHV=$RedHatVersion
        function GetOracleDistroRelease {
                $SUDO_PREFIX cat /etc/oracle-release | cut -f5 -d' ' | cut -f1 -d'.'
        }
        OracleDistroRelease=$(GetOracleDistroRelease)
        Release=$OracleDistroRelease
        LF=$LinuxFlavor
        RL=$Release
elif [ $LinuxFlavor = 'Red' ] || [ $LinuxFlavor = 'CentOS' ]
then
        if   [ $LinuxFlavor = 'Red' ]
        then
                function GetRedHatVersion {
                        $SUDO_PREFIX cat /etc/redhat-release | cut -f7 -d' ' | cut -f1 -d'.'
                }
                RedHatVersion=$(GetRedHatVersion)
        elif [ $LinuxFlavor = 'CentOS' ]
        then
                function GetRedHatVersion {
                        cat /etc/redhat-release | sed 's/ Linux//' | cut -f1 -d'.' | rev | cut -f1 -d' '
                }
                RedHatVersion=$(GetRedHatVersion)
        fi
        RHV=$RedHatVersion
        Release=$RedHatVersion
        LF=$LinuxFlavor
        RL=$Release
elif [ $LinuxFlavor = 'Fedora' ]
then
        CutIndex=3
        function GetRedHatVersion {
                $SUDO_PREFIX cat /etc/redhat-release | cut -f"$CutIndex" -d' ' | cut -f1 -d'.'
        }
        RedHatVersion=$(GetRedHatVersion)
        RHV=$RedHatVersion
        if   [ $RedHatVersion -ge 28 ]
        then
                Release=8
	elif [ $RedHatVersion -ge 19 ] || [ $RedHatVersion -le 27 ]
	then
		Release=7
        elif [ $RedHatVersion -ge 12 ] && [ $RedHatVersion -le 18 ]
        then
                Release=6
        fi
        LF=$LinuxFlavor
        RL=$Release
elif [ $LinuxFlavor = 'Ubuntu' ]
then
        function GetUbuntuVersion {
                cat /etc/lsb-release | grep DISTRIB_RELEASE | cut -f2 -d'='
        }
        UbuntuVersion=$(GetUbuntuVersion)
        LF=$LinuxFlavor
        RL=$UbuntuVersion
        function GetUbuntuMajorVersion {
                cat /etc/lsb-release | grep DISTRIB_RELEASE | cut -f2 -d'=' | cut -f1 -d'.'
        }
        UbuntuMajorVersion=$(GetUbuntuMajorVersion)
fi

if [ $LinuxFlavor = 'CentOS' ] || [ $LinuxFlavor = 'Fedora' ]
then
	LinuxFlavor=Red
fi

function GetInitiatorName {
	$SUDO_PREFIX cat /etc/iscsi/initiatorname.iscsi | grep -v '#' | grep iqn | cut -f2 -d'=' 
}
InitiatorName=$(GetInitiatorName)

function GetHostName {
	echo $HOSTNAME 
}
HostName=$(GetHostName)

DATEYR=`date +"%Y"`
DATEMO=`date +"%m"`

# Determine User-Selected Reversed Domain IQN prefix or set it to default (com.orabuntu-lxc)

DOMAIN=$7
if [ -z $7 ]
then
	DOMAIN=com.orabuntu-lxc
fi

# Determine User-Selected SCST Group Name  or set to default (lxc1)

ScstGroup=$8
if [ -z $8 ]
then
	ScstGroup=lxc1
fi

# Determine User-Selected redundancy or set to default (external)

LunRedundancy=$9

function SetCaseLunRedundancy {
	echo $LunRedundancy | sed -e 's/\([A-Z][A-Za-z0-9]*\)/\L\1/g'
}
LunRedundancy=$(SetCaseLunRedundancy)

if [ -z "$9" ]
then
	LunRedundancy=external
fi

if   [ "$LunRedundancy" = 'external' ]
then
	echo 'LunRedundancy = '$LunRedundancy > /dev/null 2>&1
elif [ "$LunRedundancy" = 'normal' ]
then
	echo $LunRedundancy
elif [ "$LunRedundancy" = 'high' ]
then
	echo 'LunRedundancy = '$LunRedundancy > /dev/null 2>&1
else
	echo "LunRedundancy must be in the set {external, normal, high}"
	echo "Current setting of LunRedundancy is $LunRedundancy"
	echo "Rerun program with correct spelling of external, normal, or high"
fi

GrpA=${10}
if [ -z ${10} ]
then
	GrpA=sysd
fi

GrpB=${11}
if [ -z ${11} ]
then
	GrpB=data
fi

GrpC=${12}
if [ -z ${12} ]
then
	GrpC=reco
fi

# GLS 20180210 https://samindaw.wordpress.com/tag/dynamically-create-variables-in-bash-script/
# GLS 20180210 Create and access shell variable having a name created by another string

eval "$GrpA"1SizeGb=${13}
GrpA1SizeGb="$GrpA"1SizeGb
if [ -z ${13} ]
then
	eval "$GrpA"1SizeGb=1G
	GrpA1SizeGb="$GrpA"1SizeGb
fi

eval "$GrpB"1SizeGb=${14}
GrpB1SizeGb="$GrpB"1SizeGb
if [ -z ${14} ]
then
	eval "$GrpB"1SizeGb=1G
	GrpB1SizeGb="$GrpB"1SizeGb
fi

eval "$GrpC"1SizeGb=${15}
GrpC1SizeGb="$GrpC"1SizeGb
if [ -z ${15} ]
then
	eval "$GrpC"1SizeGb=1G
	GrpC1SizeGb="$GrpC"1SizeGb
fi

LogicalBlkSiz=${16}
if [ -z ${16} ]
then
	LogicalBlkSiz=512
fi

if [ $LogicalBlkSiz -ne 4096 ] && [ $LogicalBlkSiz -ne 512 ]
then
	echo 'Error invalid block size'
	exit
fi

product=${17}
if [ -z ${17} ]
then
	product=oracle
fi

sleep 5

clear

echo ''
echo "======================================================"
echo "Display SCST Install settings...                      "
echo "======================================================"
echo ''

echo 'StorageOwner	= '$StorageOwner
echo 'StorageGroup	= '$StorageGroup
echo 'Mode		= '$Mode
echo 'ContainerName	= '$ContainerName
echo 'Owner		= '$Owner
echo 'StoragePrefix	= '$StoragePrefix
echo 'DATEYR        	= '$DATEYR
echo 'DATEMO        	= '$DATEMO
echo 'Domain        	= '$DOMAIN
echo 'ScstGroup     	= '$ScstGroup
echo 'LunRedundancy 	= '$LunRedundancy
echo 'GrpA		= '$GrpA
echo 'GrpB		= '$GrpB
echo 'GrpC		= '$GrpC
echo 'GrpA1SizeGb   	= '${!GrpA1SizeGb}
echo 'GrpB1SizeGb   	= '${!GrpB1SizeGb}
echo 'GrpC1SizeGb   	= '${!GrpC1SizeGb}
echo 'Initiatorname 	= '$InitiatorName
echo 'HostName      	= '$HostName
echo 'LogicalBlkSiz 	= '$LogicalBlkSiz
echo 'Product       	= '$product

echo ''
echo "======================================================"
echo "SCST Install settings displayed.                      "
echo "======================================================"

sleep 10

clear

echo ''
echo "======================================================"
echo "Display target, group, and initiators...              "
echo "======================================================"
echo ''

sleep 10

# Create Target and Groups

$SUDO_PREFIX scstadmin -add_target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -driver iscsi
$SUDO_PREFIX scstadmin -add_group $ScstGroup -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product
$SUDO_PREFIX scstadmin -add_init $InitiatorName -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup
$SUDO_PREFIX scstadmin -write_config /etc/scst.conf

$SUDO_PREFIX scstadmin -list_group

echo ''
echo "======================================================"
echo "Target, group, and initiator displayed.               "
echo "======================================================"

sleep 5

clear

# Create file-backed devices for LUNS for Oracle ASM diskgroup SYSD1

if [ "$LunRedundancy" = 'external' ]
then
	
	if [ ! -e /"$StoragePrefix"0 ]
	then
		$SUDO_PREFIX mkdir /"$StoragePrefix"0
	fi
	
	$SUDO_PREFIX fallocate -l ${!GrpA1SizeGb} /"$StoragePrefix"0/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_00.img

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for "$GrpA"1 "
	echo "======================================================"
	echo ''

	ls -lrt /"$StoragePrefix"0/"$StoragePrefix"_"$GrpA"*
	
	sleep 5

	$SUDO_PREFIX fallocate -l ${!GrpB1SizeGb} /"$StoragePrefix"0/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_00.img
	$SUDO_PREFIX fallocate -l ${!GrpC1SizeGb} /"$StoragePrefix"0/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_00.img

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for "$GrpB"1 "
	echo "======================================================"
	echo ''

	ls -lrt /"$StoragePrefix"0/"$StoragePrefix"_"$GrpB"*

	sleep 5

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for "$GrpC"1 "
	echo "======================================================"
	echo ''

	ls -lrt /"$StoragePrefix"0/"$StoragePrefix"_"$GrpC"*

	sleep 5
	
	echo ''
	echo "======================================================"
	echo "Devices for "$GrpA"1, "$GrpB"1, and "$GrpC"1 displayed"
	echo "======================================================"

	sleep 5

	clear
	
	echo ''
	echo "======================================================"
	echo "Open SCST devices and create LUNs...                  "
	echo "======================================================"
	echo ''

	sleep 5

	# Open file-backed devices for Oracle ASM diskgroup SYSD1
	
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_00 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"0/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_00.img

	# Open file-backed devices for Oracle ASM diskgroups DATA and FRA

	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_00 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"0/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_00.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_00 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"0/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_00.img

	# Add LUNs for Oracle ASM diskgroup SYSD1 to SCST iscsi target

	$SUDO_PREFIX scstadmin -add_lun 0 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_00

	# Add LUNs for Oracle ASM diskgroups DATA and FRA to SCST iscsi target

	$SUDO_PREFIX scstadmin -add_lun 1 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_00
	$SUDO_PREFIX scstadmin -add_lun 2 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_00
	
	echo ''
	echo "======================================================"
	echo "SCST devices and LUNs configured.                     "
	echo "======================================================"

	sleep 5

	clear

fi

if [ "$LunRedundancy" = 'normal' ]
then

	if [ ! -e /"$StoragePrefix"0 ]
	then
		$SUDO_PREFIX mkdir /"$StoragePrefix"0
	fi

	if [ ! -e /"$StoragePrefix"1 ]
	then
		$SUDO_PREFIX mkdir /"$StoragePrefix"1
	fi

	if [ ! -e /"$StoragePrefix"2 ]
	then
		$SUDO_PREFIX mkdir /"$StoragePrefix"2
	fi

	$SUDO_PREFIX fallocate -l ${!GrpA1SizeGb} /"$StoragePrefix"0/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_00.img
	$SUDO_PREFIX fallocate -l ${!GrpA1SizeGb} /"$StoragePrefix"1/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_01.img
	$SUDO_PREFIX fallocate -l ${!GrpA1SizeGb} /"$StoragePrefix"2/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_02.img

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for "$GrpA"1 "
	echo "Sleeping for 10 seconds...                            "
	echo "======================================================"
	echo ''

	ls -lrt /"$StoragePrefix"0/"$StoragePrefix"_"$GrpA"1*
	ls -lrt /"$StoragePrefix"1/"$StoragePrefix"_"$GrpA"1*
	ls -lrt /"$StoragePrefix"2/"$StoragePrefix"_"$GrpA"1*

	sleep 10

	# Create file-backed devices for LUNS for Oracle ASM diskgroups DATA and FRA

	$SUDO_PREFIX fallocate -l ${!GrpB1SizeGb} /"$StoragePrefix"0/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_00.img
	$SUDO_PREFIX fallocate -l ${!GrpB1SizeGb} /"$StoragePrefix"1/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_01.img
	$SUDO_PREFIX fallocate -l ${!GrpB1SizeGb} /"$StoragePrefix"2/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_02.img

	$SUDO_PREFIX fallocate -l ${!GrpC1SizeGb} /"$StoragePrefix"0/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_00.img
	$SUDO_PREFIX fallocate -l ${!GrpC1SizeGb} /"$StoragePrefix"1/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_01.img
	$SUDO_PREFIX fallocate -l ${!GrpC1SizeGb} /"$StoragePrefix"2/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_02.img

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for $GrpB    "
	echo "Sleeping for 10 seconds...                            "
	echo "======================================================"
	echo ''

	ls -lrt /"$StoragePrefix"0/"$StoragePrefix"_$GrpB*
	ls -lrt /"$StoragePrefix"1/"$StoragePrefix"_$GrpB*
	ls -lrt /"$StoragePrefix"2/"$StoragePrefix"_$GrpB*

	sleep 10

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for "$GrpC"  "
	echo "Sleeping for 10 seconds...                            "
	echo "======================================================"
	echo ''

	ls -lrt /"$StoragePrefix"0/"$StoragePrefix"_"$GrpC"*
	ls -lrt /"$StoragePrefix"1/"$StoragePrefix"_"$GrpC"*
	ls -lrt /"$StoragePrefix"2/"$StoragePrefix"_"$GrpC"*

	sleep 10

	# Open file-backed devices for Oracle ASM diskgroup SYSD1

	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_00 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"0/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_00.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_01 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"1/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_01.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_02 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"2/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_02.img

	# Open file-backed devices for Oracle ASM diskgroups DATA and FRA

	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_00 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"0/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_00.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_01 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"1/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_01.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_02 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"2/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_02.img

	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_00 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"0/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_00.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_01 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"1/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_01.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_02 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"2/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_02.img

	# Add LUNs for Oracle ASM diskgroup SYSD1 to SCST iscsi target

	$SUDO_PREFIX scstadmin -add_lun 0 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_00
	$SUDO_PREFIX scstadmin -add_lun 1 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_01
	$SUDO_PREFIX scstadmin -add_lun 2 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_02

	# Add LUNs for Oracle ASM diskgroups DATA and FRA to SCST iscsi target

	$SUDO_PREFIX scstadmin -add_lun 3 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_00
	$SUDO_PREFIX scstadmin -add_lun 4 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_01
	$SUDO_PREFIX scstadmin -add_lun 5 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_02

	$SUDO_PREFIX scstadmin -add_lun 6 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_00
	$SUDO_PREFIX scstadmin -add_lun 7 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_01
	$SUDO_PREFIX scstadmin -add_lun 8 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_02
fi

if [ "$LunRedundancy" = 'high' ]
then

	if [ ! -e /"$StoragePrefix"0 ]
	then
		$SUDO_PREFIX mkdir /"$StoragePrefix"0
	fi

	if [ ! -e /"$StoragePrefix"1 ]
	then
		$SUDO_PREFIX mkdir /"$StoragePrefix"1
	fi

	if [ ! -e /"$StoragePrefix"2 ]
	then
		$SUDO_PREFIX mkdir /"$StoragePrefix"2
	fi

	if [ ! -e /"$StoragePrefix"3 ]
	then
		$SUDO_PREFIX mkdir /"$StoragePrefix"3
	fi

	if [ ! -e /"$StoragePrefix"4 ]
	then
		$SUDO_PREFIX mkdir /"$StoragePrefix"4
	fi

	$SUDO_PREFIX fallocate -l ${!GrpA1SizeGb} /"$StoragePrefix"0/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_00.img
	$SUDO_PREFIX fallocate -l ${!GrpA1SizeGb} /"$StoragePrefix"1/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_01.img
	$SUDO_PREFIX fallocate -l ${!GrpA1SizeGb} /"$StoragePrefix"2/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_02.img
	$SUDO_PREFIX fallocate -l ${!GrpA1SizeGb} /"$StoragePrefix"3/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_03.img
	$SUDO_PREFIX fallocate -l ${!GrpA1SizeGb} /"$StoragePrefix"4/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_04.img

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for "$GrpA"1 "
	echo "Sleeping for 10 seconds...                            "
	echo "======================================================"
	echo ''

	ls -lrt /"$StoragePrefix"0/"$StoragePrefix"_"$GrpA"1*
	ls -lrt /"$StoragePrefix"1/"$StoragePrefix"_"$GrpA"1*
	ls -lrt /"$StoragePrefix"2/"$StoragePrefix"_"$GrpA"1*
	ls -lrt /"$StoragePrefix"3/"$StoragePrefix"_"$GrpA"1*
	ls -lrt /"$StoragePrefix"4/"$StoragePrefix"_"$GrpA"1*

	sleep 10

	# Create file-backed devices for LUNS for Oracle ASM diskgroups DATA and FRA

	$SUDO_PREFIX fallocate -l ${!GrpB1SizeGb} /"$StoragePrefix"0/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_00.img
	$SUDO_PREFIX fallocate -l ${!GrpB1SizeGb} /"$StoragePrefix"1/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_01.img
	$SUDO_PREFIX fallocate -l ${!GrpB1SizeGb} /"$StoragePrefix"2/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_02.img
	$SUDO_PREFIX fallocate -l ${!GrpB1SizeGb} /"$StoragePrefix"3/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_03.img
	$SUDO_PREFIX fallocate -l ${!GrpB1SizeGb} /"$StoragePrefix"4/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_04.img

	$SUDO_PREFIX fallocate -l ${!GrpC1SizeGb} /"$StoragePrefix"0/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_00.img
	$SUDO_PREFIX fallocate -l ${!GrpC1SizeGb} /"$StoragePrefix"1/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_01.img
	$SUDO_PREFIX fallocate -l ${!GrpC1SizeGb} /"$StoragePrefix"2/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_02.img
	$SUDO_PREFIX fallocate -l ${!GrpC1SizeGb} /"$StoragePrefix"3/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_03.img
	$SUDO_PREFIX fallocate -l ${!GrpC1SizeGb} /"$StoragePrefix"4/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_04.img

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for $GrpB    "
	echo "Sleeping for 10 seconds...                            "
	echo "======================================================"
	echo ''

	ls -lrt /"$StoragePrefix"0/"$StoragePrefix"_$GrpB*
	ls -lrt /"$StoragePrefix"1/"$StoragePrefix"_$GrpB*
	ls -lrt /"$StoragePrefix"2/"$StoragePrefix"_$GrpB*
	ls -lrt /"$StoragePrefix"3/"$StoragePrefix"_$GrpB*
	ls -lrt /"$StoragePrefix"4/"$StoragePrefix"_$GrpB*

	sleep 10

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for "$GrpC"  "
	echo "Sleeping for 10 seconds...                            "
	echo "======================================================"
	echo ''

	ls -lrt /"$StoragePrefix"0/"$StoragePrefix"_"$GrpC"*
	ls -lrt /"$StoragePrefix"1/"$StoragePrefix"_"$GrpC"*
	ls -lrt /"$StoragePrefix"2/"$StoragePrefix"_"$GrpC"*
	ls -lrt /"$StoragePrefix"3/"$StoragePrefix"_"$GrpC"*
	ls -lrt /"$StoragePrefix"4/"$StoragePrefix"_"$GrpC"*

	sleep 10

	# Open file-backed devices for Oracle ASM diskgroup SYSD1

	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_00 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"0/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_00.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_01 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"1/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_01.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_02 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"2/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_02.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_03 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"3/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_03.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_04 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"4/"$StoragePrefix"_"$GrpA"_"SWITCH_IP"_04.img

	# Open file-backed devices for Oracle ASM diskgroups DATA and FRA

	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_00 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"0/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_00.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_01 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"1/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_01.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_02 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"2/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_02.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_03 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"3/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_03.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_04 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"4/"$StoragePrefix"_"$GrpB"_"SWITCH_IP"_04.img

	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_00 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"0/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_00.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_01 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"1/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_01.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_02 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"2/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_02.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_03 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"3/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_03.img
	$SUDO_PREFIX scstadmin -open_dev "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_04 -handler vdisk_fileio -attributes filename=/"$StoragePrefix"4/"$StoragePrefix"_"$GrpC"_"SWITCH_IP"_04.img

	# Add LUNs for Oracle ASM diskgroup SYSD1 to SCST iscsi target

	$SUDO_PREFIX scstadmin -add_lun 0 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_00
	$SUDO_PREFIX scstadmin -add_lun 1 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_01
	$SUDO_PREFIX scstadmin -add_lun 2 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_02
	$SUDO_PREFIX scstadmin -add_lun 3 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_03
	$SUDO_PREFIX scstadmin -add_lun 4 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpA"_"SWITCH_IP"_04

	# Add LUNs for Oracle ASM diskgroups DATA and FRA to SCST iscsi target

	$SUDO_PREFIX scstadmin -add_lun 5 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_00
	$SUDO_PREFIX scstadmin -add_lun 6 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_01
	$SUDO_PREFIX scstadmin -add_lun 7 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_02
	$SUDO_PREFIX scstadmin -add_lun 8 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_03
	$SUDO_PREFIX scstadmin -add_lun 9 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpB"_"SWITCH_IP"_04

	$SUDO_PREFIX scstadmin -add_lun 10 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_00
	$SUDO_PREFIX scstadmin -add_lun 11 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_01
	$SUDO_PREFIX scstadmin -add_lun 12 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_02
	$SUDO_PREFIX scstadmin -add_lun 13 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_03
	$SUDO_PREFIX scstadmin -add_lun 14 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -group $ScstGroup -device "$StoragePrefix"_"$GrpC"_"SWITCH_IP"_04

fi

echo ''
echo "======================================================="
echo "Write SCST configuration to /etc/scst.conf file...     "
echo "======================================================="

sleep 5

$SUDO_PREFIX scstadmin -write_config /etc/scst.conf
$SUDO_PREFIX cat /etc/scst.conf

echo "======================================================="
echo "Write SCST configuration to /etc/scst.conf file...     "
echo "======================================================="

sleep 10

clear

echo ''
echo "======================================================="
echo " Enable SCST target for access...                      "
echo "======================================================="
echo ''

$SUDO_PREFIX scstadmin -enable_target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -driver iscsi
$SUDO_PREFIX scstadmin -write_config /etc/scst.conf

echo ''
echo "======================================================="
echo " Enable SCST target for access completed.              "
echo "======================================================="

sleep 5

clear

echo ''
echo "======================================================="
echo "Answer 'y' is passed automatically...                  "
echo "======================================================="
 
echo "y
quit
" | $SUDO_PREFIX scstadmin -set_drv_attr iscsi -attributes enabled=1 
sleep 5
$SUDO_PREFIX scstadmin -write_config /etc/scst.conf

echo ''
echo "======================================================="
echo "Attribute configured.                                  "
echo "======================================================="

sleep 5

clear

function GetUbuntuMajorRelease {
	lsb_release -r | cut -f1 -d'.' | cut -f2 -d':' | sed 's/^[ \t]*//;s/[ \t]*$//'
}
UbuntuMajorRelease=$(GetUbuntuMajorRelease)

if [ $UbuntuMajorRelease -gt 14 ] || [ $LinuxFlavor = 'Red' ] || [ $LinuxFlavor = 'Oracle' ]
then
	echo ''
	echo "======================================================="
	echo "Create files needed for the (olxc-scst) service...     "
	echo "======================================================="
	echo ''
else
	echo ''
	echo "======================================================="
	echo "Create Upstart Job and Autostart for SCST...           "
	echo "======================================================="
	echo ''
fi

sleep 5

if [ ! -d /etc/network/openvswitch ]
then
	$SUDO_PREFIX mkdir -p /etc/network/openvswitch
fi

if [ ! -d /etc/network/if-down.d ]
then
	$SUDO_PREFIX mkdir -p /etc/network/if-down.d
fi

Sw1Exist=sw
ifconfig sw1 >/dev/null 2>&1
if [ $? -eq 0 ]
then
	if   [ $LinuxFlavor = 'Red' ] || [ $LinuxFlavor = 'Oracle' ]
	then
		if   [ $Release -eq 7 ] || [ $Release -eq 8 ]
		then
			function CheckSw1Exist {
				ifconfig sw1 | cut -f1 -d':' | head -1
			}
	
		elif [ $Release -eq 6 ]
		then
			function CheckSw1Exist {
				ifconfig sw1 | cut -f1 -d':' | head -1 | cut -f1 -d' '
			}
		fi
		Sw1Exist=$(CheckSw1Exist)

	elif [ $LinuxFlavor = 'Ubuntu' ] || [ $LinuxFlavor = 'Pop_OS' ]
	then
		function CheckSw1Exist {
			ifconfig sw1 | cut -f1 -d':' | head -1 | cut -f1 -d' '
		}
		Sw1Exist=$(CheckSw1Exist)

	elif [ $LinuxFlavor = 'Debian' ] 
	then
		function CheckSw1Exist {
			ifconfig sw1 | cut -f1 -d':' | head -1 | cut -f1 -d' '
		}
		Sw1Exist=$(CheckSw1Exist)
	fi
fi

Sw2Exist=sw
ifconfig sw2 >/dev/null 2>&1
if [ $? -eq 0 ]
then
	if   [ $LinuxFlavor = 'Red' ] || [ $LinuxFlavor = 'Oracle' ]
	then
		if   [ $Release -eq 7 ] || [ $Release -eq 8 ]
		then
			function CheckSw2Exist {
				ifconfig sw2 | cut -f1 -d':' | head -1
			}
	
		elif [ $Release -eq 6 ]
		then
			function CheckSw2Exist {
				ifconfig sw2 | cut -f1 -d':' | head -1 | cut -f1 -d' '
			}
		fi
		Sw2Exist=$(CheckSw2Exist)

	elif [ $LinuxFlavor = 'Ubuntu' ] || [ $LinuxFlavor = 'Pop_OS' ]
	then
		function CheckSw2Exist {
			ifconfig sw2 | cut -f1 -d':' | head -1 | cut -f1 -d' '
		}
		Sw2Exist=$(CheckSw2Exist)

	elif [ $LinuxFlavor = 'Debian' ] 
	then
		function CheckSw2Exist {
			ifconfig sw2 | cut -f1 -d':' | head -1 | cut -f1 -d' '
		}
		Sw2Exist=$(CheckSw2Exist)
	fi
fi

Sw3Exist=sw
ifconfig sw3 >/dev/null 2>&1
if [ $? -eq 0 ]
then
	if   [ $LinuxFlavor = 'Red' ] || [ $LinuxFlavor = 'Oracle' ]
	then
		if   [ $Release -eq 7 ] || [ $Release -eq 8 ]
		then
			function CheckSw3Exist {
				ifconfig sw3 | cut -f1 -d':' | head -1
			}
	
		elif [ $Release -eq 6 ]
		then
			function CheckSw3Exist {
				ifconfig sw3 | cut -f1 -d':' | head -1 | cut -f1 -d' '
			}
		fi
		Sw3Exist=$(CheckSw3Exist)

	elif [ $LinuxFlavor = 'Ubuntu' ] || [ $LinuxFlavor = 'Pop_OS' ]
	then
		function CheckSw3Exist {
			ifconfig sw3 | cut -f1 -d':' | head -1 | cut -f1 -d' '
		}
		Sw3Exist=$(CheckSw3Exist)

	elif [ $LinuxFlavor = 'Debian' ]
	then
		function CheckSw3Exist {
		ifconfig sw3 | cut -f1 -d':' | head -1 | cut -f1 -d' '
		}
		Sw3Exist=$(CheckSw3Exist)
	fi
fi

$SUDO_PREFIX sh -c "echo '#!/bin/bash'															 	 	 	 		> /etc/network/openvswitch/stop_scst.sh"

$SUDO_PREFIX scstadmin -add_tgt_attr iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -driver iscsi -attribute allowed_portal=127.0.0.1

if   [ $LinuxFlavor = 'Red' ] || [ $LinuxFlavor = 'Oracle' ]
then
	$SUDO_PREFIX sh -c "echo '$IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal 127.0.0.1:3260 --logout'				>> /etc/network/openvswitch/stop_scst.sh"

elif [ $LinuxFlavor = 'Ubuntu' ] || [ $LinuxFlavor = 'Pop_OS' ]
then
	if [ $UbuntuMajorRelease -gt 14 ]
	then
		$SUDO_PREFIX sh -c "echo '$OPath $IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal 127.0.0.1:3260  --logout'		>> /etc/network/openvswitch/stop_scst.sh"
	else
		$SUDO_PREFIX update-rc.d -f scst remove
		echo ''
		$SUDO_PREFIX update-rc.d scst defaults
		echo ''
		$SUDO_PREFIX sh -c "echo '!#/bin/bash'                                                                                                                  		 	> /etc/network/openvswitch/login-scst.sh"
		$SUDO_PREFIX sh -c "echo '$IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal 127.0.0.1:3260  --login'			>> /etc/network/openvswitch/login-scst.sh"
		$SUDO_PREFIX chmod 775 /etc/network/openvswitch/login-scst.sh
		$SUDO_PREFIX sh -c "echo 'description   \"login scst\"'															 	> /etc/init/login-scst.conf"
		$SUDO_PREFIX sh -c "echo 'start on started rc'																	>> /etc/init/login-scst.conf"
		$SUDO_PREFIX sh -c "echo 'task'																			>> /etc/init/login-scst.conf"
		$SUDO_PREFIX sh -c "echo 'exec /etc/network/openvswitch/login-scst.sh'														>> /etc/init/login-scst.conf"
	fi

elif [ $LinuxFlavor = 'Debian' ]
then
	if [ $UbuntuMajorRelease -gt 14 ]
	then
		$SUDO_PREFIX sh -c "echo '$IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal 127.0.0.1:3260  --logout'			>> /etc/network/openvswitch/stop_scst.sh"
	else
		$SUDO_PREFIX update-rc.d -f scst remove
		echo ''
		$SUDO_PREFIX update-rc.d scst defaults
		echo ''
		$SUDO_PREFIX sh -c "echo '!#/bin/bash'                                                                                                                         	 		> /etc/network/openvswitch/login-scst.sh"
		$SUDO_PREFIX sh -c "echo '$IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal 127.0.0.1:3260  --login'			>> /etc/network/openvswitch/login-scst.sh"
		$SUDO_PREFIX chmod 775 /etc/network/openvswitch/login-scst.sh
		$SUDO_PREFIX sh -c "echo 'description   \"login scst\"'													 	 		> /etc/init/login-scst.conf"
		$SUDO_PREFIX sh -c "echo 'start on started rc'																	>> /etc/init/login-scst.conf"
		$SUDO_PREFIX sh -c "echo 'task'																			>> /etc/init/login-scst.conf"
		$SUDO_PREFIX sh -c "echo 'exec /etc/network/openvswitch/login-scst.sh'														>> /etc/init/login-scst.conf"
	fi
fi

function GetInterfaces {
	ifconfig | egrep 'ens|enp|wlp|wlan|eth|bnep' | egrep -v 'ether|veth' | cut -f1 -d' ' | cut -f1 -d':' | sed 's/$/ /' | tr -d '\n' |  sed 's/^[ \t]*//;s/[ \t]*$//'
}
Interfaces=$(GetInterfaces)
echo $Interfaces

for i in $Interfaces
do
       	function GetExternalIpAddress {
               	ifconfig $i | grep inet | grep -v inet6 | sed 's/^[ \t]*//;s/[ \t]*$//' | cut -f2 -d' '
       	}
       	ExternalIpAddress=$(GetExternalIpAddress)

	$SUDO_PREFIX scstadmin -add_tgt_attr iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -driver iscsi -attribute allowed_portal=$ExternalIpAddress
done

if   [ $Sw1Exist = 'sw1' ]
then
	function GetSw1IpAddress {
		ifconfig sw1 | grep inet | grep -v inet6 |  sed 's/^[ \t]*//' | cut -f2 -d' ' | cut -f2 -d':'
	}
	Sw1IpAddress=$(GetSw1IpAddress)

	function GetSw1Index {
		echo $Sw1IpAddress | cut -f4 -d'.'
	}
	Sw1Index=$(GetSw1Index)

	if   [ $LinuxFlavor = 'Red' ] || [ $LinuxFlavor = 'Oracle' ]
	then
		$SUDO_PREFIX sh -c "echo '$IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal $Sw1IpAddress:3260 --logout'			>> /etc/network/openvswitch/stop_scst.sh"
		$SUDO_PREFIX sh -c "echo '$IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal $ExternalIpAddress:3260 --logout'		>> /etc/network/openvswitch/stop_scst.sh"
		$SUDO_PREFIX scstadmin -add_tgt_attr iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -driver iscsi -attribute allowed_portal=$Sw1IpAddress

	elif [ $LinuxFlavor = 'Ubuntu' ] || [ $LinuxFlavor = 'Debian' ] || [ $LinuxFlavor = 'Pop_OS' ]
	then
		$SUDO_PREFIX sh -c "echo '$OPath $IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal $Sw1IpAddress:3260 --logout' 		>> /etc/network/openvswitch/stop_scst.sh"
		$SUDO_PREFIX sh -c "echo '$OPath $IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal $ExternalIpAddress:3260 --logout'	>> /etc/network/openvswitch/stop_scst.sh"
		$SUDO_PREFIX scstadmin -add_tgt_attr iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -driver iscsi -attribute allowed_portal=$Sw1IpAddress
	fi
fi

if   [ $Sw2Exist = 'sw2' ]
then
	function GetSw2IpAddress {
		ifconfig sw2 | grep inet | grep -v inet6 |  sed 's/^[ \t]*//' | cut -f2 -d' ' | cut -f2 -d':'
	}
	Sw2IpAddress=$(GetSw2IpAddress)

	function GetSw2Index {
		echo $Sw2IpAddress | cut -f4 -d'.'
	}
	Sw2Index=$(GetSw2Index)

	if   [ $LinuxFlavor = 'Red' ] || [ $LinuxFlavor = 'Oracle' ]
	then
	#	$SUDO_PREFIX sh -c "echo '$IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal $Sw2IpAddress:3260 --logout'			>> /etc/network/openvswitch/stop_scst.sh"
		$SUDO_PREFIX scstadmin -add_tgt_attr iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -driver iscsi -attribute allowed_portal=$Sw2IpAddress

	elif [ $LinuxFlavor = 'Ubuntu' ] || [ $LinuxFlavor = 'Debian' ] || [ $LinuxFlavor = 'Pop_OS' ]
	then
	#	$SUDO_PREFIX sh -c "echo '$OPath $IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal $Sw2IpAddress:3260 --logout' 		>> /etc/network/openvswitch/stop_scst.sh"
		$SUDO_PREFIX scstadmin -add_tgt_attr iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -driver iscsi -attribute allowed_portal=$Sw2IpAddress
	fi
fi

if   [ $Sw3Exist = 'sw3' ]
then
	function GetSw3IpAddress {
		ifconfig sw3 | grep inet | grep -v inet6 |  sed 's/^[ \t]*//' | cut -f2 -d' ' | cut -f2 -d':'
	}
	Sw3IpAddress=$(GetSw3IpAddress)

	function GetSw3Index {
		echo $Sw3IpAddress | cut -f4 -d'.'
	}
	Sw3Index=$(GetSw3Index)

	if   [ $LinuxFlavor = 'Red' ] || [ $LinuxFlavor = 'Oracle' ]
	then
	#	$SUDO_PREFIX sh -c "echo '$IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal $Sw3IpAddress:3260 --logout' 		>> /etc/network/openvswitch/stop_scst.sh"
		$SUDO_PREFIX scstadmin -add_tgt_attr iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -driver iscsi -attribute allowed_portal=$Sw3IpAddress

	elif [ $LinuxFlavor = 'Ubuntu' ] || [ $LinuxFlavor = 'Debian' ] || [ $LinuxFlavor = 'Pop_OS' ]
	then
	#	$SUDO_PREFIX sh -c "echo '$OPath $IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal $Sw3IpAddress:3260 --logout'		>> /etc/network/openvswitch/stop_scst.sh"
		$SUDO_PREFIX scstadmin -add_tgt_attr iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -driver iscsi -attribute allowed_portal=$Sw3IpAddress
	fi
fi

if   [ $LinuxFlavor = 'Red' ] || [ $LinuxFlavor = 'Oracle' ]
then
	$SUDO_PREFIX sh -c "echo '$RPath -f /dev/"$StoragePrefix"_luns/*'															>> /etc/network/openvswitch/stop_scst.sh"
	$SUDO_PREFIX sh -c "echo '$MPath -F'																			>> /etc/network/openvswitch/stop_scst.sh"

elif [ $LinuxFlavor = 'Ubuntu' ] || [ $LinuxFlavor = 'Debian' ] || [ $LinuxFlavor = 'Pop_OS' ]
then
	$SUDO_PREFIX sh -c "echo '$OPath $SPath multipath-tools stop'																>> /etc/network/openvswitch/stop_scst.sh"
	$SUDO_PREFIX sh -c "echo '$OPath $MPath -F'																		>> /etc/network/openvswitch/stop_scst.sh"
	$SUDO_PREFIX sh -c "echo '$OPath $RPath -rf /dev/"$StoragePrefix"_luns/*'														>> /etc/network/openvswitch/stop_scst.sh"
fi

$SUDO_PREFIX sh -c "echo '#!/bin/bash'																				 > /etc/network/openvswitch/strt_scst.sh"
$SUDO_PREFIX sh -c "echo '$DPath /dev/"$StoragePrefix"_luns'																	>> /etc/network/openvswitch/strt_scst.sh"
$SUDO_PREFIX sh -c "echo '$UPath control --reload-rules && $UPath trigger'															>> /etc/network/openvswitch/strt_scst.sh"

if   [ $LinuxFlavor = 'Red' ] || [ $LinuxFlavor = 'Oracle' ]
then																
	$SUDO_PREFIX sh -c "echo '$SPath multipathd restart'																	>> /etc/network/openvswitch/strt_scst.sh"
	$SUDO_PREFIX sh -c "echo '$IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal 127.0.0.1:3260   --login'				>> /etc/network/openvswitch/strt_scst.sh"

#	if [ $LXDStorageDriver != 'zfs' ]
#	then
#		function WhichModprobe {
#			which modprobe
#		}
#		ModProbe=$(WhichModprobe)
#	
#		function WhichSudo {
#			which sudo
#		}
#		Sudo=$(WhichSudo)
#	
#		function WhichZpool {
#			which zpool
#		}
#		Zpool=$(WhichZpool)
#	
#		$SUDO_PREFIX sh -c "echo '$ModProbe zfs'																	>> /etc/network/openvswitch/strt_scst.sh"
#		$SUDO_PREFIX sh -c "echo '$Zpool import olxc-001'																>> /etc/network/openvswitch/strt_scst.sh"
#	fi

elif [ $LinuxFlavor = 'Ubuntu' ] || [ $LinuxFlavor = 'Debian' ] || [ $LinuxFlavor = 'Pop_OS' ]
then
	$SUDO_PREFIX sh -c "echo '$OPath $SPath multipath-tools restart'															>> /etc/network/openvswitch/strt_scst.sh"
	$SUDO_PREFIX sh -c "echo '$OPath $IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal 127.0.0.1:3260   --login'			>> /etc/network/openvswitch/strt_scst.sh"
fi

for i in $Interfaces
do
       	function GetExternalIpAddress {
               	ifconfig $i | grep inet | grep -v inet6 | sed 's/^[ \t]*//;s/[ \t]*$//' | cut -f2 -d' '
       	}
       	ExternalIpAddress=$(GetExternalIpAddress)
 
	$SUDO_PREFIX sh -c "echo '$IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal $ExternalIpAddress:3260 --login'			>> /etc/network/openvswitch/strt_scst.sh"
done

if   [ $Sw1Exist = 'sw1' ]
then
	function GetSw1IpAddress {
		ifconfig sw1 | grep inet | grep -v inet6 |  sed 's/^[ \t]*//' | cut -f2 -d' ' | cut -f2 -d':'
	}
	Sw1IpAddress=$(GetSw1IpAddress)
	if   [ $LinuxFlavor = 'Red' ] || [ $LinuxFlavor = 'Oracle' ]
	then
		$SUDO_PREFIX sh -c "echo '$IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal $Sw1IpAddress:3260 --login'			>> /etc/network/openvswitch/strt_scst.sh"
	elif [ $LinuxFlavor = 'Ubuntu' ] || [ $LinuxFlavor = 'Debian' ] || [ $LinuxFlavor = 'Pop_OS' ]
	then
		$SUDO_PREFIX sh -c "echo '$OPath $IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal $Sw1IpAddress:3260 --login'		>> /etc/network/openvswitch/strt_scst.sh"
	fi
fi

if   [ $Sw2Exist = 'sw2' ]
then
	function GetSw2IpAddress {
		ifconfig sw2 | grep inet | grep -v inet6 |  sed 's/^[ \t]*//' | cut -f2 -d' ' | cut -f2 -d':'
	}
	Sw2IpAddress=$(GetSw2IpAddress)
	if   [ $LinuxFlavor = 'Red' ] || [ $LinuxFlavor = 'Oracle' ]
	then
		$SUDO_PREFIX sh -c "# echo '$IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal $Sw2IpAddress:3260 --login'		>> /etc/network/openvswitch/strt_scst.sh"

	elif [ $LinuxFlavor = 'Ubuntu' ] || [ $LinuxFlavor = 'Debian' ] || [ $LinuxFlavor = 'Pop_OS' ]
	then
		$SUDO_PREFIX sh -c "# echo '$OPath $IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal $Sw2IpAddress:3260 --login'		>> /etc/network/openvswitch/strt_scst.sh"
	fi
fi

if   [ $Sw3Exist = 'sw3' ]
then
	function GetSw3IpAddress {
		ifconfig sw3 | grep inet | grep -v inet6 |  sed 's/^[ \t]*//' | cut -f2 -d' ' | cut -f2 -d':'
	}
	Sw3IpAddress=$(GetSw3IpAddress)
	if   [ $LinuxFlavor = 'Red' ] || [ $LinuxFlavor = 'Oracle' ]
	then
		$SUDO_PREFIX sh -c "# echo '$IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal $Sw3IpAddress:3260 --login'		>> /etc/network/openvswitch/strt_scst.sh"

	elif [ $LinuxFlavor = 'Ubuntu' ] || [ $LinuxFlavor = 'Debian' ] || [ $LinuxFlavor = 'Pop_OS' ]
	then
		$SUDO_PREFIX sh -c "# echo '$OPath $IPath -m node --targetname "iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product" --portal $Sw3IpAddress:3260 --login'		>> /etc/network/openvswitch/strt_scst.sh"
	fi
fi

$SUDO_PREFIX chmod +x /etc/network/openvswitch/st*_scst.sh

$SUDO_PREFIX ls -l /etc/network/openvswitch/st*_scst.sh

if [ $UbuntuMajorRelease -gt 14 ] || [ $LinuxFlavor = 'Ubuntu' ]
then
	echo ''
	echo "======================================================="
	echo "Created files needed for the (olxc-scst) service.      "
	echo "======================================================="
	echo ''
else
	echo ''
	echo "======================================================="
	echo "Created Upstart Job and Autostart for SCST.            "
	echo "======================================================="
	echo ''
fi

if [ $UbuntuMajorRelease -ge 9 ] || [ $LinuxFlavor = 'Debian' ]
then
	echo ''
	echo "======================================================="
	echo "Created files needed for the (olxc-scst) service.      "
	echo "======================================================="
	echo ''
else
	echo ''
	echo "======================================================="
	echo "Created Upstart Job and Autostart for SCST.            "
	echo "======================================================="
	echo ''
fi

sleep 5

clear

echo ''
echo "======================================================"
echo "Discover portals and targets...                       "
echo "======================================================"
echo ''

$SUDO_PREFIX iscsiadm -m discovery -t sendtargets --portal 127.0.0.1
$SUDO_PREFIX iscsiadm -m node --login

echo ''
echo "======================================================"
echo "Portals and targets discovered.                       "
echo "======================================================"

sleep 5

clear

echo ''
echo "======================================================"
echo "Set Portal startups.                                  "
echo "You can change 'manual' to 'automatic' later.         "
echo "======================================================"
echo ''

sleep 7

$SUDO_PREFIX iscsiadm --mode node -T iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product -o update -n node.startup -v manual

echo ''
echo "======================================================"
echo "Set the startups of all portals to manual.            "
echo "======================================================"

sleep 5

clear

if [ $LinuxFlavor = 'Red' ] || [ $LinuxFlavor = 'Oracle' ]
then
	if   [ $Release -ge 7 ]
	then
		echo ''
		echo "======================================================"
		echo "Create a service (olxc-scst) to manage SCST storage   "
		echo "======================================================"
		echo ''

		$SUDO_PREFIX sh -c "echo '[Unit]'             	         					 > /etc/systemd/system/olxc-scst.service"
		$SUDO_PREFIX sh -c "echo 'Description=olxc-scst Service'  					>> /etc/systemd/system/olxc-scst.service"
		$SUDO_PREFIX sh -c "echo 'Wants=network-online.target sw2.service sw3.service scst.service'	>> /etc/systemd/system/olxc-scst.service"
		$SUDO_PREFIX sh -c "echo 'After=network-online.target sw2.service sw3.service scst.service'	>> /etc/systemd/system/olxc-scst.service"
		$SUDO_PREFIX sh -c "echo 'Before=shutdown.target reboot.target halt.target'			>> /etc/systemd/system/olxc-scst.service"
		$SUDO_PREFIX sh -c "echo ''                                 					>> /etc/systemd/system/olxc-scst.service"
		$SUDO_PREFIX sh -c "echo '[Service]'                        					>> /etc/systemd/system/olxc-scst.service"
		$SUDO_PREFIX sh -c "echo 'Type=oneshot'                     					>> /etc/systemd/system/olxc-scst.service"
		$SUDO_PREFIX sh -c "echo 'User=root'                        					>> /etc/systemd/system/olxc-scst.service"
		$SUDO_PREFIX sh -c "echo 'RemainAfterExit=yes'              					>> /etc/systemd/system/olxc-scst.service"
		$SUDO_PREFIX sh -c "echo 'ExecStart=/etc/network/openvswitch/strt_scst.sh'			>> /etc/systemd/system/olxc-scst.service"
		$SUDO_PREFIX sh -c "echo 'ExecStop=/etc/network/openvswitch/stop_scst.sh'			>> /etc/systemd/system/olxc-scst.service"
		$SUDO_PREFIX sh -c "echo ''                                 					>> /etc/systemd/system/olxc-scst.service"
		$SUDO_PREFIX sh -c "echo '[Install]'                        					>> /etc/systemd/system/olxc-scst.service"
		$SUDO_PREFIX sh -c "echo 'WantedBy=multi-user.target'       					>> /etc/systemd/system/olxc-scst.service"

		$SUDO_PREFIX chmod 644 /etc/systemd/system/olxc-scst.service

		$SUDO_PREFIX systemctl enable olxc-scst.service
		echo ''
		$SUDO_PREFIX cat /etc/systemd/system/olxc-scst.service

		echo ''
		echo "======================================================"
		echo "Service (olxc-scst) created.                          "
		echo "======================================================"

		sleep 5

		clear
	elif [ $Release -eq 6 ]
	then
		$SUDO_PREFIX cp -p /opt/olxc/home/scst-files/create-scst-linux6.sh /etc/init.d/olxc-scst
		$SUDO_PREFIX chkconfig olxc-scst on
	fi
fi

if [ $UbuntuMajorRelease -ge 9 ] && [ $LinuxFlavor = 'Debian' ]
then
	echo ''
	echo "======================================================"
	echo "Create a service (olxc-scst) to manage SCST storage   "
	echo "======================================================"
	echo ''

	$SUDO_PREFIX sh -c "echo '[Unit]'             	         					 > /etc/systemd/system/olxc-scst.service"
	$SUDO_PREFIX sh -c "echo 'Description=olxc-scst Service'  					>> /etc/systemd/system/olxc-scst.service"
	$SUDO_PREFIX sh -c "echo 'Wants=network-online.target sw2.service sw3.service scst.service'	>> /etc/systemd/system/olxc-scst.service"
	$SUDO_PREFIX sh -c "echo 'After=network-online.target sw2.service sw3.service scst.service'	>> /etc/systemd/system/olxc-scst.service"
	$SUDO_PREFIX sh -c "echo 'Before=shutdown.target reboot.target halt.target'			>> /etc/systemd/system/olxc-scst.service"
	$SUDO_PREFIX sh -c "echo ''                                 					>> /etc/systemd/system/olxc-scst.service"
	$SUDO_PREFIX sh -c "echo '[Service]'                        					>> /etc/systemd/system/olxc-scst.service"
	$SUDO_PREFIX sh -c "echo 'Type=oneshot'                     					>> /etc/systemd/system/olxc-scst.service"
	$SUDO_PREFIX sh -c "echo 'User=root'                        					>> /etc/systemd/system/olxc-scst.service"
	$SUDO_PREFIX sh -c "echo 'RemainAfterExit=yes'              					>> /etc/systemd/system/olxc-scst.service"
	$SUDO_PREFIX sh -c "echo 'ExecStart=/etc/network/openvswitch/strt_scst.sh'			>> /etc/systemd/system/olxc-scst.service"
	$SUDO_PREFIX sh -c "echo 'ExecStop=/etc/network/openvswitch/stop_scst.sh'			>> /etc/systemd/system/olxc-scst.service"
	$SUDO_PREFIX sh -c "echo ''                                 					>> /etc/systemd/system/olxc-scst.service"
	$SUDO_PREFIX sh -c "echo '[Install]'                        					>> /etc/systemd/system/olxc-scst.service"
	$SUDO_PREFIX sh -c "echo 'WantedBy=multi-user.target'       					>> /etc/systemd/system/olxc-scst.service"

	$SUDO_PREFIX chmod 644 /etc/systemd/system/olxc-scst.service

	$SUDO_PREFIX systemctl enable olxc-scst.service
	echo ''
	$SUDO_PREFIX cat /etc/systemd/system/olxc-scst.service

	echo ''
	echo "======================================================"
	echo "Service (olxc-scst) created.                          "
	echo "======================================================"

	sleep 5

	clear
fi

# sleep 5

# echo ''
# echo "======================================================"
# echo "Create the /etc/network/if-down.d/scst-net file..     "
# echo "======================================================"
# echo ''

# $SUDO_PREFIX sh -c "echo '#!/bin/sh'  																>  /etc/network/if-down.d/scst-net"
# $SUDO_PREFIX sh -c "echo '# This file is only used with orabuntu not with uekulele but is included in the distribution.'						>> /etc/network/if-down.d/scst-net"
# $SUDO_PREFIX sh -c "echo 'scst-net - logout of scst targets'  										 			>> /etc/network/if-down.d/scst-net"
# $SUDO_PREFIX sh -c "echo 'iscsiadm --mode node --targetname iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product --portal 127.0.0.1   --logout'		>> /etc/network/if-down.d/scst-net"

# if [ $Sw2Exist = 'sw2' ]
# then
# 	$SUDO_PREFIX sh -c "echo 'iscsiadm --mode node --targetname iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product --portal 10.210.107.1 --logout'	>> /etc/network/if-down.d/scst-net"
# fi

# if [ $Sw3Exist = 'sw3' ]
# then
# 	$SUDO_PREFIX sh -c "echo 'iscsiadm --mode node --targetname iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.$StoragePrefix.$product --portal 10.211.107.1 --logout'	>> /etc/network/if-down.d/scst-net"
# fi

# $SUDO_PREFIX cat /etc/network/if-down.d/scst-net

# echo ''
# echo "======================================================"
# echo "File created.                                         "
# echo "======================================================"

# sleep 5

# clear

echo ''
echo "======================================================"
echo "Verify that SCST SAN for Oracle is configured.        "
echo "======================================================"
echo ''

sleep 5

$SUDO_PREFIX scstadmin -write_conf /etc/scst.conf
$SUDO_PREFIX scstadmin -list_group

echo ''
echo "======================================================"
echo "SCST SAN for Oracle is configured.                    "
echo "======================================================"

sleep 10

