#!/bin/bash

#    Copyright 2015-2016 Gilbert Standen
#    This file is part of orabuntu-lxc.

#    Orabuntu-lxc is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-lxc is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with orabuntu-lxc.  If not, see <http://www.gnu.org/licenses/>.

#    v2.8 GLS 20151231
#    v3.0 GLS 20160717

export IQN_YR=`date +"%Y"`
export IQN_MO=`date +"%m"`
export IQN=iqn.$IQN_YR-$IQN_MO.com.orabuntu-lxc:storage.tgt.lxc.oracle.asm

clear

echo ''
echo "=============================================="
echo "Establish sudo privileges ...                 "
echo "=============================================="
echo ''

sudo date

echo ''
echo "=============================================="
echo "Establish sudo privileges successful.         "
echo "=============================================="
echo ''

sleep 5

clear

# Determine User-Selected redundancy or set to default (external)

AsmRedundancy=$1

function SetCaseAsmRedundancy {
echo $AsmRedundancy | sed -e 's/\([A-Z][A-Za-z0-9]*\)/\L\1/g'
}
AsmRedundancy=$(SetCaseAsmRedundancy)

if [ -z "$1" ]
then
  AsmRedundancy=external
fi

if   [ "$AsmRedundancy" = 'external' ]
then
  echo $AsmRedundancy
elif [ "$AsmRedundancy" = 'normal' ]
then
  echo $AsmRedundancy
elif [ "$AsmRedundancy" = 'high' ]
then
  echo $AsmRedundancy
else
  echo "AsmRedundancy must be in the set {external, normal, high}"
  echo "Current setting of AsmRedundancy is $AsmRedundancy"
  echo "Rerun program with correct spelling of external, normal, or high"
fi

# Create Target and Groups

  sudo tgtadm --lld iscsi --op new --mode target --tid 1 -T $IQN

  echo ''
  echo "======================================================"
  echo "Verify that target, groups, and initiators are added  "
  echo "======================================================"
  echo ''

# sudo scstadmin -list_group
  sudo tgtadm --lld iscsi --op show --mode target

  echo ''
  echo "======================================================"
  echo "Target verification step completed.                   "
  echo "======================================================"
  echo ''

  sleep 5

  clear

# Create file-backed devices for LUNS for Oracle ASM diskgroup SYSTEMDG

if [ "$AsmRedundancy" = 'external' ]
then

  if [ ! -e /asm0 ]
  then
  sudo mkdir /asm0
  fi

  sudo fallocate -l 10G /asm0/asm_systemdg_00_tgt.img

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for systemdg "
  echo "Sleeping for 5 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_systemdg*

  sleep 5

# Create file-backed devices for LUNS for Oracle ASM diskgroups DATA and FRA

  sudo fallocate -l 40G /asm0/asm_data1_00_tgt.img
  sudo fallocate -l 40G /asm0/asm_fra1_00_tgt.img

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for data     "
  echo "Sleeping for 5 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_data*

  sleep 5

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for fra      "
  echo "Sleeping for 5 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_fra*

  echo ''
  echo "======================================================"
  echo "Backing file creations completed.                     "
  echo "======================================================"
  echo ''

  sleep 5
  
  clear

  echo ''
  echo "======================================================"
  echo "TGT SAN is being created (LUNs being added to target) "
  echo "Patience...takes a minute or two...                   "
  echo "======================================================"
  echo ''

# Open file-backed devices for Oracle ASM diskgroup SYSTEMDG

  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 1  -b /asm0/asm_systemdg_00_tgt.img
  sleep 2

# Open file-backed devices for Oracle ASM diskgroups DATA and FRA

  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 2  -b /asm0/asm_data1_00_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 3  -b /asm0/asm_fra1_00_tgt.img
  sleep 2

# Show completed TGT Target

  sudo tgtadm --lld iscsi --op show --mode target

fi

if [ "$AsmRedundancy" = 'normal' ]
then

  if [ ! -e /asm0 ]
  then
  sudo mkdir /asm0
  fi

  if [ ! -e /asm1 ]
  then
  sudo mkdir /asm1
  fi

  if [ ! -e /asm2 ]
  then
  sudo mkdir /asm2
  fi

  sudo fallocate -l 10G /asm0/asm_systemdg_00_tgt.img
  sudo fallocate -l 10G /asm1/asm_systemdg_01_tgt.img
  sudo fallocate -l 10G /asm2/asm_systemdg_02_tgt.img

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for systemdg "
  echo "Sleeping for 5 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_systemdg*
  ls -lrt /asm1/asm_systemdg*
  ls -lrt /asm2/asm_systemdg*

  sleep 5

# Create file-backed devices for LUNS for Oracle ASM diskgroups DATA and FRA

  sudo fallocate -l 40G /asm0/asm_data1_00_tgt.img
  sudo fallocate -l 40G /asm1/asm_data1_01_tgt.img
  sudo fallocate -l 40G /asm2/asm_data1_02_tgt.img

  sudo fallocate -l 40G /asm0/asm_fra1_00_tgt.img
  sudo fallocate -l 40G /asm1/asm_fra1_01_tgt.img
  sudo fallocate -l 40G /asm2/asm_fra1_02_tgt.img

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for data     "
  echo "Sleeping for 5 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_data*
  ls -lrt /asm1/asm_data*
  ls -lrt /asm2/asm_data*

  sleep 5

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for fra      "
  echo "Sleeping for 5 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_fra*
  ls -lrt /asm1/asm_fra*
  ls -lrt /asm2/asm_fra*

  echo ''
  echo "======================================================"
  echo "Backing file creations completed.                     "
  echo "======================================================"
  echo ''

  sleep 5

  clear

  echo ''
  echo "======================================================"
  echo "TGT SAN is being created (LUNs being added to target) "
  echo "Patience...takes a minute or two...                   "
  echo "======================================================"
  echo ''

# Open file-backed devices for Oracle ASM diskgroup SYSTEMDG

  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 1 -b /asm0/asm_systemdg_00_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 2 -b /asm1/asm_systemdg_01_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 3 -b /asm2/asm_systemdg_02_tgt.img

# Open file-backed devices for Oracle ASM diskgroups DATA and FRA

  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 4 -b /asm0/asm_data1_00_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 5 -b /asm1/asm_data1_01_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 6 -b /asm2/asm_data1_02_tgt.img

  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 7 -b /asm0/asm_fra1_00_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 8 -b /asm1/asm_fra1_01_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 9 -b /asm2/asm_fra1_02_tgt.img

# Show completed TGT Target

  sudo tgtadm --lld iscsi --op show --mode target

fi

if [ "$AsmRedundancy" = 'high' ]
then

  if [ ! -e /asm0 ]
  then
  sudo mkdir /asm0
  fi

  if [ ! -e /asm1 ]
  then
  sudo mkdir /asm1
  fi

  if [ ! -e /asm2 ]
  then
  sudo mkdir /asm2
  fi

  if [ ! -e /asm3 ]
  then
  sudo mkdir /asm3
  fi

  if [ ! -e /asm4 ]
  then
  sudo mkdir /asm4
  fi

  sudo fallocate -l 10G /asm0/asm_systemdg_00_tgt.img
  sudo fallocate -l 10G /asm1/asm_systemdg_01_tgt.img
  sudo fallocate -l 10G /asm2/asm_systemdg_02_tgt.img
  sudo fallocate -l 10G /asm3/asm_systemdg_03_tgt.img
  sudo fallocate -l 10G /asm4/asm_systemdg_04_tgt.img

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for systemdg "
  echo "Sleeping for 5 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_systemdg*
  ls -lrt /asm1/asm_systemdg*
  ls -lrt /asm2/asm_systemdg*
  ls -lrt /asm3/asm_systemdg*
  ls -lrt /asm4/asm_systemdg*

  sleep 5

# Create file-backed devices for LUNS for Oracle ASM diskgroups DATA and FRA

  sudo fallocate -l 40G /asm0/asm_data1_00_tgt.img
  sudo fallocate -l 40G /asm1/asm_data1_01_tgt.img
  sudo fallocate -l 40G /asm2/asm_data1_02_tgt.img
  sudo fallocate -l 40G /asm3/asm_data1_03_tgt.img
  sudo fallocate -l 40G /asm4/asm_data1_04_tgt.img

  sudo fallocate -l 40G /asm0/asm_fra1_00_tgt.img
  sudo fallocate -l 40G /asm1/asm_fra1_01_tgt.img
  sudo fallocate -l 40G /asm2/asm_fra1_02_tgt.img
  sudo fallocate -l 40G /asm3/asm_fra1_03_tgt.img
  sudo fallocate -l 40G /asm4/asm_fra1_04_tgt.img

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for data     "
  echo "Sleeping for 5 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_data*
  ls -lrt /asm1/asm_data*
  ls -lrt /asm2/asm_data*
  ls -lrt /asm3/asm_data*
  ls -lrt /asm4/asm_data*

  sleep 5

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for fra      "
  echo "Sleeping for 5 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_fra*
  ls -lrt /asm1/asm_fra*
  ls -lrt /asm2/asm_fra*
  ls -lrt /asm3/asm_fra*
  ls -lrt /asm4/asm_fra*

  echo ''
  echo "======================================================"
  echo "Backing file creations completed.                     "
  echo "======================================================"
  echo ''

  sleep 5

  clear

  echo ''
  echo "======================================================"
  echo "TGT SAN is being created (LUNs being added to target) "
  echo "Patience...takes a minute or two...                   "
  echo "======================================================"
  echo ''

# Open file-backed devices for Oracle ASM diskgroup SYSTEMDG

  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 1  -b /asm0/asm_systemdg_00_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 2  -b /asm1/asm_systemdg_01_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 3  -b /asm2/asm_systemdg_02_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 4  -b /asm3/asm_systemdg_03_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 5  -b /asm4/asm_systemdg_04_tgt.img
  sleep 2

# Open file-backed devices for Oracle ASM diskgroups DATA and FRA

  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 6  -b /asm0/asm_data1_00_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 7  -b /asm1/asm_data1_01_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 8  -b /asm2/asm_data1_02_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 9  -b /asm3/asm_data1_03_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 10 -b /asm4/asm_data1_04_tgt.img
  sleep 2

  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 11 -b /asm0/asm_fra1_00_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 12 -b /asm1/asm_fra1_01_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 13 -b /asm2/asm_fra1_02_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 14 -b /asm3/asm_fra1_03_tgt.img
  sleep 2
  sudo tgtadm --lld iscsi --op new --mode logicalunit --tid 1 --lun 15 -b /asm4/asm_fra1_04_tgt.img
  sleep 2

# Show completed TGT Target

  sudo tgtadm --lld iscsi --op show --mode target

fi

  sudo tgtadm --lld iscsi --op bind --mode target --tid 1 -I ALL

  echo "======================================================="
  echo "SCST SAN is configued and created.                     "
  echo "======================================================="
  echo ''

  sleep 5

  clear

  echo "======================================================="
  echo "Run script create-tgt-2.sh next to login to the SAN.   "
  echo "======================================================="
  echo ''

# sudo netstat -tulpn | grep 3260
