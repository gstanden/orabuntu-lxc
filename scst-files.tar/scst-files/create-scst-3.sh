#!/bin/bash

cd ~/scst
sleep 5

sudo make scst scst_install iscsi iscsi_install scstadm scstadm_install
sleep 5

sudo modprobe scst
sudo modprobe scst_vdisk
sudo modprobe scst_disk
sudo modprobe scst_user
sudo modprobe scst_modisk
sudo modprobe scst_processor
sudo modprobe scst_raid
sudo modprobe scst_tape
sudo modprobe scst_cdrom
sudo modprobe scst_changer
sudo modprobe iscsi-scst
sudo iscsi-scstd
# sudo service scst start
# sudo systemctl enable scst.service

