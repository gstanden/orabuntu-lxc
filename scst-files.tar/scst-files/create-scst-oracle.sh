#    Copyright 2015-2016 Gilbert Standen
#    This file is part of orabuntu-lxc.

#    Orabuntu-lxc is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-lxc is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with orabuntu-lxc.  If not, see <http://www.gnu.org/licenses/>.

#    v2.8 GLS 20151231
#    v3.0 GLS 20160710
#    v3.1 GLS 20160924

#    User:     Run this program as root if on RedHat/CentOS/Oracle Linux or similar; Run this program as the install admin user (sudo not-root) if on Ubuntu or similar.
#    Usage:    create-scst-oracle.sh com.yourdomain ScstGroupName AsmRedundancy Sysd1SizeGb Data1SizeGb Reco1SizeGb LogicalBlkSiz 
#    Example:  create-scst-oracle.sh com.robinsystems lxc1 external 10G 40G 40G 4096
#    Note1:    If you do not pass in a "com.yourdomain" parameter it will be set to default value of com.orabuntu-lxc
#    Note2:    If you do not pass in a "ScstGroupName"  parameter it will be set to default value of lxc1
#    Note3:    If you do not pass in a "AsmRedundancy"  parameter it will be set to default value of external
#    Note4:    If you do not pass in a "Sysd1SizeGb"  parameter it will be set to default value of 1Gb
#    Note5:    If you do not pass in a "Data1SizeGb"  parameter it will be set to default value of 1Gb 
#    Note6:    If you do not pass in a "Reco1SizeGb"  parameter it will be set to default value of 1Gb 
#    Note7:    If you do not pass in a "LogicalBlkSiz"  parameter it will be set to default value of null

#!/bin/bash

# Determine if sudo prefix is needed on commands


GetLinuxFlavor(){
        if [[ -e /etc/redhat-release ]]
        then
                LinuxFlavor=$(cat /etc/redhat-release | cut -f1 -d' ')
        elif [[ -e /usr/bin/lsb_release ]]
        then
                LinuxFlavor=$(lsb_release -d | awk -F ':' '{print $2}' | cut -f1 -d' ')
        elif [[ -e /etc/issue ]]
        then
                LinuxFlavor=$(cat /etc/issue | cut -f1 -d' ')
        else
                LinuxFlavor=$(cat /proc/version | cut -f1 -d' ')
        fi
}

GetLinuxFlavor

function TrimLinuxFlavor {
echo $LinuxFlavor | sed 's/^[ \t]//;s/[ \t]$//'
}
LinuxFlavor=$(TrimLinuxFlavor)

if [ $LinuxFlavor = 'Ubuntu' ]
then
	SUDO_PREFIX=sudo
	$SUDO_PREFIX apt-get install -y open-iscsi
	echo ''
	echo "======================================================="
	echo "Establish sudo privileges ...                          "
	echo "======================================================="
	echo ''

	sudo date

	echo ''
	echo "======================================================="
	echo "Establish sudo privileges successful.                  "
	echo "======================================================="
	echo ''
elif [ $LinuxFlavor = 'CentOS' ]
then
	SUDO_PREFIX=
	yum -y install iscsi-initiator-utils
fi

function GetInitiatorName {
$SUDO_PREFIX cat /etc/iscsi/initiatorname.iscsi | grep -v '#' | grep iqn | cut -f2 -d'=' 
}
InitiatorName=$(GetInitiatorName)

function GetHostName {
echo $HOSTNAME 
}
HostName=$(GetHostName)

DATEYR=`date +"%Y"`
DATEMO=`date +"%m"`

# Determine User-Selected Reversed Domain IQN prefix or set it to default (com.orabuntu-lxc)

DOMAIN=$1
if [ -z $DOMAIN ]
then
DOMAIN=com.orabuntu-lxc
fi

# Determine User-Selected SCST Group Name  or set to default (lxc1)

ScstGroup=$2
if [ -z $ScstGroup ]
then
ScstGroup=lxc1
fi

# Determine User-Selected redundancy or set to default (external)

AsmRedundancy=$3

function SetCaseAsmRedundancy {
echo $AsmRedundancy | sed -e 's/\([A-Z][A-Za-z0-9]*\)/\L\1/g'
}
AsmRedundancy=$(SetCaseAsmRedundancy)

if [ -z "$3" ]
then
AsmRedundancy=external
fi

if   [ "$AsmRedundancy" = 'external' ]
then
echo 'AsmRedundancy = '$AsmRedundancy
elif [ "$AsmRedundancy" = 'normal' ]
then
echo $AsmRedundancy
elif [ "$AsmRedundancy" = 'high' ]
then
echo 'AsmRedundancy = '$AsmRedundancy
else
echo "AsmRedundancy must be in the set {external, normal, high}"
echo "Current setting of AsmRedundancy is $AsmRedundancy"
echo "Rerun program with correct spelling of external, normal, or high"
fi

Sysd1SizeGb=$4
if [ -z $Sysd1SizeGb ]
then
Sysd1SizeGb=1G
fi

Data1SizeGb=$5
if [ -z $Data1SizeGb ]
then
Data1SizeGb=1G
fi

Reco1SizeGb=$6
if [ -z $Reco1SizeGb ]
then
Reco1SizeGb=1G
fi

LogicalBlkSiz=$7
if [ -z $7 ]
then
LogicalBlkSiz=''
elif [ $LogicalBlkSiz -eq 4096 ]
then
LogicalBlkSiz=',blocksize='$7
elif [ $LogicalBlkSiz -eq 512  ]
then
LogicalBlkSiz=',blocksize='$7
elif [ $LogicalBlkSiz -ne 4096 ] && [ $LogicalBlkSiz -ne 512 ]
then
echo 'Error invalid block size'
exit
fi

echo $AsmRedundancy
echo $InitiatorName
echo $ScstGroup
echo $DATEYR
echo $DATEMO
echo $DOMAIN
echo $HostName
echo $Sysd1SizeGb
echo $Data1SizeGb
echo $Reco1SizeGb
echo $LogicalBlkSiz

sleep 10

# Create Target and Groups

$SUDO_PREFIX scstadmin -add_target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -driver iscsi
$SUDO_PREFIX scstadmin -add_group $ScstGroup -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle
$SUDO_PREFIX scstadmin -add_init $InitiatorName -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup
$SUDO_PREFIX scstadmin -write_config /etc/scst.conf

echo ''
echo "======================================================"
echo "Verify that target, groups, and initiators are added  "
echo "Sleeping for 10 seconds...                            "
echo "======================================================"
echo ''

$SUDO_PREFIX scstadmin -list_group

sleep 10

# Create file-backed devices for LUNS for Oracle ASM diskgroup SYSD1

if [ "$AsmRedundancy" = 'external' ]
then
	
	if [ ! -e /asm0 ]
	then
	$SUDO_PREFIX mkdir /asm0
	fi
	
	$SUDO_PREFIX fallocate -l $Sysd1SizeGb /asm0/asm_sysd1_00.img

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for sysd1 "
	echo "Sleeping for 10 seconds...                            "
	echo "======================================================"
	echo ''

	ls -lrt /asm0/asm_sysd1*
	
	sleep 10
	
	# Create file-backed devices for LUNS for Oracle ASM diskgroups DATA and FRA

	$SUDO_PREFIX fallocate -l $Data1SizeGb /asm0/asm_data1_00.img
	$SUDO_PREFIX fallocate -l $Reco1SizeGb /asm0/asm_reco1_00.img

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for data     "
	echo "Sleeping for 10 seconds...                            "
	echo "======================================================"
	echo ''

	ls -lrt /asm0/asm_data*

	sleep 10
	
	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for reco      "
	echo "Sleeping for 10 seconds...                            "
	echo "======================================================"
	echo ''

	ls -lrt /asm0/asm_reco*
	
	sleep 10
	
	# Open file-backed devices for Oracle ASM diskgroup SYSD1
	
	$SUDO_PREFIX scstadmin -open_dev asm_sysd1_00 -handler vdisk_fileio -attributes filename=/asm0/asm_sysd1_00.img

	# Open file-backed devices for Oracle ASM diskgroups DATA and FRA

	$SUDO_PREFIX scstadmin -open_dev asm_data1_00 -handler vdisk_fileio -attributes filename=/asm0/asm_data1_00.img$LogicalBlkSiz
	$SUDO_PREFIX scstadmin -open_dev asm_reco1_00 -handler vdisk_fileio -attributes filename=/asm0/asm_reco1_00.img$LogicalBlkSiz

	# Add LUNs for Oracle ASM diskgroup SYSD1 to SCST iscsi target

	$SUDO_PREFIX scstadmin -add_lun 0 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_sysd1_00

	# Add LUNs for Oracle ASM diskgroups DATA and FRA to SCST iscsi target

	$SUDO_PREFIX scstadmin -add_lun 1 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_data1_00
	$SUDO_PREFIX scstadmin -add_lun 2 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_reco1_00

fi

if [ "$AsmRedundancy" = 'normal' ]
then

	if [ ! -e /asm0 ]
	then
	$SUDO_PREFIX mkdir /asm0
	fi

	if [ ! -e /asm1 ]
	then
	$SUDO_PREFIX mkdir /asm1
	fi

	if [ ! -e /asm2 ]
	then
	$SUDO_PREFIX mkdir /asm2
	fi

	$SUDO_PREFIX fallocate -l $Sysd1SizeGb /asm0/asm_sysd1_00.img
	$SUDO_PREFIX fallocate -l $Sysd1SizeGb /asm1/asm_sysd1_01.img
	$SUDO_PREFIX fallocate -l $Sysd1SizeGb /asm2/asm_sysd1_02.img

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for sysd1 "
	echo "Sleeping for 10 seconds...                            "
	echo "======================================================"
	echo ''

	ls -lrt /asm0/asm_sysd1*
	ls -lrt /asm1/asm_sysd1*
	ls -lrt /asm2/asm_sysd1*

	sleep 10

	# Create file-backed devices for LUNS for Oracle ASM diskgroups DATA and FRA

	$SUDO_PREFIX fallocate -l $Data1SizeGb /asm0/asm_data1_00.img
	$SUDO_PREFIX fallocate -l $Data1SizeGb /asm1/asm_data1_01.img
	$SUDO_PREFIX fallocate -l $Data1SizeGb /asm2/asm_data1_02.img

	$SUDO_PREFIX fallocate -l $Reco1SizeGb /asm0/asm_reco1_00.img
	$SUDO_PREFIX fallocate -l $Reco1SizeGb /asm1/asm_reco1_01.img
	$SUDO_PREFIX fallocate -l $Reco1SizeGb /asm2/asm_reco1_02.img

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for data     "
	echo "Sleeping for 10 seconds...                            "
	echo "======================================================"
	echo ''

	ls -lrt /asm0/asm_data*
	ls -lrt /asm1/asm_data*
	ls -lrt /asm2/asm_data*

	sleep 10

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for reco      "
	echo "Sleeping for 10 seconds...                            "
	echo "======================================================"
	echo ''

	ls -lrt /asm0/asm_reco*
	ls -lrt /asm1/asm_reco*
	ls -lrt /asm2/asm_reco*

	sleep 10

	# Open file-backed devices for Oracle ASM diskgroup SYSD1

	$SUDO_PREFIX scstadmin -open_dev asm_sysd1_00 -handler vdisk_fileio -attributes filename=/asm0/asm_sysd1_00.img
	$SUDO_PREFIX scstadmin -open_dev asm_sysd1_01 -handler vdisk_fileio -attributes filename=/asm1/asm_sysd1_01.img
	$SUDO_PREFIX scstadmin -open_dev asm_sysd1_02 -handler vdisk_fileio -attributes filename=/asm2/asm_sysd1_02.img

	# Open file-backed devices for Oracle ASM diskgroups DATA and FRA

	$SUDO_PREFIX scstadmin -open_dev asm_data1_00 -handler vdisk_fileio -attributes filename=/asm0/asm_data1_00.img$LogicalBlkSiz
	$SUDO_PREFIX scstadmin -open_dev asm_data1_01 -handler vdisk_fileio -attributes filename=/asm1/asm_data1_01.img$LogicalBlkSiz
	$SUDO_PREFIX scstadmin -open_dev asm_data1_02 -handler vdisk_fileio -attributes filename=/asm2/asm_data1_02.img$LogicalBlkSiz

	$SUDO_PREFIX scstadmin -open_dev asm_reco1_00 -handler vdisk_fileio -attributes filename=/asm0/asm_reco1_00.img$LogicalBlkSiz
	$SUDO_PREFIX scstadmin -open_dev asm_reco1_01 -handler vdisk_fileio -attributes filename=/asm1/asm_reco1_01.img$LogicalBlkSiz
	$SUDO_PREFIX scstadmin -open_dev asm_reco1_02 -handler vdisk_fileio -attributes filename=/asm2/asm_reco1_02.img$LogicalBlkSiz

	# Add LUNs for Oracle ASM diskgroup SYSD1 to SCST iscsi target

	$SUDO_PREFIX scstadmin -add_lun 0 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_sysd1_00
	$SUDO_PREFIX scstadmin -add_lun 1 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_sysd1_01
	$SUDO_PREFIX scstadmin -add_lun 2 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_sysd1_02

	# Add LUNs for Oracle ASM diskgroups DATA and FRA to SCST iscsi target

	$SUDO_PREFIX scstadmin -add_lun 3 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_data1_00
	$SUDO_PREFIX scstadmin -add_lun 4 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_data1_01
	$SUDO_PREFIX scstadmin -add_lun 5 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_data1_02

	$SUDO_PREFIX scstadmin -add_lun 6 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_reco1_00
	$SUDO_PREFIX scstadmin -add_lun 7 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_reco1_01
	$SUDO_PREFIX scstadmin -add_lun 8 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_reco1_02
fi

if [ "$AsmRedundancy" = 'high' ]
then

	if [ ! -e /asm0 ]
	then
	$SUDO_PREFIX mkdir /asm0
	fi

	if [ ! -e /asm1 ]
	then
	$SUDO_PREFIX mkdir /asm1
	fi

	if [ ! -e /asm2 ]
	then
	$SUDO_PREFIX mkdir /asm2
	fi

	if [ ! -e /asm3 ]
	then
	$SUDO_PREFIX mkdir /asm3
	fi

	if [ ! -e /asm4 ]
	then
	$SUDO_PREFIX mkdir /asm4
	fi

	$SUDO_PREFIX fallocate -l $Sysd1SizeGb /asm0/asm_sysd1_00.img
	$SUDO_PREFIX fallocate -l $Sysd1SizeGb /asm1/asm_sysd1_01.img
	$SUDO_PREFIX fallocate -l $Sysd1SizeGb /asm2/asm_sysd1_02.img
	$SUDO_PREFIX fallocate -l $Sysd1SizeGb /asm3/asm_sysd1_03.img
	$SUDO_PREFIX fallocate -l $Sysd1SizeGb /asm4/asm_sysd1_04.img

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for sysd1 "
	echo "Sleeping for 10 seconds...                            "
	echo "======================================================"
	echo ''

	ls -lrt /asm0/asm_sysd1*
	ls -lrt /asm1/asm_sysd1*
	ls -lrt /asm2/asm_sysd1*
	ls -lrt /asm3/asm_sysd1*
	ls -lrt /asm4/asm_sysd1*

	sleep 10

	# Create file-backed devices for LUNS for Oracle ASM diskgroups DATA and FRA

	$SUDO_PREFIX fallocate -l $Data1SizeGb /asm0/asm_data1_00.img
	$SUDO_PREFIX fallocate -l $Data1SizeGb /asm1/asm_data1_01.img
	$SUDO_PREFIX fallocate -l $Data1SizeGb /asm2/asm_data1_02.img
	$SUDO_PREFIX fallocate -l $Data1SizeGb /asm3/asm_data1_03.img
	$SUDO_PREFIX fallocate -l $Data1SizeGb /asm4/asm_data1_04.img

	$SUDO_PREFIX fallocate -l $Reco1SizeGb /asm0/asm_reco1_00.img
	$SUDO_PREFIX fallocate -l $Reco1SizeGb /asm1/asm_reco1_01.img
	$SUDO_PREFIX fallocate -l $Reco1SizeGb /asm2/asm_reco1_02.img
	$SUDO_PREFIX fallocate -l $Reco1SizeGb /asm3/asm_reco1_03.img
	$SUDO_PREFIX fallocate -l $Reco1SizeGb /asm4/asm_reco1_04.img

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for data     "
	echo "Sleeping for 10 seconds...                            "
	echo "======================================================"
	echo ''

	ls -lrt /asm0/asm_data*
	ls -lrt /asm1/asm_data*
	ls -lrt /asm2/asm_data*
	ls -lrt /asm3/asm_data*
	ls -lrt /asm4/asm_data*

	sleep 10

	echo ''
	echo "======================================================"
	echo "Verify that device backing files created for reco      "
	echo "Sleeping for 10 seconds...                            "
	echo "======================================================"
	echo ''

	ls -lrt /asm0/asm_reco*
	ls -lrt /asm1/asm_reco*
	ls -lrt /asm2/asm_reco*
	ls -lrt /asm3/asm_reco*
	ls -lrt /asm4/asm_reco*

	sleep 10

	# Open file-backed devices for Oracle ASM diskgroup SYSD1

	$SUDO_PREFIX scstadmin -open_dev asm_sysd1_00 -handler vdisk_fileio -attributes filename=/asm0/asm_sysd1_00.img
	$SUDO_PREFIX scstadmin -open_dev asm_sysd1_01 -handler vdisk_fileio -attributes filename=/asm1/asm_sysd1_01.img
	$SUDO_PREFIX scstadmin -open_dev asm_sysd1_02 -handler vdisk_fileio -attributes filename=/asm2/asm_sysd1_02.img
	$SUDO_PREFIX scstadmin -open_dev asm_sysd1_03 -handler vdisk_fileio -attributes filename=/asm3/asm_sysd1_03.img
	$SUDO_PREFIX scstadmin -open_dev asm_sysd1_04 -handler vdisk_fileio -attributes filename=/asm4/asm_sysd1_04.img

	# Open file-backed devices for Oracle ASM diskgroups DATA and FRA

	$SUDO_PREFIX scstadmin -open_dev asm_data1_00 -handler vdisk_fileio -attributes filename=/asm0/asm_data1_00.img$LogicalBlkSiz
	$SUDO_PREFIX scstadmin -open_dev asm_data1_01 -handler vdisk_fileio -attributes filename=/asm1/asm_data1_01.img$LogicalBlkSiz
	$SUDO_PREFIX scstadmin -open_dev asm_data1_02 -handler vdisk_fileio -attributes filename=/asm2/asm_data1_02.img$LogicalBlkSiz
	$SUDO_PREFIX scstadmin -open_dev asm_data1_03 -handler vdisk_fileio -attributes filename=/asm3/asm_data1_03.img$LogicalBlkSiz
	$SUDO_PREFIX scstadmin -open_dev asm_data1_04 -handler vdisk_fileio -attributes filename=/asm4/asm_data1_04.img$LogicalBlkSiz

	$SUDO_PREFIX scstadmin -open_dev asm_reco1_00 -handler vdisk_fileio -attributes filename=/asm0/asm_reco1_00.img$LogicalBlkSiz
	$SUDO_PREFIX scstadmin -open_dev asm_reco1_01 -handler vdisk_fileio -attributes filename=/asm1/asm_reco1_01.img$LogicalBlkSiz
	$SUDO_PREFIX scstadmin -open_dev asm_reco1_02 -handler vdisk_fileio -attributes filename=/asm2/asm_reco1_02.img$LogicalBlkSiz
	$SUDO_PREFIX scstadmin -open_dev asm_reco1_03 -handler vdisk_fileio -attributes filename=/asm3/asm_reco1_03.img$LogicalBlkSiz
	$SUDO_PREFIX scstadmin -open_dev asm_reco1_04 -handler vdisk_fileio -attributes filename=/asm4/asm_reco1_04.img$LogicalBlkSiz

	# Add LUNs for Oracle ASM diskgroup SYSD1 to SCST iscsi target

	$SUDO_PREFIX scstadmin -add_lun 0 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_sysd1_00
	$SUDO_PREFIX scstadmin -add_lun 1 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_sysd1_01
	$SUDO_PREFIX scstadmin -add_lun 2 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_sysd1_02
	$SUDO_PREFIX scstadmin -add_lun 3 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_sysd1_03
	$SUDO_PREFIX scstadmin -add_lun 4 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_sysd1_04

	# Add LUNs for Oracle ASM diskgroups DATA and FRA to SCST iscsi target

	$SUDO_PREFIX scstadmin -add_lun 5 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_data1_00
	$SUDO_PREFIX scstadmin -add_lun 6 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_data1_01
	$SUDO_PREFIX scstadmin -add_lun 7 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_data1_02
	$SUDO_PREFIX scstadmin -add_lun 8 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_data1_03
	$SUDO_PREFIX scstadmin -add_lun 9 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_data1_04

	$SUDO_PREFIX scstadmin -add_lun 10 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_reco1_00
	$SUDO_PREFIX scstadmin -add_lun 11 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_reco1_01
	$SUDO_PREFIX scstadmin -add_lun 12 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_reco1_02
	$SUDO_PREFIX scstadmin -add_lun 13 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_reco1_03
	$SUDO_PREFIX scstadmin -add_lun 14 -driver iscsi -target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -group $ScstGroup -device asm_reco1_04

fi

# Write SCST configuration to /etc/scst.conf file

$SUDO_PREFIX scstadmin -write_config /etc/scst.conf

# Enable SCST target for access

$SUDO_PREFIX scstadmin -enable_target iqn.$DATEYR-$DATEMO.$DOMAIN:$HostName.san.asm.oracle -driver iscsi
$SUDO_PREFIX scstadmin -write_config /etc/scst.conf
sleep 5

echo "======================================================"
echo "Answer y here...                                      "
echo "======================================================"
  
$SUDO_PREFIX scstadmin -set_drv_attr iscsi -attributes enabled=1
sleep 5
$SUDO_PREFIX scstadmin -write_config /etc/scst.conf

echo ''
echo "======================================================"
echo "Verify that SCST SAN is fully configured and ready    "
echo "Sleeping for 10 seconds...                            "
echo "======================================================"
echo ''

$SUDO_PREFIX scstadmin -list_group

