function CheckContainersRunning {
sudo lxc-ls -f | grep RUNNING | sed 's/  */ /g' | cut -f1 -d' ' | sed 's/$/ /' | tr -d '\n' |  sed 's/^[ \t]*//;s/[ \t]*$//'
}
ContainersRunning=$(CheckContainersRunning)

for i in $ContainersRunning
do
sudo lxc-stop -n $i
sleep 5
done

