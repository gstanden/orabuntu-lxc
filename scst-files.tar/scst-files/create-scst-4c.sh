cd /asm
  echo ''
  echo "======================================================"
  echo "Verify that target, groups, and initiators are added  "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''
  sudo scstadmin -list_group
  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for systemdg "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''
ls -lrt /asm/asm_systemdg*
sudo fallocate -l 30G /asm/asm_data1_00.img
sudo fallocate -l 30G /asm/asm_data1_01.img
sudo fallocate -l 30G /asm/asm_data1_02.img
sudo fallocate -l 30G /asm/asm_fra1_00.img
sudo fallocate -l 30G /asm/asm_fra1_01.img
sudo fallocate -l 30G /asm/asm_fra1_02.img
sudo scstadmin -open_dev asm_data1_00    -handler vdisk_fileio -attributes filename=/asm/asm_data1_00.img
sudo scstadmin -open_dev asm_data1_01    -handler vdisk_fileio -attributes filename=/asm/asm_data1_01.img
sudo scstadmin -open_dev asm_data1_02    -handler vdisk_fileio -attributes filename=/asm/asm_data1_02.img
sudo scstadmin -open_dev asm_fra1_00     -handler vdisk_fileio -attributes filename=/asm/asm_fra1_00.img
sudo scstadmin -open_dev asm_fra1_01     -handler vdisk_fileio -attributes filename=/asm/asm_fra1_01.img
sudo scstadmin -open_dev asm_fra1_02     -handler vdisk_fileio -attributes filename=/asm/asm_fra1_02.img
sudo scstadmin -add_lun 3 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_data1_00
sudo scstadmin -add_lun 4 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_data1_01
sudo scstadmin -add_lun 5 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_data1_02
sudo scstadmin -add_lun 6 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_fra1_00
sudo scstadmin -add_lun 7 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_fra1_01
sudo scstadmin -add_lun 8 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_fra1_02
  sleep 5
  echo ''
  echo "======================================================"
  echo "Verify that SCST SAN is fully configured and ready    "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''
  sudo scstadmin -list_group

