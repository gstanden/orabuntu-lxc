#!/bin/bash

# sudo service multipath-tools stop
# sudo multipath -F

if [ -e /etc/multipath.conf ]
then
sudo cp -p /etc/multipath.conf /etc/multipath.conf.original.bak
fi

sudo cp -p ~/Downloads/scst-files/multipath.conf /etc/multipath.conf
sudo chmod 755 /etc/multipath.conf

# sudo mv ~/Downloads/scst-files/multipath.conf.readme /etc/multipath.conf.readme

echo ''
echo "==========================================================================="
echo "Login to SCST target...                                                    "
echo "Verify that login to SCST target is successful...                          "
echo "==========================================================================="
echo ''

sudo iscsiadm --mode node --targetname iqn.2015-08.org.vmem:w520.san.asm.luns   --portal 10.207.41.1 --login
sudo iscsiadm --mode node --targetname iqn.2015-08.org.vmem:w520.san.asm.luns   --portal 10.207.40.1 --login

echo ''
echo "==========================================================================="
echo "Verify /dev/mapper output...                                               "
echo "Multipath ASM LUNs (/dev/mapper/asm_*) for Oracle should be present...     "
echo "==========================================================================="
echo ''

ls -l /dev/mapper

sleep 8

echo ''
echo "==========================================================================="
echo "Logout of SCST target...                                                   "
echo "Verify that logout of SCST target is successful...                         "
echo "==========================================================================="
echo ''

sudo iscsiadm --mode node --targetname iqn.2015-08.org.vmem:w520.san.asm.luns   --portal 10.207.41.1 --logout
sudo iscsiadm --mode node --targetname iqn.2015-08.org.vmem:w520.san.asm.luns   --portal 10.207.40.1 --logout

sudo multipath -F

echo ''
echo "==========================================================================="
echo "Verify /dev/mapper output...                                               "
echo "Should not be any multipath LUNs at this time...                           "
echo "==========================================================================="
echo ''

ls -lrt /dev/mapper

sleep 8

echo '' 
echo "==========================================================================="
echo "Sleeping 10 seconds...then rebooting                                       "
echo "==========================================================================="
echo ''
sleep 10

# sudo multipath -ll -v2
sudo reboot


