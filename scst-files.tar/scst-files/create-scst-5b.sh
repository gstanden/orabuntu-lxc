#! /bin/bash

sudo cp -p /etc/multipath.conf /etc/multipath.conf.bak
sudo cp -p ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf /etc/multipath.conf
sudo chmod 644 /etc/multipath.conf
sudo chown root:root /etc/multipath.conf

# GLS 20151128 The below files can be used for additional shutdown and startup commands as needed.

sudo cp -p ~/Downloads/orabuntu-lxc-master/scst-files/custom-start-shutdown.service /lib/systemd/system/custom-start-shutdown.service
sudo cp -p ~/Downloads/orabuntu-lxc-master/scst-files/custom-start.sh /usr/lib/systemd/scripts/custom-start.sh
sudo cp -p ~/Downloads/orabuntu-lxc-master/scst-files/custom-shutdown.sh /usr/lib/systemd/scripts/custom-shutdown.sh

# GLS 20151128 Added code to login to SCST during startup.
sudo chmod 755 /usr/lib/systemd/scripts/custom-start.sh
sudo chown root:root /usr/lib/systemd/scripts/custom-start.sh

# GLS 20151128 Added code to logout of SCST and stop multipath during shutdown.
sudo chmod 755 /usr/lib/systemd/scripts/custom-shutdown.sh
sudo chown root:root /usr/lib/systemd/scripts/custom-shutdown.sh

sudo chmod 644 /lib/systemd/system/custom-start-shutdown.service
sudo chown root:root /lib/systemd/system/custom-start-shutdown.service
sudo systemctl enable custom-start-shutdown.service

echo "Rebooting in 5 seconds..."

sleep 5

sudo shutdown -h now
