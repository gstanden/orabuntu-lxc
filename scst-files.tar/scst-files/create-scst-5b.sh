#! /bin/bash

sudo cp -p /etc/multipath.conf /etc/multipath.conf.bak
sudo cp -p ~/Downloads/scst-files/multipath.conf /etc/multipath.conf
sudo chmod 755 /etc/multipath.conf

echo "Rebooting in 5 seconds..."

sleep 5

sudo reboot
