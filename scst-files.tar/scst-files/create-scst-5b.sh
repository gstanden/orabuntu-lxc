#!/bin/bash

sudo service multipath-tools stop
sudo multipath -F

if [ -e /etc/multipath.conf ]
then
sudo cp -p /etc/multipath.conf /etc/multipath.conf.original.bak
fi

sudo mv ~/Downloads/scst-files/multipath.conf /etc/multipath.conf
# sudo mv ~/Downloads/scst-files/multipath.conf.readme /etc/multipath.conf.readme
sudo iscsiadm --mode node --targetname iqn.2015-08.org.vmem:w520.san.asm.luns   --portal 10.207.41.1 --logout
sudo iscsiadm --mode node --targetname iqn.2015-08.org.vmem:w520.san.asm.luns   --portal 10.207.40.1 --logout
sudo multipath -F

# echo "==========================================================================="
# echo "Login to SCST target...                                                    "
# echo "Verify that login to SCST target is successful...                          "
# echo "==========================================================================="
# echo ''
sudo iscsiadm --mode node --targetname iqn.2015-08.org.vmem:w520.san.asm.luns   --portal 10.207.41.1 --login
sudo iscsiadm --mode node --targetname iqn.2015-08.org.vmem:w520.san.asm.luns   --portal 10.207.40.1 --login
# echo ''

sudo service multipath-tools start

# echo "==========================================================================="
# echo "Verify /dev/mapper output...should be using multipath friendly names...    "
# echo "Sleeping 5 seconds...                                                     "
# echo "==========================================================================="
# echo ' '
# sleep 5

# ls -lrt /dev/mapper

# echo '' 
echo "==========================================================================="
# echo "Verify multipath -ll -v2 output ...                                      "
echo "Sleeping 5 seconds...then rebooting                                        "
echo "==========================================================================="
echo ''
sleep 5

# sudo multipath -ll -v2
sudo reboot


