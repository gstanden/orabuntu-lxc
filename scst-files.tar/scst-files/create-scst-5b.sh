#    Copyright 2015-2016 Gilbert Standen
#    This file is part of orabuntu-lxc.

#    Orabuntu-lxc is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-lxc is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with orabuntu-lxc.  If not, see <http://www.gnu.org/licenses/>.

#    v2.8 GLS 20151231

#! /bin/bash

sudo cp -p /etc/multipath.conf /etc/multipath.conf.bak
sudo cp -p ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf /etc/multipath.conf
sudo chmod 644 /etc/multipath.conf
sudo chown root:root /etc/multipath.conf

# GLS 20151128 The below files can be used for additional shutdown and startup commands as needed.

# sudo cp -p ~/Downloads/orabuntu-lxc-master/scst-files/custom-start-shutdown.service /lib/systemd/system/custom-start-shutdown.service
# sudo cp -p ~/Downloads/orabuntu-lxc-master/scst-files/custom-start.sh /usr/lib/systemd/scripts/custom-start.sh
# sudo cp -p ~/Downloads/orabuntu-lxc-master/scst-files/custom-shutdown.sh /usr/lib/systemd/scripts/custom-shutdown.sh

# GLS 20151128 Added code to login to SCST during startup.
# sudo chmod 755 /usr/lib/systemd/scripts/custom-start.sh
# sudo chown root:root /usr/lib/systemd/scripts/custom-start.sh

# GLS 20151128 Added code to logout of SCST and stop multipath during shutdown.
# sudo chmod 755 /usr/lib/systemd/scripts/custom-shutdown.sh
# sudo chown root:root /usr/lib/systemd/scripts/custom-shutdown.sh

# sudo chmod 644 /lib/systemd/system/custom-start-shutdown.service
# sudo chown root:root /lib/systemd/system/custom-start-shutdown.service
# sudo systemctl enable custom-start-shutdown.service

echo ''
echo "=============================================="
echo "Ubuntu Host reboot is recommended to finalize "
echo "multipath storage configuration.              "
echo "=============================================="
read -e -p "Reboot Ubuntu Host ? [Y/N]    " -i "N" RebootUbuntuHost
echo "=============================================="
echo ''

if [ $RebootUbuntuHost = 'Y' ] || [ $RebootUbuntuHost = 'y' ]
then
echo "Rebooting in 5 seconds..."
sleep 5
sudo shutdown -h now
fi
