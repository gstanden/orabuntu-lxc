#!/bin/bash

cd ~/Downloads/linux-3.19.0/

echo "=============================================================="
echo "About to write vars.scst...                                   "
echo "Sleeping 20 seconds...                                        "
echo "=============================================================="

sudo sed -i "s/Generic/SCST/" debian.master/control.d/vars.scst

echo ''
echo "=============================================================="
echo "About to write getabis for scst...                            "
echo "=============================================================="

sudo sed -i "s/getall amd64 generic lowlatency/getall amd64 generic lowlatency scst/" debian.master/etc/getabis

echo ''
echo "=============================================================="
echo "About to write amd64.mk for scst...                           "
echo "=============================================================="

sudo sed -i "s/generic lowlatency/generic lowlatency scst/" debian.master/rules.d/amd64.mk

echo ''
echo "=============================================================="
sudo cat debian.master/control.d/vars.scst
echo "=============================================================="
echo ''
sleep 5

echo ''
echo "=============================================================="
sudo cat debian.master/etc/getabis
echo "=============================================================="
echo ''
sleep 5

echo ''
echo "=============================================================="
sudo cat debian.master/rules.d/amd64.mk
echo "=============================================================="
echo ''
sleep 5

