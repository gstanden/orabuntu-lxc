#!/bin/bash
sudo iscsiadm --mode node --targetname iqn.2015-08.org.vmem:w520.san.asm.luns --portal 10.207.41.1 --logout
sudo iscsiadm --mode node --targetname iqn.2015-08.org.vmem:w520.san.asm.luns --portal 10.207.40.1 --logout
sudo multipath -F

