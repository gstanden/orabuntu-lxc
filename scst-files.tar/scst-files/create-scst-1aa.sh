cd ~/Downloads
pwd
sudo apt-get install -y debian-keyring
# ssh-keygen -t rsa  # first run only do not uncomment if lxc-containers have already been installed for Oracle
sleep 10
sudo gpg --keyserver keyserver.ubuntu.com --recv-keys B1CDE58F
sudo gpg --no-default-keyring -a --export B1CDE58F | sudo gpg --no-default-keyring --keyring ~/.gnupg/trustedkeys.gpg --import -
echo "======================================================="
echo "Verify gpg key installed successfully                  "
echo "Sleeping 20 seconds...                                 "
echo "======================================================="
sudo apt-get install -y subversion
sleep 10
sudo svn co https://scst.svn.sourceforge.net/svnroot/scst/trunk scst
cd scst
