#    Copyright 2015-2016 Gilbert Standen
#    This file is part of orabuntu-lxc.

#    Orabuntu-lxc is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-lxc is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with orabuntu-lxc.  If not, see <http://www.gnu.org/licenses/>.

#    v2.8 GLS 20151231
#    v3.0 GLS 20160710

#!/bin/bash

cd ~/Downloads

ls -l linux-image-* linux-headers*
sleep 10

sudo dpkg -i linux-image-* linux-headers*
sleep 5

sudo update-initramfs -u
sleep 5

function CheckContainersRunning {
sudo lxc-ls -f | grep RUNNING | sed 's/  */ /g' | cut -f1 -d' ' | sed 's/$/ /' | tr -d '\n' |  sed 's/^[ \t]*//;s/[ \t]*$//'
}
ContainersRunning=$(CheckContainersRunning)

for i in $ContainersRunning
do
sudo lxc-stop -n $i
sleep 5
done

echo ''
echo "==========================================="
echo "Verify LXC Containers are shutdown ...     "
echo "==========================================="

sudo lxc-ls -f

echo "==========================================="
echo "Rebooting in 5 seconds...                 "
echo "==========================================="

sleep 5

sudo reboot
