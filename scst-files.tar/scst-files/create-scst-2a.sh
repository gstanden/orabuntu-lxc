#!/bin/bash

cd ~/Downloads

ls -l linux-image-* linux-headers*
sleep 10

sudo dpkg -i linux-image-* linux-headers*
sleep 5

sudo update-initramfs -u
sleep 5

sudo lxc-stop -n lxcora01
sleep 5
sudo lxc-stop -n lxcora02
sleep 5
sudo lxc-stop -n lxcora03
sleep 5
sudo lxc-stop -n lxcora04
sleep 5
sudo lxc-stop -n lxcora05
sleep 5
sudo lxc-stop -n lxcora06
sleep 5

echo ''
echo "==========================================="
echo "Verify LXC Containers are shutdown ...     "
echo "==========================================="

sudo lxc-ls -f

echo "==========================================="
echo "Rebooting in 5 seconds...                 "
echo "==========================================="

sleep 5

sudo reboot
