cd ~/Downloads/linux-3.19.0/
sudo fakeroot debian/rules clean
sleep 2
sudo debian/rules updateconfigs
sleep 2
sudo debian/rules editconfigs
sleep 2
sudo fakeroot debian/rules clean
sleep 2
# Using skipabi=true for build success
sudo skipabi=true fakeroot debian/rules -j8 binary-headers binary-scst
# sudo fakeroot debian/rules -j8 binary-headers binary-scst
sleep 2
