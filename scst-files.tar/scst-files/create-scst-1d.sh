#!/bin/bash

# GLS 20151126 Added function to get kernel version of running kernel to support linux 4.x kernels in Ubuntu Wily Werewolf etc.

function GetRunningKernelVersion {
uname -r | cut -f1-2 -d'.'
}
RunningKernelVersion=$(GetRunningKernelVersion)

# GLS 20151126 Added function to get kernel directory path for running kernel version to support linux 4.x and linux 3.x kernels etc.

function GetKernelDirectoryPath {
uname -a | cut -f3 -d' ' | cut -f1 -d'-' | sed 's/^/linux-/'
}
KernelDirectoryPath=$(GetKernelDirectoryPath)

cd ~/Downloads/$KernelDirectoryPath/
sudo fakeroot debian/rules clean
sleep 2
sudo debian/rules updateconfigs
sleep 2
sudo debian/rules editconfigs
sleep 2
sudo fakeroot debian/rules clean
sleep 2
# Using skipabi=true for build success
sudo skipabi=true fakeroot debian/rules -j8 binary-headers binary-scst
# sudo fakeroot debian/rules -j8 binary-headers binary-scst
sleep 2
