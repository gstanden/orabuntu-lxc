#    Copyright 2015-2016 Gilbert Standen
#    This file is part of orabuntu-lxc.

#    Orabuntu-lxc is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-lxc is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with orabuntu-lxc.  If not, see <http://www.gnu.org/licenses/>.

#    v2.8 GLS 20151231
#    v3.0 GLS 20160710

#!/bin/bash

# GLS 20151126 Added function to get kernel version of running kernel to support linux 4.x kernels in Ubuntu Wily Werewolf etc.

function GetRunningKernelVersion {
uname -r | cut -f1-2 -d'.'
}
RunningKernelVersion=$(GetRunningKernelVersion)

# GLS 20151126 Added function to get kernel directory path for running kernel version to support linux 4.x and linux 3.x kernels etc.

function GetKernelDirectoryPath {
uname -a | cut -f3 -d' ' | cut -f1 -d'-' | sed 's/^/linux-/'
}
KernelDirectoryPath=$(GetKernelDirectoryPath)

cd ~/Downloads/$KernelDirectoryPath/

function GetGenericOriginal () { find . -name generic | grep amd64 | sed 's/\.\///'; }
Generic=$(GetGenericOriginal)

function GetGenericSCST () { find . -name generic | grep amd64 | sed 's/generic/scst/' | sed 's/\.\///'; }
GenericSCST=$(GetGenericSCST)

function GetModulesOriginal () { find . -name generic.modules | grep amd64 | sed 's/\.\///'; }
ModulesOriginal=$(GetModulesOriginal)

function GetModulesSCST () { find . -name generic.modules | grep amd64 | sed 's/generic\.modules/scst\.modules/' | sed 's/\.\///'; }
ModulesSCST=$(GetModulesSCST)

sudo cp debian.master/config/amd64/config.flavour.generic debian.master/config/amd64/config.flavour.scst
sudo cp $Generic $GenericSCST
sudo cp $ModulesOriginal $ModulesSCST
sudo cp debian.master/control.d/vars.generic debian.master/control.d/vars.scst

ls -lrt debian.master/config/amd64/config.flavour.scst
ls -lrt $GenericSCST
ls -lrt $ModulesSCST
ls -lrt debian.master/control.d/vars.scst
