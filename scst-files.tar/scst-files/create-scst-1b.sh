#!/bin/bash

cd ~/Downloads/linux-3.19.0/
sudo cp debian.master/config/amd64/config.flavour.generic debian.master/config/amd64/config.flavour.scst
sudo cp debian.master/abi/3.19.0-26.27/amd64/generic debian.master/abi/3.19.0-26.27/amd64/scst
sudo cp debian.master/abi/3.19.0-26.27/amd64/generic.modules debian.master/abi/3.19.0-26.27/amd64/scst.modules
sudo cp debian.master/control.d/vars.generic debian.master/control.d/vars.scst
ls -lrt debian.master/config/amd64/config.flavour.scst
ls -lrt debian.master/abi/3.19.0-26.27/amd64/scst
ls -lrt debian.master/abi/3.19.0-26.27/amd64/scst.modules
ls -lrt debian.master/control.d/vars.scst
