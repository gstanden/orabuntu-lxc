#!/bin/bash

# GLS 20151126 Added function to get kernel version of running kernel to support linux 4.x kernels in Ubuntu Wily Werewolf etc.

function GetRunningKernelVersion {
uname -r | cut -f1-2 -d'.'
}
RunningKernelVersion=$(GetRunningKernelVersion)

# GLS 20151126 Added function to get kernel directory path for running kernel version to support linux 4.x and linux 3.x kernels etc.

function GetKernelDirectoryPath {
uname -a | cut -f3 -d' ' | cut -f1 -d'-' | sed 's/^/linux-/'
}
KernelDirectoryPath=$(GetKernelDirectoryPath)

cd ~/Downloads/$KernelDirectoryPath/

function GetGenericOriginal () { find . -name generic | grep amd64 | sed 's/\.\///'; }
Generic=$(GetGenericOriginal)

function GetGenericSCST () { find . -name generic | grep amd64 | sed 's/generic/scst/' | sed 's/\.\///'; }
GenericSCST=$(GetGenericSCST)

function GetModulesOriginal () { find . -name generic.modules | grep amd64 | sed 's/\.\///'; }
ModulesOriginal=$(GetModulesOriginal)

function GetModulesSCST () { find . -name generic.modules | grep amd64 | sed 's/generic\.modules/scst\.modules/' | sed 's/\.\///'; }
ModulesSCST=$(GetModulesSCST)

sudo cp debian.master/config/amd64/config.flavour.generic debian.master/config/amd64/config.flavour.scst
sudo cp $Generic $GenericSCST
sudo cp $ModulesOriginal $ModulesSCST
sudo cp debian.master/control.d/vars.generic debian.master/control.d/vars.scst

ls -lrt debian.master/config/amd64/config.flavour.scst
ls -lrt $GenericSCST
ls -lrt $ModulesSCST
ls -lrt debian.master/control.d/vars.scst
