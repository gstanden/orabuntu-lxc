#    Copyright 2015-2016 Gilbert Standen
#    This file is part of orabuntu-lxc.

#    Orabuntu-lxc is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-lxc is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with orabuntu-lxc.  If not, see <http://www.gnu.org/licenses/>.

#    v2.8 GLS 20151231

#!/bin/bash

# Determine User-Selected redundancy or set to default (external)

AsmRedundancy=$1

function SetCaseAsmRedundancy {
echo $AsmRedundancy | sed -e 's/\([A-Z][A-Za-z0-9]*\)/\L\1/g'
}
AsmRedundancy=$(SetCaseAsmRedundancy)

if [ -z "$1" ]
then
  AsmRedundancy=external
fi

if   [ "$AsmRedundancy" = 'external' ]
then
  echo $AsmRedundancy
elif [ "$AsmRedundancy" = 'normal' ]
then
  echo $AsmRedundancy
elif [ "$AsmRedundancy" = 'high' ]
then
  echo $AsmRedundancy
else
  echo "AsmRedundancy must be in the set {external, normal, high}"
  echo "Current setting of AsmRedundancy is $AsmRedundancy"
  echo "Rerun program with correct spelling of external, normal, or high"
fi

# Create Target and Groups

  sudo scstadmin -add_target iqn.2015-08.org.vmem:w520.san.asm.luns -driver iscsi
  sudo scstadmin -add_group lxc1 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns
  sudo scstadmin -add_init iqn.2014-09.org.vmem1:oracle.asm.luns -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1
  sudo scstadmin -write_config /etc/scst.conf

  echo ''
  echo "======================================================"
  echo "Verify that target, groups, and initiators are added  "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''

  sudo scstadmin -list_group

  sleep 10

# Create file-backed devices for LUNS for Oracle ASM diskgroup SYSTEMDG

if [ "$AsmRedundancy" = 'external' ]
then

  if [ ! -e /asm0 ]
  then
  sudo mkdir /asm0
  fi

  sudo fallocate -l 10G /asm0/asm_systemdg_00.img

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for systemdg "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_systemdg*

  sleep 10

# Create file-backed devices for LUNS for Oracle ASM diskgroups DATA and FRA

  sudo fallocate -l 40G /asm0/asm_data1_00.img
  sudo fallocate -l 40G /asm0/asm_fra1_00.img

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for data     "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_data*

  sleep 10

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for fra      "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_fra*

  sleep 10

# Open file-backed devices for Oracle ASM diskgroup SYSTEMDG

  sudo scstadmin -open_dev asm_systemdg_00 -handler vdisk_fileio -attributes filename=/asm0/asm_systemdg_00.img

# Open file-backed devices for Oracle ASM diskgroups DATA and FRA

  sudo scstadmin -open_dev asm_data1_00    -handler vdisk_fileio -attributes filename=/asm0/asm_data1_00.img
  sudo scstadmin -open_dev asm_fra1_00     -handler vdisk_fileio -attributes filename=/asm0/asm_fra1_00.img

# Add LUNs for Oracle ASM diskgroup SYSTEMDG to SCST iscsi target

  sudo scstadmin -add_lun 0 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_systemdg_00

# Add LUNs for Oracle ASM diskgroups DATA and FRA to SCST iscsi target

  sudo scstadmin -add_lun 1 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_data1_00
  sudo scstadmin -add_lun 2 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_fra1_00

fi

if [ "$AsmRedundancy" = 'normal' ]
then

  if [ ! -e /asm0 ]
  then
  sudo mkdir /asm0
  fi

  if [ ! -e /asm1 ]
  then
  sudo mkdir /asm1
  fi

  if [ ! -e /asm2 ]
  then
  sudo mkdir /asm2
  fi

  sudo fallocate -l 10G /asm0/asm_systemdg_00.img
  sudo fallocate -l 10G /asm1/asm_systemdg_01.img
  sudo fallocate -l 10G /asm2/asm_systemdg_02.img

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for systemdg "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_systemdg*
  ls -lrt /asm1/asm_systemdg*
  ls -lrt /asm2/asm_systemdg*

  sleep 10

# Create file-backed devices for LUNS for Oracle ASM diskgroups DATA and FRA

  sudo fallocate -l 40G /asm0/asm_data1_00.img
  sudo fallocate -l 40G /asm1/asm_data1_01.img
  sudo fallocate -l 40G /asm2/asm_data1_02.img

  sudo fallocate -l 40G /asm0/asm_fra1_00.img
  sudo fallocate -l 40G /asm1/asm_fra1_01.img
  sudo fallocate -l 40G /asm2/asm_fra1_02.img

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for data     "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_data*
  ls -lrt /asm1/asm_data*
  ls -lrt /asm2/asm_data*

  sleep 10

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for fra      "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_fra*
  ls -lrt /asm1/asm_fra*
  ls -lrt /asm2/asm_fra*

  sleep 10

# Open file-backed devices for Oracle ASM diskgroup SYSTEMDG

  sudo scstadmin -open_dev asm_systemdg_00 -handler vdisk_fileio -attributes filename=/asm0/asm_systemdg_00.img
  sudo scstadmin -open_dev asm_systemdg_01 -handler vdisk_fileio -attributes filename=/asm1/asm_systemdg_01.img
  sudo scstadmin -open_dev asm_systemdg_02 -handler vdisk_fileio -attributes filename=/asm2/asm_systemdg_02.img

# Open file-backed devices for Oracle ASM diskgroups DATA and FRA

  sudo scstadmin -open_dev asm_data1_00    -handler vdisk_fileio -attributes filename=/asm0/asm_data1_00.img
  sudo scstadmin -open_dev asm_data1_01    -handler vdisk_fileio -attributes filename=/asm1/asm_data1_01.img
  sudo scstadmin -open_dev asm_data1_02    -handler vdisk_fileio -attributes filename=/asm2/asm_data1_02.img

  sudo scstadmin -open_dev asm_fra1_00     -handler vdisk_fileio -attributes filename=/asm0/asm_fra1_00.img
  sudo scstadmin -open_dev asm_fra1_01     -handler vdisk_fileio -attributes filename=/asm1/asm_fra1_01.img
  sudo scstadmin -open_dev asm_fra1_02     -handler vdisk_fileio -attributes filename=/asm2/asm_fra1_02.img

# Add LUNs for Oracle ASM diskgroup SYSTEMDG to SCST iscsi target

  sudo scstadmin -add_lun 0 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_systemdg_00
  sudo scstadmin -add_lun 1 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_systemdg_01
  sudo scstadmin -add_lun 2 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_systemdg_02

# Add LUNs for Oracle ASM diskgroups DATA and FRA to SCST iscsi target

  sudo scstadmin -add_lun 3 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_data1_00
  sudo scstadmin -add_lun 4 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_data1_01
  sudo scstadmin -add_lun 5 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_data1_02

  sudo scstadmin -add_lun 6 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_fra1_00
  sudo scstadmin -add_lun 7 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_fra1_01
  sudo scstadmin -add_lun 8 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_fra1_02

fi

if [ "$AsmRedundancy" = 'high' ]
then

  if [ ! -e /asm0 ]
  then
  sudo mkdir /asm0
  fi

  if [ ! -e /asm1 ]
  then
  sudo mkdir /asm1
  fi

  if [ ! -e /asm2 ]
  then
  sudo mkdir /asm2
  fi

  if [ ! -e /asm3 ]
  then
  sudo mkdir /asm3
  fi

  if [ ! -e /asm4 ]
  then
  sudo mkdir /asm4
  fi

  sudo fallocate -l 10G /asm0/asm_systemdg_00.img
  sudo fallocate -l 10G /asm1/asm_systemdg_01.img
  sudo fallocate -l 10G /asm2/asm_systemdg_02.img
  sudo fallocate -l 10G /asm3/asm_systemdg_03.img
  sudo fallocate -l 10G /asm4/asm_systemdg_04.img

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for systemdg "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_systemdg*
  ls -lrt /asm1/asm_systemdg*
  ls -lrt /asm2/asm_systemdg*
  ls -lrt /asm3/asm_systemdg*
  ls -lrt /asm4/asm_systemdg*

  sleep 10

# Create file-backed devices for LUNS for Oracle ASM diskgroups DATA and FRA

  sudo fallocate -l 40G /asm0/asm_data1_00.img
  sudo fallocate -l 40G /asm1/asm_data1_01.img
  sudo fallocate -l 40G /asm2/asm_data1_02.img
  sudo fallocate -l 40G /asm3/asm_data1_03.img
  sudo fallocate -l 40G /asm4/asm_data1_04.img

  sudo fallocate -l 40G /asm0/asm_fra1_00.img
  sudo fallocate -l 40G /asm1/asm_fra1_01.img
  sudo fallocate -l 40G /asm2/asm_fra1_02.img
  sudo fallocate -l 40G /asm3/asm_fra1_03.img
  sudo fallocate -l 40G /asm4/asm_fra1_04.img

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for data     "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_data*
  ls -lrt /asm1/asm_data*
  ls -lrt /asm2/asm_data*
  ls -lrt /asm3/asm_data*
  ls -lrt /asm4/asm_data*

  sleep 10

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for fra      "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''

  ls -lrt /asm0/asm_fra*
  ls -lrt /asm1/asm_fra*
  ls -lrt /asm2/asm_fra*
  ls -lrt /asm3/asm_fra*
  ls -lrt /asm4/asm_fra*

  sleep 10

# Open file-backed devices for Oracle ASM diskgroup SYSTEMDG

  sudo scstadmin -open_dev asm_systemdg_00 -handler vdisk_fileio -attributes filename=/asm0/asm_systemdg_00.img
  sudo scstadmin -open_dev asm_systemdg_01 -handler vdisk_fileio -attributes filename=/asm1/asm_systemdg_01.img
  sudo scstadmin -open_dev asm_systemdg_02 -handler vdisk_fileio -attributes filename=/asm2/asm_systemdg_02.img
  sudo scstadmin -open_dev asm_systemdg_03 -handler vdisk_fileio -attributes filename=/asm3/asm_systemdg_03.img
  sudo scstadmin -open_dev asm_systemdg_04 -handler vdisk_fileio -attributes filename=/asm4/asm_systemdg_04.img

# Open file-backed devices for Oracle ASM diskgroups DATA and FRA

  sudo scstadmin -open_dev asm_data1_00    -handler vdisk_fileio -attributes filename=/asm0/asm_data1_00.img
  sudo scstadmin -open_dev asm_data1_01    -handler vdisk_fileio -attributes filename=/asm1/asm_data1_01.img
  sudo scstadmin -open_dev asm_data1_02    -handler vdisk_fileio -attributes filename=/asm2/asm_data1_02.img
  sudo scstadmin -open_dev asm_data1_03    -handler vdisk_fileio -attributes filename=/asm3/asm_data1_03.img
  sudo scstadmin -open_dev asm_data1_04    -handler vdisk_fileio -attributes filename=/asm4/asm_data1_04.img

  sudo scstadmin -open_dev asm_fra1_00     -handler vdisk_fileio -attributes filename=/asm0/asm_fra1_00.img
  sudo scstadmin -open_dev asm_fra1_01     -handler vdisk_fileio -attributes filename=/asm1/asm_fra1_01.img
  sudo scstadmin -open_dev asm_fra1_02     -handler vdisk_fileio -attributes filename=/asm2/asm_fra1_02.img
  sudo scstadmin -open_dev asm_fra1_03     -handler vdisk_fileio -attributes filename=/asm3/asm_fra1_03.img
  sudo scstadmin -open_dev asm_fra1_04     -handler vdisk_fileio -attributes filename=/asm4/asm_fra1_04.img

# Add LUNs for Oracle ASM diskgroup SYSTEMDG to SCST iscsi target

  sudo scstadmin -add_lun 0 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_systemdg_00
  sudo scstadmin -add_lun 1 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_systemdg_01
  sudo scstadmin -add_lun 2 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_systemdg_02
  sudo scstadmin -add_lun 3 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_systemdg_03
  sudo scstadmin -add_lun 4 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_systemdg_04

# Add LUNs for Oracle ASM diskgroups DATA and FRA to SCST iscsi target

  sudo scstadmin -add_lun 5 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_data1_00
  sudo scstadmin -add_lun 6 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_data1_01
  sudo scstadmin -add_lun 7 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_data1_02
  sudo scstadmin -add_lun 8 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_data1_03
  sudo scstadmin -add_lun 9 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_data1_04

  sudo scstadmin -add_lun 10 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_fra1_00
  sudo scstadmin -add_lun 11 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_fra1_01
  sudo scstadmin -add_lun 12 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_fra1_02
  sudo scstadmin -add_lun 13 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_fra1_03
  sudo scstadmin -add_lun 14 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_fra1_04

fi

# Write SCST configuration to /etc/scst.conf file

  sudo scstadmin -write_config /etc/scst.conf

# Enable SCST target for access

  sudo scstadmin -enable_target iqn.2015-08.org.vmem:w520.san.asm.luns -driver iscsi
  sudo scstadmin -write_config /etc/scst.conf
  sleep 5

  echo "======================================================"
  echo "Answer y here...                                      "
  echo "======================================================"
  
  sudo scstadmin -set_drv_attr iscsi -attributes enabled=1
  sleep 5
  sudo scstadmin -write_config /etc/scst.conf

  echo ''
  echo "======================================================"
  echo "Verify that SCST SAN is fully configured and ready    "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''

  sudo scstadmin -list_group

  sleep 10

