cd ~/Downloads
pwd
sudo apt-get install -y debian-keyring
# ssh-keygen -t rsa  # first run only do not uncomment if lxc-containers have already been installed for Oracle
sleep 10
sudo gpg --keyserver keyserver.ubuntu.com --recv-keys B1CDE58F
sudo gpg --no-default-keyring -a --export B1CDE58F | sudo gpg --no-default-keyring --keyring ~/.gnupg/trustedkeys.gpg --import -
echo "======================================================="
echo "Verify gpg key installed successfully                  "
echo "Sleeping 20 seconds...                                 "
echo "======================================================="
sudo apt-get install -y subversion
sleep 10
sudo svn co https://scst.svn.sourceforge.net/svnroot/scst/trunk scst
cd scst
sudo scripts/generate-kernel-patch 3.19 > ../scst.patch
cd ..
sudo apt-get source -y linux-image-$(uname -r)
echo "======================================================="
echo "Verify success...                                      "
echo "Sleeping 10 seconds...                                 "
echo "======================================================="
sleep 5
sudo apt-get build-dep -y linux-image-$(uname -r)
echo "======================================================="
echo "Verify success...                                      "
echo "Sleeping 10 seconds...                                 "
echo "======================================================="
sleep 5
sudo apt-get install -y libncurses5-dev
echo "======================================================="
echo "Verify success...                                      "
echo "Sleeping 10 seconds...                                 "
echo "======================================================="
sleep 5
cd ~/Downloads/linux-3.19.0/
sudo patch -Np1 -i ../scst.patch
echo "======================================================="
echo "Verify patch created successfully...                   "
echo "Sleeping 10 seconds...                                 "
echo "======================================================="
sleep 5
sudo chmod a+x debian/scripts/*
sudo chmod a+x debian/scripts/misc/*
echo "========================================================================"
echo "Note: may have to change these paths if your kernel version is different"
echo "i.e. change 3.19.0-26.27 to your kernel version                         "
echo "========================================================================"

cd debian.master/abi
ls -lrt
echo ''
echo "sleeping 20 seconds..."
echo "review output in abi directory"
echo "should be 3.19.0-26.27"
echo ''
pwd
sleep 20

# sudo cp debian.master/config/amd64/config.flavour.generic debian.master/config/amd64/config.flavour.scst
# sudo cp debian.master/abi/3.19.0-26.27/amd64/generic debian.master/abi/3.19.0-26.27/amd64/scst
# sudo cp debian.master/abi/3.19.0-26.27/amd64/generic.modules debian.master/abi/3.19.0-26.27/amd64/scst.modules
# sudo cp debian.master/control.d/vars.generic debian.master/control.d/vars.scst
# ls -lrt debian.master/config/amd64/config.flavour.scst
# ls -lrt debian.master/abi/3.19.0-26.27/amd64/scst
# ls -lrt debian.master/abi/3.19.0-26.27/amd64/scst.modules
# ls -lrt debian.master/control.d/vars.scst
