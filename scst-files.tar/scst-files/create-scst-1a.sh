cd ~/Downloads
pwd
echo "======================================================="
echo "Thanks to Chris Weiss for the manual steps for building"
echo "SCST on Ubuntu.                                        "
echo "https://gist.github.com/chrwei/42f8bbb687290b04b598    "
echo "======================================================="
echo ''
sudo apt-get install -y debian-keyring
sudo apt-get install -y gawk
# ssh-keygen -t rsa  # first run only do not uncomment if lxc-containers have already been installed for Oracle
sleep 10
sudo gpg --keyserver keyserver.ubuntu.com --recv-keys B1CDE58F
sudo gpg --no-default-keyring -a --export B1CDE58F | sudo gpg --no-default-keyring --keyring ~/.gnupg/trustedkeys.gpg --import -
echo "======================================================="
echo "Verify gpg key installed successfully                  "
echo "Sleeping 10 seconds...                                 "
echo "======================================================="

echo "======================================================="
echo "Get Kernel Version of running kernel...                "
echo "======================================================="

# GLS 20151126 Added function to get kernel version of running kernel to support linux 4.x kernels in Ubuntu Wily Werewolf etc.

function GetRunningKernelVersion {
uname -r | cut -f1 -d'-'
}
RunningKernelVersion=$(GetRunningKernelVersion)

# GLs 20151126 Added function to get kernel directory path for running kernel version to support linux 4.x and linux 3.x kernels etc.

function GetKernelDirectoryPath {
uname -a | cut -f3 -d' ' | cut -f1 -d'-' | sed 's/^/linux-/'
}
KernelDirectoryPath=$(GetKernelDirectoryPath)

sudo apt-get install -y subversion
sleep 10
sudo svn co https://scst.svn.sourceforge.net/svnroot/scst/trunk scst
cd scst
sudo scripts/generate-kernel-patch $RunningKernelVersion > ../scst.patch
cd ..
sudo apt-get source -y linux-image-$(uname -r)
echo "======================================================="
echo "Verify success...                                      "
echo "Sleeping 10 seconds...                                 "
echo "======================================================="
sleep 5
sudo apt-get build-dep -y linux-image-$(uname -r)
echo "======================================================="
echo "Verify success...                                      "
echo "Sleeping 10 seconds...                                 "
echo "======================================================="
sleep 5
sudo apt-get install -y libncurses5-dev
echo "======================================================="
echo "Verify success...                                      "
echo "Sleeping 10 seconds...                                 "
echo "======================================================="
sleep 5
cd ~/Downloads/$KernelDirectoryPath/
sudo patch -Np1 -i ../scst.patch
echo "======================================================="
echo "Verify patch created successfully...                   "
echo "Sleeping 10 seconds...                                 "
echo "======================================================="
sleep 5
sudo chmod a+x debian/scripts/*
sudo chmod a+x debian/scripts/misc/*

echo "========================================================================"
echo "20151126 Scripts updated to dynamically select correct kernel versions  "
echo "20151126 Visually check to make sure correct kernel version selected    "
echo "========================================================================"

cd debian.master/abi
ls -lrt

echo ''
echo "========================================================================"
echo "sleeping 20 seconds...                                                  "
echo "Review output in abi directory to see if kernel versions look correct..."
echo "========================================================================"
echo ''

