#    Copyright 2015-2016 Gilbert Standen
#    This file is part of orabuntu-lxc.

#    Orabuntu-lxc is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-lxc is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with orabuntu-lxc.  If not, see <http://www.gnu.org/licenses/>.

#    v2.8 GLS 20151231
#    v3.0 GLS 20160710

#!/bin/bash

clear

echo ''
echo "===================================================="
echo "Dynamically create multipath.conf file...patience..."
echo "===================================================="
echo ''

echo '' > ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo 'blacklist {' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    devnode      "sd[a]$"' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf

function GetDevNode {
sudo ls /dev/sd* | sed 's/$/ /' | tr -d '\n'
}
DevNode=$(GetDevNode)
for k in $DevNode
do
	function GetVendor {
	sudo udevadm info -a -p  $(udevadm info -q path -n $k) | egrep 'ATTRS{vendor}' | grep -v '0x' | sed 's/  *//g' | rev | cut -f1 -d'=' | sed 's/"//g' | rev | sed 's/$/_DEVICE/'
	}
	Vendor=$(GetVendor)
 	function GetProduct {
 	sudo udevadm info -a -p  $(udevadm info -q path -n $k) | egrep 'ATTRS{model}' | grep -v '0x' | sed 's/  *//g' | rev | cut -f1 -d'=' | rev
 	}
 	Product=$(GetProduct)
	function CheckProductExist {
	cat multipath.conf | grep $Product | rev | cut -f1 -d' ' | rev | sort -u | wc -l
	}
	ProductExist=$(CheckProductExist)
	function GetExistId {
	sudo /lib/udev/scsi_id -g -u -d $k
	}
	ExistId=$(GetExistId)
		if [ "$Vendor" != "SCST_FIO_DEVICE" ] && [ "$ProductExist" -eq 0 ] && [ ! -z $ExistId ]
		then
			ExistId=$(GetExistId)
			function CheckIdExist {
			grep -c $ExistId ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
			}
			IdExist=$(CheckIdExist)
			if [ "$IdExist" -eq 0 ]
			then
				sudo /lib/udev/scsi_id -g -u -d $k | sed 's/^/    wwid         "/' | sed 's/$/"/' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
			fi
		echo '    device {' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
		sudo udevadm info -a -p  $(udevadm info -q path -n $k) | egrep 'ATTRS{rev}|ATTRS{model}|ATTRS{vendor}' | grep -v 0x | grep vendor | cut -f3 -d'=' | sed 's/  *//g' | sed 's/^/        vendor   /' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
		sudo udevadm info -a -p  $(udevadm info -q path -n $k) | egrep 'ATTRS{rev}|ATTRS{model}|ATTRS{vendor}' | grep -v 0x | grep model  | cut -f3 -d'=' | sed 's/  *//g' | sed 's/^/        product  /' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
		sudo udevadm info -a -p  $(udevadm info -q path -n $k) | egrep 'ATTRS{rev}|ATTRS{model}|ATTRS{vendor}' | grep -v 0x | grep rev    | cut -f3 -d'=' | sed 's/  *//g' | sed 's/^/        revision /' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
		echo '    }' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
		fi
done
echo '}' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf

echo 'defaults {' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    user_friendly_names  yes' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '}' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo 'devices {' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    device {' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    vendor               "SCST_FIO"' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    product              "asm*"' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    revision             "310"' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    path_grouping_policy group_by_serial' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    getuid_callout       "/lib/udev/scsi_id --whitelisted --device=/dev/%n"' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    hardware_handler     "0"' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    features             "1 queue_if_no_path"' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    fast_io_fail_tmo     5' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    dev_loss_tmo         30' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    failback             immediate' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    rr_weight            uniform' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    no_path_retry        fail' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    path_checker         tur' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    rr_min_io            4' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    path_selector        "round-robin 0"' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '    }' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo '}' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
echo 'multipaths {' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf

# Old function line
# sudo scstadmin -list_group | grep systemdg | rev | cut -f1 -d' ' | rev | sed 's/$/ /' | tr -d '\n'

function GetLunName {
cat /etc/scst.conf | grep LUN | rev | cut -f1 -d' ' | rev | sed 's/$/ /' | tr -d '\n'
}
LunName=$(GetLunName)

for i in $LunName
do
	function GetDevNode {
	sudo ls /dev/sd* | sed 's/$/ /' | tr -d '\n'
	}
	DevNode=$(GetDevNode)
	for j in $DevNode
	do
		function GetModelName {
		sudo udevadm info -a -p  $(udevadm info -q path -n $j) | egrep 'ATTRS{model}' | sed 's/  *//g' | rev | cut -f1 -d'=' | sed 's/"//g' | rev | sed 's/^[ \t]*//;s/[ \t]*$//' | grep $i 
		}
		function CheckEntryExist {
		cat ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf | grep $i
		}
		EntryExist=$(CheckEntryExist)
		ModelName=$(GetModelName)
		if [ "$ModelName" = "$i" ] && [ -z "$EntryExist" ]
		then
			function Getwwid {
			sudo /lib/udev/scsi_id -g -u -d $j
			}
			wwid=$(Getwwid)
			echo "     multipath {" >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
			echo "         wwid $wwid" >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
			echo "         alias $i" >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
			echo "     }" >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
		fi
	done
done
echo '}' >> ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf

# GLS 20151126 Added function to get kernel version of running kernel to support linux 4.x kernels in Ubuntu Wily Werewolf etc.

function GetRunningKernelVersion {
uname -r | cut -f1-2 -d'.'
}
RunningKernelVersion=$(GetRunningKernelVersion)

# GLS 20151126 Added function to get kernel directory path for running kernel version to support linux 4.x and linux 3.x kernels etc.

function GetKernelDirectoryPath {
uname -a | cut -f3 -d' ' | cut -f1 -d'-' | cut -f1 -d'.' | sed 's/^/linux-/'
}
KernelDirectoryPath=$(GetKernelDirectoryPath)

if [ $KernelDirectoryPath = 'linux-4' ]
then
sed -i 's/revision "/# revision "/' ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf
fi

echo "Review file ~/Downloads/orabuntu-lxc-master/scst-files/multipath.conf for validity, then run script create-scst-5b.sh ..."
echo ''

echo "===================================================="
echo "Dynamically create multipath.conf file complete.    "
echo "===================================================="
echo ''

