#    Copyright 2015-2016 Gilbert Standen
#    This file is part of orabuntu-lxc.

#    Orabuntu-lxc is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    Orabuntu-lxc is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with orabuntu-lxc.  If not, see <http://www.gnu.org/licenses/>.

#    v2.8 GLS 20151231
#    v3.0 GLS 20160710
#    v3.1 GLS 20160924 # Removes requirement of custom kernel for SCST deployment for Linux kernels >= 2.6.30

GetLinuxFlavor(){
	if [[ -e /etc/redhat-release ]]
	then
		LinuxFlavor=$(cat /etc/redhat-release | cut -f1 -d' ')
	elif [[ -e /usr/bin/lsb_release ]]
	then
		LinuxFlavor=$(lsb_release -d | awk -F ':' '{print $2}' | cut -f1 -d' ')
	elif [[ -e /etc/issue ]]
	then
		LinuxFlavor=$(cat /etc/issue | cut -f1 -d' ')
	else
		LinuxFlavor=$(cat /proc/version | cut -f1 -d' ')
	fi
}
GetLinuxFlavor

function TrimLinuxFlavor {
echo $LinuxFlavor | sed 's/^[ \t]//;s/[ \t]$//'
}
LinuxFlavor=$(TrimLinuxFlavor)

echo "======================================================="
echo "Get Kernel Version of running kernel...                "
echo "======================================================="

# GLS 20151126 Added function to get kernel version of running kernel to support linux 4.x kernels in Ubuntu Wily Werewolf etc.
# GLS 20160924 SCST 3.1 does not require a custom kernel build for kernels >= 2.6.30 so now we check that kernel is >= 2.6.30.
# GLS 20160924 If the kernel version is lower than 2.6.30 it will be necessary for you to compile a custom kernel.

function VersionKernelPassFail () {
    ./vercomp | cut -f1 -d':'
}
KernelPassFail=$(VersionKernelPassFail)

if [ $KernelPassFail = 'Pass' ]
then
	if [ $LinuxFlavor = 'Ubuntu' ]
	then
		echo "======================================================="
		echo "Consult Chris Weiss post on building custom SCST kernel"
		echo "on Ubuntu for kernels older than 2.6.30.               "
		echo "https://gist.github.com/chrwei/42f8bbb687290b04b598    "
		echo "======================================================="
		echo ''
		echo "======================================================="
		echo "Establish sudo privileges ...                          "
		echo "======================================================="
		echo ''

		sudo date

		echo ''
		echo "======================================================="
		echo "Establish sudo privileges successful.                  "
		echo "======================================================="
		echo ''

		echo "======================================================="
		echo "Installing Packages ...                                "
		echo "======================================================="

		sudo apt-get install -y gawk
		sudo apt-get install -y multipath-tools
		sudo apt-get install -y open-iscsi
		sudo apt-get install -y gawk
		sudo apt-get install -y subversion
		echo "======================================================="
		echo "Installing SCST version 3.1                            "
		echo "======================================================="
		svn co https://scst.svn.sourceforge.net/svnroot/scst/branches/3.1.x scst-3.1
		cd scst-3.1
		sudo make 2perf scst scst_install iscsi iscsi_install scstadm scstadm_install
		sudo systemctl enable scst.service
		sudo service scst start
		sudo service scst status
		sudo make scst scst_install iscsi iscsi_install scstadm scstadm_install
		sudo modprobe scst
		sudo modprobe scst_vdisk
		sudo modprobe scst_disk
		sudo modprobe scst_user
		sudo modprobe scst_modisk
		sudo modprobe scst_processor
		sudo modprobe scst_raid
		sudo modprobe scst_tape
		sudo modprobe scst_cdrom
		sudo modprobe scst_changer
		sudo modprobe iscsi-scst
		sudo iscsi-scstd
		sudo service scst start
		sudo systemctl enable scst.service
		sudo systemctl daemon-reload
	elif [ $LinuxFlavor = 'CentOS' ]
	then
		echo "======================================================="
		echo "Installing Packages ...                                "
		echo "======================================================="
		yum -y install svn
		yum -y groupinstall "Development Tools" 
		yum -y install asciidoc newt-devel xmlto
		yum -y install perl-ExtUtils-MakeMaker
		yum -y install kernel-devel-$(uname -r)
		yum -y install device-mapper-multipath
		yum -y install iscsi-initiator-utils
		echo "======================================================="
		echo "Installing SCST version 3.1                            "
		echo "======================================================="
		svn co https://scst.svn.sourceforge.net/svnroot/scst/branches/3.1.x scst-3.1
		cd scst-3.1
		make 2perf scst scst_install iscsi iscsi_install scstadm scstadm_install
		systemctl enable scst.service
		service scst start
		service scst status
		make scst scst_install iscsi iscsi_install scstadm scstadm_install
		modprobe scst
		modprobe scst_vdisk
		modprobe scst_disk
		modprobe scst_user
		modprobe scst_modisk
		modprobe scst_processor
		modprobe scst_raid
		modprobe scst_tape
		modprobe scst_cdrom
		modprobe scst_changer
		modprobe iscsi-scst
		iscsi-scstd
		service scst start
		systemctl enable scst.service
	else
		echo "======================================================="
		echo "Kernel version is lower than 2.6.30. Consider Upgrade. " 
		echo "======================================================="
	fi
fi
